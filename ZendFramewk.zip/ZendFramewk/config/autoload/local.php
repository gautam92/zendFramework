<?php
// config/autoload/local.php:
return array(
    'db' => array(
        'user' => 'root',
        'password' => 'root',
    ),
);
?>