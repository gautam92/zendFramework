<?php
/*
@@ Developer : [Gautam Dharaiya] [Date : 01-Jun-2015]
@@ Description :Define All Global Message  
*/

// GD - All Tax Title 
define('SERVICE_CHARGE_TITLE','Service Charge');
define('SERVICE_TAX_TITLE','Service Tax');
define('VAT_TITLE','Vat');
define('SWACCH_BHARAT_CESS_TITLE','Swacch Bharat Cess');
define('KRUSHI_KALYAN_CESS_TITLE','Krishi Kalyan Cess');
define('KRUSHI_KALYAN_TITLE','Krishi Kalyan');
define('GST_TITLE','GST');
define('CASH_CARRY_GST_TAX_TITLE','GST');
define('CGST_TITLE','CGST');
define('SGST_TITLE','SGST');
define('CASH_CARRY_CGST_TAX_TITLE','CGST');
define('CASH_CARRY_SGST_TAX_TITLE','SGST');

// IC CHARGE TITLE
define('IC_CHARGE_TITLE', 'I.C. Charges');
define('IC_SERVICE_TAX_TITLE', 'Service Tax');
define('IC_SBC_TITLE', 'SBC');
define('IC_KKC_TITLE', 'KKC');

// GD - CASH CARRY TAX TITLE 
define('CASH_CARRY_SERVICE_CHARGE_TITLE','Service Charge');
define('CASH_CARRY_SERVICE_TAX_TITLE','Service Tax');
define('CASH_CARRY_VAT_TITLE','Vat');
define('CASH_CARRY_SWACCH_BHARAT_CESS_TITLE','Swacch Bharat Cess');
define('CASH_CARRY_KRUSHI_KALYAN_CESS_TITLE','Krishi Kalyan Cess');
define('CASH_CARRY_KRUSHI_KALYAN_TITLE','Krishi Kalyan');

// SignUp Message
define('FIRSTNAME','Enter firstname');
define('LASTNAME','Enter lastname');
define('EMAIL','Enter email');
define('PASSWORD','Enter Password');
@define('EMAIL_EXITS','User with email '.EMAIL_NAME.'already registered with us');
define('EMAIL_INVALID','Enter valid email address');
define('INVALID_TOKEN','Invalid token');

define('SUCC_SIGNUP_USER','Signup successfully, please check your email for activation link');
define('FB_ACC_EXITS','Your account is already activated through Facebook/Google');
define('GP_ACC_EXITS','Your account is already activated through Facebook/Google');
define('SUCC_EMAIL','Please check your email for password reset details');
// Login Message

define('INVALID_LOGIN_DETAILS','Invalid log in credentials, try again');
define('IS_USER_ACTIVE','Your account suspended by admin');

define('CUISINE_NM','Enter cuisine name');
define('CUISINE_ADD_SUCC','Cuisine has been added successfully');
define('CUISINE_NM_EXITS','Cuisine already exist');
define('CUISINE_UPDATE_SUCC','Cuisine has been updated successfully');
// Update Details Message

define('GENDER','Select gender');
define('PHONE_NUMER','Enter phone number');
define('CITY','Enter city');
define('STATE','Enter state');
define('ZIP_CODE','Zipcode - Please enter 6-digit valid zipcode');
define('COUNTRY','Select country');

define('UPDATE_SUCC_INFORMATION','Password changed successfully');
define('UPDATEPROFILE_SUCC_INFORMATION','Profile has been updated successfully');
define('MOBILE_VALID','Phone number must be at least 8 and less than 14 digits');
define('PASSWORD_LENGTH_VALID','Password must be at least 6 and less than 20 digits');

// change password
define('NEW_PASSWORD','Enter newpassword');
define('CONFIRM_PASSWORD','Enter confirmpassword');
define('MISMATCH_PASSWORD', "Password does not match");
define('SUCC_UPDATE_PASS','Password changed successfully');
define('CURR_PASSWORD','Enter current password');
define('CURR_WRONG_PASSWORD','current password does not match');
// smtp mail details

//MESSAGE ASHVIN START//
//user
define('USER_FIRST_NAME','Enter firstname');
define('USER_LAST_NAME','Enter lastname');
define('USER_MOBILE_NUMBER','Enter mobile number');
define('USER_EMAIL_ADDRESS','Enter email address');
define('USER_DOB','Enter date of birth');

define('USER_CURRENT_LATITUDE','Enter current latitude');
define('USER_CURRENT_LONGITUDE','Enter current longitude');
define('USER_DEVICE_TYPE','Enter device type');
define('USER_DEVICE_OS','Enter device os');
define('USER_DEVICE_TOKEN','Enter device token');

define('USER_APP_VERSION','Enter app version');
define('USER_DATE_REGISTERED','Enter registered date');
define('USER_LAST_LOGGED_IN','Enter last logged in date and time');
define('USER_LOGGED_IN_LATITUDE','Enter logged in latitude');
define('USER_LOGGED_IN_LONGITUDE','Enter logged in longitude');

define('USER_UPDATE_SUCC','User has been updated successfully');
define('EMAIL_ALREADY_EXIST','Email already exist');

define('MOBILE_ALREADY_EXIST','Mobile number already exist');
//MESSAGE ASHVIN END//

define('RESTAURANT_ADD_SUCC','Restaurant has been added successfully');
define('RESTAURANT_UPDATE_SUCC','Restaurant record updated successfully');
define('RESTAURANT_STREET', 'Enter street address');
define('RESTAURANT_LANDMARK', 'Enter landmark');
define('RESTAURANT_CITY', 'Enter city');
define('RESTAURANT_STATE', 'Enter state');
define('RESTAURANT_ZIPCODE', 'Enter zipcode');
define('RESTAURANT_COUNTRY', 'Enter country');
define('RESTAURANT_NM', 'Enter restaurant name');
define('RESTAURANT_ESTABLISHED_SINCE', 'Enter established since');
define('RESTAURANT_FIRSTNM', 'Enter firstname');
define('RESTAURANT_LASTNM', 'Enter lastname');
define('RESTAURANT_PHONE_NM', 'Enter phone no');
define('RESTAURANT_DOB', 'Enter date of birth');
define('RESTAURANT_EMAIL', 'Enter email address');
define('RESTAURANT_PASS', 'Enter password');
define('RESTAURANT_NM_EXITS','Restaurant name already exist');
define('RESTAURANT_EMAIL_EXITS','Restaurant email already exists');

define('BRANCH_ADD_SUCC','Branch record added successfully');
define('BRANCH_NM_EXITS','Branch already exist');
define('BRANCH_UPDATE_SUCC','Branch record updated successfully');
/* start changes by prashant shah 09-12-2015 */
define('BRANCH_SUSPENSION_ERROR','Branch cannot be suspended if there is any order in running mode');
/* end changes by prashant shah 09-12-2015 */
/* start changes by prashant shah 08-12-2015*/
define('BRANCH_UNDER_REVIEW','The branch account deactivation is under process. We will take atleast 2 business days to verify and deactivate the branch');
/* end changes by prashant shah 08-12-2015*/

define('BRANCHMANAGER_ADD_SUCC','Employee record added successfully');
define('BRANCHMANAGER_EMAIL_EXITS','Branch Employee email already exist');
define('BRANCHMANAGER_UPDATE_SUCC','Employee record updated successfully');
define('BRANCHMANAGER_LIMIT_EXCEED','You cannot add more than Five employees');
define('BRANCHMANAGER_NUMBER_OF_EMPLOYEE_ALLOWED',5);

define('MENUCARD_NM_EXITS','Menucard already exist');
define('MENUCARD_ADD_SUCC','Menu card added successfully');
define('MENUCARD_UPDATE_SUCC','Menu card updated successfully');
define('MENUCARD_ORDER_EXITS','Menu card sequence already exist');

/* start changes by prashant shah 16-12-2015*/
define('CATEGORY_NM_EXITS','Menu category already exist');
define('CATEGORY_ADD_SUCC','Menu category added successfully');
define('CATEGORY_UPDATE_SUCC','Menu category updated successfully');
define('CATEGORY_ORDER_EXITS','Menu category sequence already exist');

define('CATEGORYITEM_NM_EXITS','Menu item already exist');
define('CATEGORYITEM_ADD_SUCC','Menu item added successfully');
define('CATEGORYITEM_UPDATE_SUCC','Menu item updated successfully');
// define('CATEGORYITEM_ORDER_EXITS','Menu item sequence already exist');

define('EXTRAITEM_NM_EXITS','Menu extra item already exist');
define('EXTRAITEM_ADD_SUCC','Menu extra item has been created successfully');
define('EXTRAITEM_UPDATE_SUCC','Menu extra item has been updated successfully');
/* end changes by prashant shah 16-12-2015*/

define('BEACONS_NM_EXITS','Beacon already exist');
define('BEACONS_ADD_SUCC','Beacon has been added successfully');
define('BEACONS_UPDATE_SUCC','Beacon has been updated successfully');

define('TABLES_NM_EXITS','Table number already exist');
define('TABLES_ADD_SUCC','Table added successfully');
define('TABLES_UPDATE_SUCC','Table updated successfully');
define('IMPORT_MENU_SUCCESS','Import menu has been added successfully');
define('ZIPCODE_INVALID','Enter valid zipcode');

define('TASTE_NM','Enter taste name');
define('TASTE_ADD_SUCC','Taste has been added successfully');
define('TASTE_NM_EXITS','Taste already exist');
define('TASTE_UPDATE_SUCC','Taste has been updated successfully');
/*define('SMTP_EMAIL_ADDRESS','qaorig1@gmail.com');
define('SMTP_PASS','qaorig1234');*/

define('UPSELL_DUPLICATE','Category added multiple times to upsell');
define('VOOLSY_FLAT_COUPON_TITLE','All Voolsy Partnered Outlets');

// Prepayment Notification Messages. 
//define('PREPAYMENT_NOTIFY','Your order is ready now, Please take from counter.');
//define('PREPAYMENT_NOTIFY_DELAY','Your order is delay, Please contact to counter manager.');
//define('REQUESTTOUNSERVED','Your order has been confirmed and preparing now.');
//define('UNSERVEDTOSERVED','Your order has been served successfully.');


define('PREPAYMENT_NOTIFY','Your order #BRNNM# is ready. Please collect it from the counter.');
define('COLLECTION_NOTIFY_TITLE','Ready to collect');

define('PREPAYMENT_NOTIFY_DELAY','There appears to be a slight delay with your order #BRNNM#. We appreciate your patience.');
define('PREPAYMENT_NOTIFY_DELAY_TITLE','Attention Delay');

define('PREPAYMENT_NOTIFY_ACCEPT_TITLE','Order Confirmation');
define('PREPAYMENT_NOTIFY_ACCEPT','Your order #BRNNM# has been accepted. It will be ready in #MINIT_WAIT# minutes');

define('PREPAYMENT_FULLY_REFUND_TITLE','Full Refund');
define('PREPAYMENT_FULLY_REFUND_MESSAGE','Full Refund');
define('PREPAYMENT_FULLY_REFUND','Your order has been fully refunded');

define('PREPAYMENT_PARTIAL_REFUND_TITLE','Partial Refund');
define('PREPAYMENT_PARTIAL_REFUND_MESSAGE','Partial Refund');
define('PREPAYMENT_PARTIAL_REFUND','Your order #BRNNM# has been partial refunded');

define('REQUESTTOUNSERVED_TITLE','Confirm Order');
define('REQUESTTOUNSERVED_MESSAGE','Prepayment');
define('REQUESTTOUNSERVED','Your order #BRNNM# has been confirmed and preparing now.');

define('UNSERVEDTOSERVED_TITLE','Served Order');
define('UNSERVEDTOSERVED_MESSAGE','Prepayment');
define('UNSERVEDTOSERVED','Your order #BRNNM# has been served successfully.');

// define('PREPAYMENT_NOTIFY_CALL_CUSTOMER','We need your attention. Kindly come to #BRNNM#');
// define('PREPAYMENT_NOTIFY_CALL_CUSTOMER_TITLE','Attention');

define('PREPAYMENT_NOTIFY_REFUND_TITLE','Full Refund');
define('PREPAYMENT_FULLY_BRANCH_REFUND_REJECT1','Sorry your order #BRNNM# has been rejected as this item is currently  unavailable');
define('PREPAYMENT_FULLY_BRANCH_REFUND_REJECT2','Sorry your order #BRNNM# has been rejected as there appears to a be problem  with the machinery of this item.');
define('PREPAYMENT_FULLY_BRANCH_REFUND_REJECT3','Sorry your order #BRNNM# has been rejected as the restaurant is  unable to deliver this item.');

define('CATEGORYITEM_ORDER_EXITS','Sequance number already exist');

define('PROMOTONAL_NOTIFICATION_SEND','Promotion Information Sent Sucessfully.');
define('PROMOTONAL_NOTIFICATION_NOT_SEND','There is no device registered.');

define('BEACONS_TABLE_NOT_EXITS','Please set your beacon uuid');

define('EMAIL_VERIFY_TEXT','Please verify your email to get your order, invoice & upcoming offers details');
define('EMAIL_VERIFY_TEXT_SUCCESS_ORDER','Unable to send order receipt on email as it is not verified');

/* HD :: Start Global PHP Messages */
define('NOTIFICATION_MSG_SEND','Notification Information Sent Sucessfully.');
define('NOTIFICATION_MSG_NOT_SEND','There is no device registered.');

// define('MSG91_API_AUTHENTICATION_KEY','91740Aasaj55ll2r55f19193');
define('SMS_NOTIFICATION_MSG_SEND','SMS notification sent sucessfully.');
define('SMS_NOTIFICATION_MSG_NOT_SEND','Something went wrong.');

define('SUGGESTED_IMAGE_CROPPED','Image uploaded successfully');
define('SUGGESTED_IMAGE_DELETED','Suggested image deleted successfully');
define('MONDAY','monday');
define('TUESDAY','tuesday');
define('WEDNESDAY','wednesday');
define('THURSDAY','thursday');
define('FRIDAY','friday');
define('SATURDAY','saturday');
define('SUNDAY','sunday');
define('LOGIN_DOES_NOT_HAVE_ACCESS','You do not have enough access');
define('EXTRA_ADD_SUCC','Extra-Ingredients has been updated successfully');
define('EXTRA_CATEGORY_NAME_EXIST','Category name already exist');
define('EXTRA_INGREDIENTS_ITEM_NAME_EXIST','Category item name already exist');
define('EXTRA_CATEGORY_REFERENCE_NAME_EXIST','Category reference name already exist');
define('EXTRA_INGREDIENTS_ITEM_REFERENCE_NAME_EXIST','Category item reference name already exist');
define('EXTRA_INGREDIENTS_ADD_SUCC','Extra-Ingredients has been added successfully');
define('EXTRA_INGREDIENTS_UPDATE_SUCC','Extra-Ingredients has been updated successfully');
define('GENERAL_EXTRA_INGREDIENTS_ADD_SUCC','Extra-Ingredients has been added successfully');
define('GENERAL_EXTRA_INGREDIENTS_UPDATE_SUCC','Extra-Ingredients has been updated successfully');
define('EXTRA_INGREDIENTS_NAME_EXIST','Category item name already exist');

define('NOTIFICATION_AND_SMS_SEND_NOTIFICATION','Notification Sent to #COUNT# Customer.');
define('NOTIFICATION_AND_SMS_SEND_SMS','SMS Sent to #COUNT# Customer.');
define('NOTIFICATION_AND_SMS_SEND_ERROR','Something went wrong.');
define('NOTIFICATION_AND_SMS_NO_USER','There is no matching user found.');

define('DISCOUNT_SAVE_SUCC','Discount saved successfully');
define('DISCOUNT_SAVE_ERROR','Something went wrong.');

define('ACCOUNT_ADD_SUCC','Account has been created successfully');
define('ACCOUNT_UDATE_SUCC','Account has been updated successfully');
define('ACCOUNT_ADD_NAME_EROR','Enter Unique Name');
define('ACCOUNT_ADD_VALID_NAME_EROR','Enter Valid Account Name');
define('DISCOUNT_ADD_SUCC','Amount deposited successfully');

/* Menu Setting */
define('MENU_SETTING_DISCOUNT_ADD_SUCC','Menu discount add successfully');
define('MENU_SETTING_DISCOUNT_UPDATE_SUCC','Menu discount update successfully');
define('MENU_SETTING_TIMING_ADD_SUCC','Menu timing add successfully');
define('MENU_SETTING_TIMING_UPDATE_SUCC','Menu timing update successfully');
define('MENU_SETTING_TAX_ADD_SUCC','Menu tax add successfully');
define('MENU_SETTING_TAX_UPDATE_SUCC','Menu tax update successfully');

//define('USER_CASHBACK_SMS',"Congratulations! You've Rs.#AMOUNT# cashback. check it out in Voolsy Offers Section. Pay via Voolsy to redeem on your next dine-out.");
//define('USER_CASHBACK_SMS',"Congratulations! You've received Rs.#AMOUNT# cashback. check your total balance in Voolsy Offers section. Pay via Voolsy to redeem on your next dine");
define('USER_CASHBACK_SMS',"Congratulations! You've  Rs.#AMOUNT# cashback. check it out in Voolsy Credits Section. Pay via  Voolsy to redeem on your next dine-out.");
define('USER_PROMOTIONAL_CASHBACK_SMS',"Congratulations! You've Rs.#AMOUNT# cashback. check it out in Voolsy Credits Section. Pay via Voolsy to redeem on your next dine-out.");

define('MENUCARD_RUNNING_ORDER_MSG','Please, Complete your all running order.');
/* HD :: End Global PHP Messages */

define('USER_PAYMENT_COMPLETE_SMS','Payment for order OIDxxxxxx at BRNNM has been received successfully.');

define('USER_PAYMENT_CANCEL_ORDER_SMS','Order id OIDxxxxxx at BRNNM has been cancelled. Payment will get refunded to your payment source account if paid.');

define('USER_ORDER_COMPLETE_SMS','Your order OIDxxxxxx at BRNNM has been served successfully. If not then please contact restaurant manager immediately.');

define('USER_PAYMENT_REFUND_SMS','Amount of Rs. XXX against order id OIDxxxxxx is refunded to your payment source account. It should reflect within 6-7 working days as per bank procedure.');

define('USER_PAYMENT_ACCESS_REFUND_SMS','Amount of Rs. XXX against order id OIDxxxxxx is refunded to your payment source account. It should reflect within 6-7 working days as per bank procedure.');

define('USER_INSUFFICIENT_COVER_CHARGE','Your cover charges balance is insufficient');

define('BRANCH_RESTRICT_CHANGE_TABLE',"You don't have rights to change table");

// define('SUSPEND_USER_VALIDATION_MESSAGE','Oops, it looks like your account is not active.Please contact Voolsy for further support');

define('CUSTOMER_COUNTER_ORDER_OTP','Your BRNNM otp is OTPNUMBER  Use Voolsy to Order & Pay without coupon. install at vlsy.in/app <http://vlsy.in/app>');

define('SUSPEND_USER_VALIDATION_MESSAGE','Oops, it looks like your account is not active.Please contact Voolsy for further support');

define('OTHER_COUNTER_ORDER_MESSAGE','There is no order for this counter');

// Counter Branch Text Title
define('COUNTER_TEXT_TITLE','NEXT STEP');
define('COUNTER_TEXT_DESCRIPTION','Go to the mentioned counter to enter the OTP and take the printout of the order placed.');

define('ADD_PAYMENT_METHOD','Add payment method');

define('CNC_CASH_AND_CARRY_TEXT','Cash & Carry');
define('CNC_ON_TABLE_TEXT','On Table');
define('CNC_EAT_OUT_OPTION_TEXT','Select option');

define('FEEDBACK_PREPAYMENT_RATING_SUB_TITLE','it would be awesome if you can \n rate your experience with');
define('FEEDBACK_POST_PAYMENT_RATING_SUB_TITLE','It would be awesome to get your ratings at');
define('FEEDBACK_REVIEW_MESSAGE','Please select any one option');

// Know More Title Home page Section
define('HOMEPAGE_KNOW_MORE_TITLE','Are you at the venue ? \n Select any of the below dining options');
define('HOMEPAGE_KNOW_MORE_BOLD_TITLE','Select any of the below dining options');
define('HOMEPAGE_KNOW_MORE_REDIRECT_URL','https://control.voolsy.com/public/know_more_v1/index.html');

define('TAG_NM','Enter Tag name');
define('TAG_ADD_SUCC','Restaurant Tag has been added successfully');
define('TAG_NM_EXITS','Restaurant Tag already exist');
define('TAG_UPDATE_SUCC','Restaurant Tag has been updated successfully');

define('PREPAYMENT_NOTIFY_CALL_CUSTOMER','We need your attention. Kindly come to #BRNNM#');
define('PREPAYMENT_NOTIFY_CALL_CUSTOMER_TITLE','Voolsy');

define('TOKEN_REFERENCE_CALL_CUSTOMER_MESSAGE','Restaurant manager is trying to contact you. Kindly reach out to nearest manager or counter');

define('PAYMENT_FAIL_MESSAGE','Your payment to order has failed');
define('PAYMENT_SUCCESS_MESSAGE','Your payment to order is successful');

define('PAYMENT_REFUND_REQUESTED','Payment Refund Requested');
define('PAYMENT_FAIL','Payment Failed');
define('PAYMENT_REFUNDED','Payment Refunded');

//define('NUMBER_OF_MEMBER_HEADER_TITLE', 'Heya, you are ordering for');
define('NUMBER_OF_MEMBER_HEADER_TITLE', 'Select the number of persons');

define('SMS_FOR_CONTEST_WINNER',"Congrats! You have received Rs.100 Exclusive Voolsy Credits for Buddy's Pizza - Panchvati, valid for 15 days. Check Voolsy Credits section for more details");
//define('SMS_FOR_CONTEST_WINNER',"Congrats! You have received Rs.100 Exclusive Voolsy Credits for Subway, valid for 10 days. Check Voolsy Credits section for more details");

define('REASON_FOR_FAILURE_TITLE','Reason for failure');
define('REASON_FOR_FAILURE_MESSAGE','Your payment has been declined by your bank. Please contact your bank for any queries. If money has been deducted from your account, your bank will inform us within 48 hrs and we will refund the same');

define('REASON_FOR_FAILURE_MAIL_BTN','Mail us');
define('REASON_FOR_FAILURE_MAIL_MESSAGE','If your payment is deducted, we request to you not to worry, your payment will be refunded within 48 hours.');

define('QR_INVOICE_TITLE', 'Invoice Detail');
define('QR_INVOICE_DESC', 'Do you want to go back to scanning screen ?'); // \n Tap "Yes" to scan QR code and "No" to remain on this screen.

define('ORDER_DETAIL_QR_TITLE',"What's Next");
define('ORDER_DETAIL_QR_DESC',"Kindly show this payment reference token to the manager to settle this payment with your order.");
define('ORDER_DETAIL_QR_PAYMENT_TITLE',"Payment Details");

define('ORDER_DETAIL_QR_PAYMENT_SUCC_TITLE',"Your payment is done successfully at");
define('ORDER_DETAIL_QR_PAYMENT_REFERENCE',"Payment reference token is");

define('SETLLED_NOTIFY_ORDER_TITLE','Order Settled');
define('SETLLED_NOTIFY_ORDER_DESC','Your order has been successfully mapped to the payment made. Kindly go to "Order History" section to view the order detail.');

define("QR_UNDO_TITLE","Undo Invoice");
//define("QR_UNDO_MESSAGE","Payment cannot be done as manager has performed 'Undo Invoice'.");
define("QR_UNDO_MESSAGE","Payment cannot be done as the invoice was recalled.");
define('QR_BRANCH_PAYMENT_SUCCESS_BY_USER','Payment at BRNNM has been received successfully. Your payment reference token is xxxxxx. Kindly mention this number to the manager.');
define('QR_BRANCH_PAYMENT_REFUND_TOKEN','Your payment with reference token no. TOKENNO has been fully refunded. Payment will get refunded to your payment source account');
define('REFER_EARN_LOGO_TITLE','Share Voolsy. Gift rewards.');

define('VERSION_UPDATE_MANDATORY_MESSAGE','You are using an old version of the app that is no longer supported. Please update the app to continue.');

define('SEND_SMS_SENDER','Voolsy');
define('APP_NAME','Voolsy');
define('DOWNLOAD_APP_URL','http://vlsy.in/app'); //vlsy.in/app <http://vlsy.in/app>

// Food Court Message 
define('FOODCOURT_MESSAGE','Please ensure that you are in "XXX"  foodcourt. Press OK to place the order!');
define('SYMBOL_RS','₹');
define('TITLE_TEXT','Recharge Receipt');
define('TRANSACTION_CREDIT_NOTES','Show this slip at counter to pay.');

// Share Screen Message -
//define('REFER_DESC_VOOLSY','If your friend install with your code, you will earn REPLACE_VLSY_CASHBACK and your friend too. Make sure you have verified you and your friend has verified email address.');
define('REFER_DESC_VOOLSY','If your friend installs with your code, your friend will earn REPLACE_VLSY_CASHBACK . You both need to verify your respective email addresses. Happy Gifting.');
//define('SHARE_DESC_VOOLSY','Download Voolsy to order & pay inside restaurant without waiter. Use code REPLACE_REFERRAL_CODE & earn REPLACE_VOOLSY_CASHBACK_AMOUNT. Refer others & earn. More on http://vlsy.in/app');
define('SHARE_DESC_VOOLSY','Download Voolsy to order & pay inside restaurant without waiter.Refer code REPLACE_REFERRAL_CODE & gift Rs 50 to your friends/family. More on http://vlsy.in/app');

define('CASH_AND_CARRY_TEXT','Cash And Carry');

define('RESTRICT_REFUND_MESSAGE', 'Unable to refund please contact customer care');

define('COVER_CHARGE_TITLE','Cover Charge');
define('COVER_CHARGES_TITLE','Cover Charges');

define('ERROR_FOR_OTP_MESSAGE','Unable to send OTP, Please try again later');

define('QR_BRANCH_CODE_AMOUNT_TO_PAY','Amount to pay');
define('QR_BRANCH_CODE_DISCOUNT','Discount');
define('QR_BRANCH_CODE_PAYABLE_AMOUNT','Payable Amount');
define('QR_BRANCH_CODE_AMOUNT_PLACEHOLDER','Amount');

define('REFER_EARN_TITLE',"Refer &\nGift");
define('REFER_EARN_SCREEN_TITLE',"Refer & Gift");

define('REFER_EARN_HOME_PAGE_TITLE',"REFER");
define('REFER_EARN_HOME_PAGE_DESC',"& GIFT CREDITS");

define('SCAN_QR_ENTER_CODE_TITLE', "Can't Scan QR?");
define('SCAN_QR_ENTER_CODE_HINT', "Enter Code");
define('CANT_SCAN_QR','Code: ');

define('NOTE_AFTER_QR_IN_INVOICE_QR_PRINT',"How it works? \n Scan QR Code With Voolsy App \n Avail discounts,if any\n Make instant payment \n\n #BRNDISCOUNT# \n Your payments are safe and secure with us.");

define('PAYTMREFUND','Invalid refund request');

define('BRANCH_QR_PROMOTIONAL_TITLE', "Discount Applicable");
define('BRANCH_QR_PROMOTIONAL_MESSAGE', "Discount/offer is applicable for this outlet");

define('ACCEPT_ORDER_TO_SEND_KIOSK_USER','##BRNNM## has confirmed your order. We will deliver to you in ##MINIT## minutes.');

define('ACCEPT_ORDER_TO_SEND_KIOSK_USER_WITHOUT_MINIT','##BRNNM## has confirmed your order.');


define('REJECT_ORDER_TO_SEND_KIOSK_USER','##BRNNM## has rejected your order. Your ordering amount will be refunded back to your account in 6-7 working days.');
define('SERVED_ORDER_TO_SEND_KIOSK_USER','##BRNNM## has served your order. If not, kindly contact the outlet and show your receipt.');

define('BRANCH_CONFIG_ADD_SUCC','Branch Configuration has been added successfully');
define('BRANCH_CONFIG_UPDATE_SUCC','Branch Configuration record updated successfully');
define('LOCATION_ADD_SUCC','Location has been added successfully');
define('LOCATION_UPDATE_SUCC','Location record updated successfully');
define('LOCATION_NM_EXITS','Display name already exist');

define('PRINTER_CONFIG_ADD_SUCC','Printer Configuration has been added successfully');
define('PRINTER_CONFIG_UPDATE_SUCC','Printer Configuration record updated successfully');

define('KIOSK_CONFIG_ADD_SUCC','Device Configuration has been added successfully');
define('KIOSK_CONFIG_UPDATE_SUCC','Device Configuration record updated successfully');


// Cv Emp Available Or Not If Available in Manager App Get SMS Message 
define('CV_EMP_NOT_FOUND','Kindly check the entered details as we cannot find employee.');
define('CV_EMP_FOUND_TO_SMS','You have placed an order at ##locname## containing approval required items. If not, kindly contact admin stating the same.');
define('CV_EMP_ORDER_OTP_MESSAGE',' ##otp## is the OTP for making payment at ##locname## for order  using recharge amount.');

define('USER_COD_PAYMENT_COMPLETE_SMS','Your Order Id:OIDxxxxxx has been generated successfully  for BRNNM.  Please pay the amount at Cash Counter (if  applicable) and collect your order. Enjoy your Meal.');

define('PENDING_AUTHORIZATION_TITLE','Pending Authorization');
define('PENDING_AUTHORIZATION_MESSAGE','You have new pending autorization.');


define('BYPASS_PAYMENT_MODE','N/A');
define('PAYMENT_MODE_LIST','cash,credit card,credit account,complementary,complimentary,multi,cv,pay later,cod,n/a,bypass');

define('GET_OTP_SMS_KIOSK','##OTPNUMBER## is the OTP to validate your number. It is valid for 15 minutes. Kindly verify to process your order.');
define('GET_OTP_SMS','##OTPNUMBER## is the OTP to activate Voolsy. Code valid for 15 minutes. Kindly ignore if you have not made any request. Enjoy Voolsy :)');


?>