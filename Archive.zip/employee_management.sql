-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Mar 12, 2019 at 12:36 PM
-- Server version: 5.6.35
-- PHP Version: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `employee_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_department`
--

CREATE TABLE `tbl_department` (
  `department_id` int(11) NOT NULL,
  `department_name` varchar(255) NOT NULL COMMENT 'Department Name',
  `status` enum('0','1') NOT NULL DEFAULT '1' COMMENT 'Status : 1 = Active, 0 = Suspend',
  `created` datetime NOT NULL COMMENT 'Department Created Datetime'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_department`
--

INSERT INTO `tbl_department` (`department_id`, `department_name`, `status`, `created`) VALUES
(1, 'HR Team', '1', '2019-03-11 05:03:01'),
(2, 'Accounts', '1', '2019-03-11 05:03:01'),
(3, 'Marketing', '1', '2019-03-11 05:03:01'),
(4, 'Designs', '1', '2019-03-11 05:03:01'),
(5, 'Tech', '1', '2019-03-11 06:15:22'),
(6, 'Operation', '1', '2019-03-11 08:12:03');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_employee`
--

CREATE TABLE `tbl_employee` (
  `employee_id` int(11) NOT NULL,
  `department_id` int(11) NOT NULL COMMENT 'Reference from tbl_department',
  `name` varchar(255) NOT NULL COMMENT 'Employee Name',
  `date_of_birth` datetime NOT NULL COMMENT 'Employee BirthDate',
  `phone_number` varchar(50) NOT NULL COMMENT 'Employee Mobile Number',
  `photo` varchar(255) NOT NULL COMMENT 'Employee Photo',
  `email` varchar(255) NOT NULL COMMENT 'Employee Email',
  `salary` double NOT NULL COMMENT 'Employee Salary',
  `status` enum('0','1') NOT NULL DEFAULT '1' COMMENT 'Employee Status 1 = Active , 0 = Suspend',
  `created_date` datetime NOT NULL COMMENT 'Created Date Time',
  `modified_date` datetime NOT NULL COMMENT 'Modified Date Time'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_employee`
--

INSERT INTO `tbl_employee` (`employee_id`, `department_id`, `name`, `date_of_birth`, `phone_number`, `photo`, `email`, `salary`, `status`, `created_date`, `modified_date`) VALUES
(1, 1, 'Raju', '2019-03-11 00:00:00', '', '', 'raju@test.com', 10000, '1', '2019-03-11 00:00:00', '0000-00-00 00:00:00'),
(3, 5, 'Ramesh', '2019-03-03 00:00:00', '1234567890', '20190312100114.jpeg', 'test@test.com', 1666, '1', '2019-03-12 10:01:14', '0000-00-00 00:00:00'),
(4, 5, 'Ramesh', '2019-03-03 00:00:00', '1234567890', '20190312100327.jpeg', 'test@test.com', 1666, '1', '2019-03-12 10:03:27', '0000-00-00 00:00:00'),
(7, 4, 'gd', '2019-03-01 00:00:00', 'dd', '20190312102957.jpeg', 'd', 0, '1', '2019-03-12 10:29:58', '0000-00-00 00:00:00'),
(8, 4, 'sads', '2019-03-11 00:00:00', 'sss', '20190312103245.jpeg', 'dfd', 0, '1', '2019-03-12 10:32:45', '0000-00-00 00:00:00'),
(9, 6, 'ggg', '2019-03-04 00:00:00', '44545345', '20190312110053.png', 'dfsdf', 0, '1', '2019-03-12 11:00:54', '0000-00-00 00:00:00'),
(10, 0, 'dsfsd', '2019-03-03 00:00:00', 'sdfs', '', 'dsf', 0, '1', '2019-03-12 11:10:58', '0000-00-00 00:00:00'),
(11, 2, 'fdsfs', '2019-03-04 00:00:00', 'sfds', '', 'sfsd', 0, '1', '2019-03-12 11:12:27', '0000-00-00 00:00:00'),
(12, 4, 'sdfds', '2019-03-06 00:00:00', 'sfs', '20190312111358.jpeg', 'sdfs', 0, '1', '2019-03-12 11:13:58', '0000-00-00 00:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_department`
--
ALTER TABLE `tbl_department`
  ADD PRIMARY KEY (`department_id`);

--
-- Indexes for table `tbl_employee`
--
ALTER TABLE `tbl_employee`
  ADD PRIMARY KEY (`employee_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_department`
--
ALTER TABLE `tbl_department`
  MODIFY `department_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `tbl_employee`
--
ALTER TABLE `tbl_employee`
  MODIFY `employee_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;