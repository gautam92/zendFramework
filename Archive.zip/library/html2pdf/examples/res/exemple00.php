<style type="text/Css">
<!--
.test1
{
    border: solid 1px #FF0000;
    background: #FFFFFF;
    border-collapse: collapse;
}
-->
</style>
<page style="font-size: 14px">
   		
   	 	
   	 	
     <hr style="height: 4mm; background: red; >
   
    
</page>