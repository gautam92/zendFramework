<?php
/**
 * This makes our life easier when dealing with paths. Everything is relative
 * to the application root now.
 */
chdir(dirname(__DIR__));

// Setup autoloading
include 'init_autoloader.php';
require 'config/autoload/global_msg.php';
require 'config/autoload/global_flag.php';
require 'config/autoload/global_validation_msg.php';
require 'config/node/node.php';

require 'config/tables/tbl_branch_admin.php';
require 'config/tables/tbl_branch_beacon.php';
require 'config/tables/tbl_branch_category_items.php';
require 'config/tables/tbl_branch_cities.php';
require 'config/tables/tbl_branch_cuisine.php';
require 'config/tables/tbl_branch_employees_type.php';
require 'config/tables/tbl_branch_manager_admin.php';
require 'config/tables/tbl_branch_manager.php'; 
require 'config/tables/tbl_branch_menu_category.php';
require 'config/tables/tbl_branch_menu.php';
require 'config/tables/tbl_branch_table.php';
require 'config/tables/tbl_branch.php';
require 'config/tables/tbl_city.php';
require 'config/tables/tbl_country.php';
require 'config/tables/tbl_coupon_code_types.php';
require 'config/tables/tbl_coupon_code.php';
require 'config/tables/tbl_coupon_codes_used.php';
require 'config/tables/tbl_cuisine_reuest.php';
require 'config/tables/tbl_cuisine.php';
require 'config/tables/tbl_extra_ingredient.php';
require 'config/tables/tbl_landmark.php';
require 'config/tables/tbl_master_taste.php';
require 'config/tables/tbl_order_items_extra_ingredient.php';
require 'config/tables/tbl_order_items.php';
require 'config/tables/tbl_otp_verification.php';

require 'config/tables/tbl_popular_favourite.php';
require 'config/tables/tbl_popular_rating.php';
require 'config/tables/tbl_popular_sales.php';

require 'config/tables/tbl_request_types.php';
require 'config/tables/tbl_restaurant_owner.php';
require 'config/tables/tbl_restaurant.php';
require 'config/tables/tbl_state.php';
require 'config/tables/tbl_suspent_reason_list.php';
require 'config/tables/tbl_user_message.php';
require 'config/tables/tbl_user_notifications.php';
require 'config/tables/tbl_user_order.php';
require 'config/tables/tbl_user_rating_item.php';
require 'config/tables/tbl_user_request.php';
require 'config/tables/tbl_user_type.php';
require 'config/tables/tbl_user.php';
require 'config/tables/tbl_voolsy_users.php';
require 'config/tables/tbl_user_reported_abuse_history.php'; // Ashvin Ahjolia [25-11-2015]


// Run the application!
Zend\Mvc\Application::init(include 'config/application.config.php')->run()->send();

//session_start();


