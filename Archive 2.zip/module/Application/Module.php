<?php

namespace Application;

use Zend\Mvc\ModuleRouteListener;

use Zend\Authentication\Storage;
use Zend\Session\Config\SessionConfig;

use Zend\Session\Storage\ArrayStorage;
use Zend\Session\SessionManager;
use Zend\Session\Storage\StorageInterface;

use Zend\Session\Container;


class Module
{
    public function onBootstrap($e)
    {
        $e->getApplication()->getServiceManager()->get('translator');
        $eventManager        = $e->getApplication()->getEventManager();
		
		
		
        $moduleRouteListener = new ModuleRouteListener();
        $moduleRouteListener->attach($eventManager);
	    $this->bootstrapSession($e);
		//$this->getServiceConfig();
    
	}
	
	public function bootstrapSession($e)
    {
    	
       /* $session = $e->getApplication()
                     ->getServiceManager()
                     ->get('Zend\Session\SessionManager');*/
			$session =  new SessionManager();
        	$session->start();
    	    
    	    $actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
			$_SESSION['redirect_url'] = $actual_link; 
	   		
       // $container = new Container('initialized');
		
		/*if (!isset($container->init)) {
            	
            $serviceManager = $e->getApplication()->getServiceManager();
            $request        = $serviceManager->get('Request');
			
    		$session->regenerateId(true);
            $container->init          = 1;
            $container->remoteAddr    = $request->getServer()->get('REMOTE_ADDR');
            $container->httpUserAgent = $request->getServer()->get('HTTP_USER_AGENT');
			
            $config = $serviceManager->get('Config');
            if (!isset($config['session'])) {
                return;
            }

            $sessionConfig = $config['session'];
            if (isset($sessionConfig['validators'])) {
                $chain   = $session->getValidatorChain();

                foreach ($sessionConfig['validators'] as $validator) {
                    switch ($validator) {
                        case 'Zend\Session\Validator\HttpUserAgent':
                            $validator = new $validator($container->httpUserAgent);
                            break;
                        case 'Zend\Session\Validator\RemoteAddr':
                            $validator  = new $validator($container->remoteAddr);
                            break;
                        default:
                            $validator = new $validator();
                    }

                    $chain->attach('session.validate', array($validator, 'isValid'));
                }
            }
        
		}*/
   
   }
	
    public function getConfig()
    {
        return include __DIR__ . '/config/module.config.php';
    }

    public function getAutoloaderConfig()
    {
        return array(
            'Zend\Loader\StandardAutoloader' => array(
                'namespaces' => array(
                    __NAMESPACE__ => __DIR__ . '/src/' . __NAMESPACE__,
                ),
            ),
        );
    }

}
