<?php
namespace Employeemgt\Controller;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Employeemgt\Model\Employeemgt;

use Zend\Authentication\Storage;
use Zend\Session\Config\SessionConfig;
use Zend\Session\Storage\ArrayStorage;
use Zend\Session\SessionManager;
use Zend\Session\Storage\StorageInterface;
use Zend\Validator\EmailAddress;
use Zend\Db\Sql\Select;
use Zend\Paginator\Paginator;
use Zend\Paginator\Adapter\Iterator as paginatorIterator;
use Zend\Stdlib\RequestInterface as Request;
use Zend\Stdlib\ResponseInterface as Response;
use Zend\Mvc\MvcEvent;
use PHPExcel;
use PHPExcel_IOFactory;
@session_start();

class CampaignController extends AbstractActionController
{
	
/* *
 * DEVELOPED BY :: NIKUNJ PATEL [ NP :: 31-07-2018 ]
 * DESCRIPTION :: FOR AJAX RESPONSE
 * */	
	public function sendResponse($status,$message='',$result = '')
	{
		$response = array();
		$response['STATUS'] = $status;
		$response['MESSAGE'] = trim($message);
		if($result != ''){
			$response['RESULT'] = $result;
		}
		echo json_encode($response);
		die();
	}
// // ~ ----------------------------------------------------------------------------------------------------------------- ~ // //
	public function getCommonTable(){
        $sm = $this->getServiceLocator();
        $this->CommonTable = $sm->get('Accountadmin\Model\CommonTable');
        return $this->CommonTable;
    }
    public function getAccountadminTable() {
		$sm = $this -> getServiceLocator();
		$this -> Accountadmin = $sm -> get('Accountadmin\Model\AccountadminTable');
		return $this -> Accountadmin;
	}
    public function getCampaignTable(){
        $sm = $this->getServiceLocator();
        $this->CampaignTable = $sm->get('Accountadmin\Model\CampaignTable');
        return $this->CampaignTable;
    }
    public function getSmssettingsTable(){
        $sm = $this->getServiceLocator();
        $this->SmssettingsTable = $sm->get('Accountadmin\Model\SmssettingsTable');
        return $this->SmssettingsTable;
    }
// // ~ ----------------------------------------------------------------------------------------------------------------- ~ // //
    public function indexAction() {
    	return $this -> redirect() -> toRoute('employeemgt', array('action' => 'dashboard'));
    	die();
    }
// // ~ ----------------------------------------------------------------------------------------------------------------- ~ // //
/* *
 * DEVELOPED BY :: NIKUNJ PATEL [ NP :: 31-07-2018 ]
 * DESCRIPTION :: CAMPAIGN MANAGEMENT / CONTACT LIST 
 * */	
	public function listAction()
	{
		$this->isLogin();
		$request = $this->getRequest();
		$vData = array();
		$vData['resultSet'] = $this->getCampaignTable()->getContactList();
		// //~
		$check_sms_ac = $this->getAccountadminTable()->checkSMSAccount();
		$is_sms_ac_active = '0';
		if(isset($check_sms_ac['account_auth_key']) && !empty($check_sms_ac['account_auth_key'])) {
			$is_sms_ac_active = '1';
		}
		$vData['is_sms_ac_active'] = $is_sms_ac_active;
		return $vData;
	}
/* *
 * DEVELOPED BY :: NIKUNJ PATEL [ NP :: 01-08-2018 ]
 * DESCRIPTION :: SEND SMS FROM THE LIST PAGE
 * */	
	public function sendSMSAction()
	{
		$this->isLogin();
		$request = $this->getRequest();
		if($request->ispost())
		{
			$check_sms_ac = $this->getAccountadminTable()->checkSMSAccount();
			if(isset($check_sms_ac['account_auth_key']) && !empty($check_sms_ac['account_auth_key']))
			{
				$resultAry = $this->getCampaignTable()->sendSMStoList($request->getpost());
				$sms_balance = 0;
				$sms_data = $this->getSmssettingsTable()->checksmsAccountRequest();
				if(isset($sms_data['total_sms_credit']) && !empty($sms_data['total_sms_credit'])) {
					$sms_balance = (int) $sms_data['total_sms_credit'];
				}
				if(isset($resultAry['sms_data']) && !empty($resultAry['sms_data']) && count($resultAry['sms_data'])>0)
				{
					$count = '0';
					if(isset($resultAry['sms_count']) && !empty($resultAry['sms_count'])) {
						$count = $resultAry['sms_count'];
					}
					$sms_balance = 0;
					$sms_data = $this->getSmssettingsTable()->checksmsAccountRequest();
					if(isset($sms_data['total_sms_credit']) && !empty($sms_data['total_sms_credit'])) {
						$sms_balance = (int) $sms_data['total_sms_credit'];
					} else {
						$this->sendResponse('0',"Something went wrong on sms balance check");
						die();
					}
					if($count <= $sms_balance) {
						$postData = array();
						$postData['organization_id'] = trim($_SESSION['organization_id']);
						$postData['message_list'] = json_encode($resultAry['sms_data']);
						$fields_string = '';
						foreach($postData as $key=>$value) { $fields_string .= $key.'='.$value.'&'; }
						rtrim($fields_string, '&');
						// //~ echo "<br> :: ".NODE_IP_WITH_PORT."/sendSms";die();
						$curl = curl_init(NODE_IP_WITH_PORT."/sendSms");
						curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
						curl_setopt($curl, CURLOPT_POST, true);
						curl_setopt($curl, CURLOPT_POSTFIELDS, $fields_string);
						$curl_response = curl_exec($curl);
						if ($curl_response === false) {
							$info = curl_getinfo($curl);
							curl_close($curl);
							$this->sendResponse('0',"Error :: Something Wrong On Server Response!!");
							die();
						}
						curl_close($curl);
						$response = json_decode($curl_response,true);
						// //~
						if($response['STATUS'] == '1') {
							// $this->sendResponse('1',$response['MESSAGE']);
							$this->sendResponse('1','SMS sent to '.$count.' contact/s');
						}
						else {
							if(isset($response['MESSAGE'])) {
								$this->sendResponse('0',$response['MESSAGE']);	
							} else {
								$this->sendResponse('0',"Something went wrong");
							}
						}
					}
					else {
						$this->sendResponse('0',"SMS balance is insufficient");
					}
				}
				else {
					$this->sendResponse('0',"Contacts not found.");
				}
				die();
			}
			else {
				$this->sendResponse('0',"Please activate your sms account");
			}
		}	
		die();
	}
	public function deleteContacsAction()
	{
		$this->isLogin();
		$request = $this->getRequest();
		$deletedIDs = json_decode($request->getpost()->deletedIDs);
		//echo "<pre>"; print_r($deletedIDs); exit;
		$data = array();
		if(empty($deletedIDs)) {
			$data['status'] = '0';
			$data['msg'] = GLOBAL_ERROR_MESSAGE;
		} else {		
			$data['datatable_array'] = $this->getCampaignTable()->deleteContacts($deletedIDs);
			$data['status'] = '1';
			$data['msg'] = 'Contact list has been deleted successfully';
		}
		echo json_encode($data); exit;
	}		
// // ~ ----------------------------------------------------------------------------------------------------------------- ~ // //
/* *
 * DEVELOPED BY :: NIKUNJ PATEL [ NP :: 01-08-2018 ]
 * DESCRIPTION :: CAMPAIGN MANAGEMENT -> ADD/EDIT CONTACT  
 * */	
	public function contactAction()
	{
		$this->isLogin();
		$request = $this->getRequest();
		if($request->ispost())
		{
			$is_exist = $this->getCampaignTable()->chkContactListName($request->getpost());
			if(!empty($is_exist)) {
				$this->sendResponse('0',"Contact list name already exist");
			}
			else {
				$h_role_id = $this->getRequest()->getPost('h_role_id','0');
				if(!empty($h_role_id)) {
					$result = $this->getCampaignTable()->updateContactList($request->getpost());
				} else {
					$result = $this->getCampaignTable()->saveContactList($request->getpost());	
				}
				if(!empty($result)) {
					if($result == '2') {
						$_SESSION['id_error_msg'] = 'Contact list was created but something went wrong in import contact';
					} else {
						$_SESSION['id_success_msg'] = 'Contact list saved successfully';
					}
					$this->sendResponse('1',"SUCCESS");
				}
				else {
					$this->sendResponse('0',"Something went wrong");
				}
			}
			die();
		}
		$vData = array();
		// //~
		$vData['form_list'] = $this->getCampaignTable()->getFormList();
		$form_column = array();
		foreach ($vData['form_list'] as $key => $value) {
			$tmpAry = array();
			foreach ($value['sign_in_fields_array'] as $key_1 => $value_1) {
				$tmpAry[$value_1['form_key_id']] = $value_1['label'];
			}
			if(!empty($tmpAry) && count($tmpAry)>0) {
				$form_column[$value['signin_flow_id']]['signin_flow_id'] = $value['signin_flow_id'];
				$form_column[$value['signin_flow_id']]['visitor_type_name'] = $value['visitor_type_name'];
				$form_column[$value['signin_flow_id']]['is_visitor_sign_out_applicable'] = $value['is_visitor_sign_out_applicable'];
				$form_column[$value['signin_flow_id']]['columns_data'] = $tmpAry;
			}
		}
		$vData['form_column'] = $form_column;
		// //~
		$vData['data_list'] = array();
		$id = $this->params('id');
		if(!empty($id)) {
			$id = fnDecodeData($id);
			$contact_data = $this->getCampaignTable()->getContactListData($id);
			$contact_data['signin_flow_names'] = isset($form_column[$contact_data['signin_flow_ids']]['visitor_type_name'])?$form_column[$contact_data['signin_flow_ids']]['visitor_type_name']:"-";
			$vData['data_list'] = $contact_data;
		}
		// echo "<pre>";
		// 	print_r($vData);
		// die();
		return $vData;
	}
// // ~ ----------------------------------------------------------------------------------------------------------------- ~ // //
	public function viewcontactsAction()
	{
		$this->isLogin();
		$request = $this->getRequest();
		$id = $this->params('id');
		if(empty($id)) {
			return $this->redirect()->toRoute('accountadmin', array('action'=>'index') );
		}
		$check_sms_ac = $this->getAccountadminTable()->checkSMSAccount();
		$is_sms_ac_active = '0';
		if(isset($check_sms_ac['account_auth_key']) && !empty($check_sms_ac['account_auth_key'])) {
			$is_sms_ac_active = '1';
		}
		$id = fnDecodeData($id);
		$vData['role_id'] = $id;
		$filter_data = array();
		$filter_data['id'] = $id;
		$filter_data['is_sms_ac_active'] = $is_sms_ac_active;
		$resultData = $this->getCampaignTable()->viewContactData($filter_data);
		if(!(isset($resultData['status']) && $resultData['status'] == '1')) {
			return $this->redirect()->toRoute('accountadmin', array('action'=>'index') );
		}
		$vData['contact_list'] = $resultData['contact_list'];
		$vData['columns_data'] = $resultData['column'];
		$vData['contactList'] = $resultData['data'];
		$vData['is_sms_ac_active'] = $is_sms_ac_active;
		return $vData;
	}

// // ~ ----------------------------------------------------------------------------------------------------------------- ~ // //
/* *
 * DEVELOPED BY :: NIKUNJ PATEL [ NP :: 24-08-2018 ]
 * DESCRIPTION :: CAMPAIGN MANAGEMENT / CREATE CAMPAIGN 
 * */	
	public function campaignlistAction()
	{
		$this->isLogin();
		$request = $this->getRequest();
		$vData = array();
		$vData['resultSet'] = $this->getCampaignTable()->getCampaignList();
		// $check_sms_ac = $this->getAccountadminTable()->checkSMSAccount();
		return $vData;
	}
/* *
 * DEVELOPED BY :: NIKUNJ PATEL [ NP :: 24-08-2018 ]
 * DESCRIPTION :: CAMPAIGN MANAGEMENT / CREATE CAMPAIGN / DELETE CAMPAIGN
 * */	
	public function deleteCampaignAction()
	{
		$this->isLogin();
		$request = $this->getRequest();
		$compaign_id = $this->getRequest()->getPost('compaign_id','');
		if(!empty($compaign_id)) {
			$result = $this->getCampaignTable()->deleteCampaign($compaign_id);	
			if(!empty($result)) {
				$data_list = $this->getCampaignTable()->getCampaignList();	
				$this->sendResponse('1',"Campaign deleted successfully",$data_list);
			}
			else {
				$this->sendResponse('0',"Something went wrong");
			}
		}
		else {
			$this->sendResponse('0',"Something went wrong");
		}
		die();
	}
/* *
 * DEVELOPED BY :: NIKUNJ PATEL [ NP :: 24-08-2018 ]
 * DESCRIPTION :: CAMPAIGN MANAGEMENT / CREATE CAMPAIGN 
 * */	
	public function campaignAction()
	{
		$this->isLogin();
		$request = $this->getRequest();
		if($request->ispost())
		{
			$is_exist = $this->getCampaignTable()->chkCampaignListName($request->getpost());
			if(!empty($is_exist)) {
				$this->sendResponse('0',"Campaign name already exist");
			}
			else {
				$result = $this->getCampaignTable()->saveCampaignList($request->getpost());	
				// echo "<bR> :: ".$result;
				if(!empty($result)) {
					if($result == '2') {
						$_SESSION['id_error_msg'] = 'Campaign saved successfully but something went wrong in send SMS';
					} else {
						$_SESSION['id_success_msg'] = 'Campaign saved successfully';
					}
					$this->sendResponse('1',"SUCCESS");
				}
				else {
					$this->sendResponse('0',"Something went wrong");
				}
			}
			die();
		}
		$vData = array();	
		$clist_data = $this->getCampaignTable()->getContactListForCampaign();
		$vData['status'] = $clist_data['status'];
		$vData['contact_list'] = $clist_data['contact_list'];
		$vData['phone_field'] = $clist_data['phone_field'];
		$vData['date_field'] = $clist_data['date_field'];
		$vData['data_list'] = array();
		$id = $this->params('id');
		if(!empty($id)) {
			$id = fnDecodeData($id);
			$compaign_data = $this->getCampaignTable()->getCampaignDetail($id);
			$vData['data_list'] = $compaign_data;
		}
		// echo "<pre>";
		// 	print_r($vData);
		// 	print_r($vData);
		// die();
		return $vData;
	}
// // ~ ----------------------------------------------------------------------------------------------------------------- ~ // //	
}
