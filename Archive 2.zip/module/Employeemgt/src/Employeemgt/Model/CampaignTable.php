<?php
namespace Employeemgt\Model;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\Adapter\Driver\ResultInterface;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\Sql\Select;
use Zend\Db\Sql\Where;
use Zend\Db\Sql\Insert;
use Zend\Db\Adapter\AdapterInterface;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Db\Sql\Sql;
use Zend\Db\Sql\Update;
use Zend\Db\Sql\Delete;
use Zend\Validator;
use Zend\Validator\EmailAddress;
use Zend\Validator\File\Md5;
use Zend\Validator\Db\NoRecordExists;
use Zend\Mail;
use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Adapter\Driver\DriverInterface;
use Zend\Db\Sql\Expression; 
use Zend\Db\Sql\Predicate\NotIn;
// Use Pagination content.
use Zend\Paginator\Paginator;

class CampaignTable extends AbstractTableGateway
{

    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->resultSetPrototype->setArrayObjectPrototype(new Employeemgt());
        $this->initialize();
    }
// // ~ ----------------------------------------------------------------------------------------------------------------- ~ // //
/* *
 * DEVELOPED BY :: NIKUNJ PATEL [ NP :: 31-07-2018 ]
 * DESCRIPTION :: FOR CONTACT LIST PAGE
 * */   
    public function getContactList()
    {
        $resultAry['AllData'] = array();
        // //~
        $sql ="SELECT r.*,sf.`visitor_type_name` FROM tbl_location_contact_list_role r 
            INNER JOIN `tbl_visitor_signin_flow` sf ON r.`signin_flow_ids` = sf.`signin_flow_id`
            WHERE r.`organization_id` = '".trim($_SESSION['organization_id'])."' AND r.`location_id` = '".trim($_SESSION['location_id'])."' AND r.`is_active` = '1' ";
        // echo "<pre>".$sql; die();    
        $statement = $this->adapter->query($sql); 
        $result = $statement->execute();
        if(count($result)>0)
        {
            $resultData = array();
            $role_ids_array = array();
            foreach ($result as $key => $value) {
                $resultData[] = $value;
                $role_ids_array[] = $value['location_contact_list_role_id'];
            }
            // //~
            $contact_count = array();
            $sql_1 ="SELECT `location_contact_list_role_id`, count(*) as `total_count` FROM tbl_location_contact_list_history WHERE organization_id = '".trim($_SESSION['organization_id'])."' AND location_id = '".trim($_SESSION['location_id'])."' AND `location_contact_list_role_id` IN('".implode("','", $role_ids_array)."') GROUP BY `location_contact_list_role_id` ";
            $statement_1 = $this->adapter->query($sql_1); 
            $result_1 = $statement_1->execute();
            foreach ($result_1 as $key => $value) {
               $contact_count[$value['location_contact_list_role_id']] = $value['total_count'];
            }
            // //~
            foreach ($resultData as $key => $value)
            {
                $count = (isset($contact_count[$value['location_contact_list_role_id']]) && !empty($contact_count[$value['location_contact_list_role_id']]))?$contact_count[$value['location_contact_list_role_id']]:'0';
                $tmpAry = array();
                $tmpAry[] = $value['location_contact_list_role_id'];
                $tmpAry[] = '<a href="'.MODULE_ROUTE_ACCOUNTADMIN_URL.'/campaign/contact/'.fnEncodeData($value['location_contact_list_role_id']).'">'.$value['contact_name'].'</a>';
                $tmpAry[] = (!empty($value['description'])?$value['description']:'-');
                $tmpAry[] = (!empty($value['visitor_type_name'])?$value['visitor_type_name']:'-');
                $tmpAry[] = (!empty($count))?'<a href="'.MODULE_ROUTE_ACCOUNTADMIN_URL.'/campaign/viewcontacts/'.fnEncodeData($value['location_contact_list_role_id']).'">'.$count." Contacts </a>":"-";
               
                $datearray= array();
                $datearray['date']=$value['created_on'];
                $datearray['mode']='IST';
                $created_on = date("d/m/Y h:i A",strtotime(DateTimeAsPerTimeZone($datearray)));

                $tmpAry[] = $created_on;
                $tmpAry[] = '<a href="javascript:void(0);" class="cls_send_sms" data-count="'.$count.'" data-roleid="'.$value['location_contact_list_role_id'].'" >Send SMS</a> ';
                $resultAry['AllData'][] = $tmpAry;
            }
        }
        return $resultAry;
    }
/* *
 * DEVELOPED BY :: NIKUNJ PATEL [ NP :: 01-08-2018 ]
 * DESCRIPTION :: SEND SMS FROM THE LIST PAGE
 * */    
    public function sendSMStoList($pData)
    {
        $resultAry = array();
        if(!count($pData)>0) {
            return $resultAry;
        }
        if(!(isset($pData['h_role_id']) && !empty($pData['h_role_id']))) {
            return $resultAry;   
        }
        if(!(isset($pData['sms_contain']) && !empty($pData['sms_contain']))) {
            return $resultAry;   
        }
        $h_role_id = (int) $pData['h_role_id'];
        $sms_contain = trim($pData['sms_contain']);
        // //~
        $sql ="SELECT h.`location_contact_list_history_id`, h.`full_name`, h.`mobile_number`, h.`email_address`, 
            (SELECT count(*) FROM `tbl_location_contact_list_history` h1 WHERE h1.`mobile_number` = h.`mobile_number` AND h1.`is_user_block` = '1') as `block_count`
            FROM `tbl_location_contact_list_history` h 
            WHERE h.`organization_id` = '".trim($_SESSION['organization_id'])."' AND h.`location_id` = '".trim($_SESSION['location_id'])."' AND h.`location_contact_list_role_id` = '".$h_role_id."' AND h.`is_user_block` != '1' ";
        // echo "<pre>".$sql; die();    
        $statement = $this->adapter->query($sql); 
        $result = $statement->execute();
        // //~
        $str_pos = stripos($sms_contain,"##custname##");
        if($str_pos === false) {
            $resultAry[0]['message'] = $sms_contain;
            $resultAry[0]['mobile_number'] = array();
        }
        $n = 0;
        foreach ($result as $key => $value)
        {
            if(!empty($value['mobile_number']) && empty($value['block_count']))
            {
                if($str_pos === false) {
                    $resultAry[0]['mobile_number'][] = $value['mobile_number'];
                    $n++;
                }
                else {
                    $name = (!empty($value['full_name']))?$value['full_name']:'';
                    $flag_sms_msg = str_ireplace('##custname##',$name,$sms_contain);
                    $tmpAry = array();
                    $tmpAry['message'] = $flag_sms_msg;
                    $tmpAry['mobile_number'][] = $value['mobile_number'];
                    $resultAry[] = $tmpAry;
                    $n++;
                }
            }
        }
        $finalAry = array();
        $finalAry['sms_count'] = $n;
        $finalAry['sms_data'] = array();
        if(!empty($n) && count($n)>0) {
            $finalAry['sms_data'] = $resultAry;
        }
        return $finalAry;
    }
    public function deleteContacts($deleteIDs)
    {
        foreach($deleteIDs as $k=>$v) {
            if(!empty($k) && $v == '1') {
                // Contact Role Deleled //
                $del_sql ="DELETE FROM `tbl_location_contact_list_role` WHERE `location_contact_list_role_id` = '".$k."' ";
                $del_statement = $this->adapter->query($del_sql);
                $del_result = $del_statement->execute();
                
                // Contact History Deleled //
                $delete ="DELETE FROM `tbl_location_contact_list_history` WHERE `location_contact_list_role_id` = '".$k."' ";
                $statement = $this->adapter->query($delete);
                $statement->execute();
            }
        }
        return $this->getContactList();
    }
// // ~ ----------------------------------------------------------------------------------------------------------------- ~ // //
/* *
 * DEVELOPED BY :: NIKUNJ PATEL [ NP :: 01-08-2018 ]
 * DESCRIPTION :: GET THE FORM LIST FOR ADD/EDIT CONTACT
 * */   
    public function getFormList()
    {
        $resultAry = array();
        $sql ="SELECT sf.*, vt.`is_visitor_sign_out_applicable` FROM `tbl_visitor_signin_flow` sf
            INNER JOIN `tbl_location_visitor_type` vt ON sf.`location_visitor_type_id` = vt.`location_visitor_type_id`
            WHERE sf.`organization_id` = '".trim($_SESSION['organization_id'])."' AND sf.`location_id` = '".trim($_SESSION['location_id'])."' AND sf.`is_active` = '1' ORDER BY sf.`visitor_type_name` ASC ";
        $statement = $this->adapter->query($sql); 
        $result = $statement->execute();
        if(count($result)>0)
        {
            $sql_1 ="SELECT `master_form_field_type_id`,`parent_id`,`form_field_type_name`,`display_reference_name` FROM tbl_master_form_field_type ";
            $statement_1 = $this->adapter->query($sql_1); 
            $result_1 = $statement_1->execute();
            $field_array = array();
            foreach ($result_1 as $key => $value) {
                $field_array[$value['master_form_field_type_id']] = $value;
            }
            // //~
            $host_data = array();
            foreach ($result as $key => $value)
            {
                $flagAry = array();
                $flagAry = json_decode($value['sign_in_fields'],true);
                foreach ($flagAry as $key_1 => $value_1)
                {
                    // $location_id = $value['location_id'];
                    $form_field_type_id = (!empty($value_1['master_form_field_parent_id']))?$value_1['master_form_field_parent_id']:$value_1['master_form_field_type_id'];
                    $value_1['form_field_type_array'] = (isset($field_array[$form_field_type_id]))?$field_array[$form_field_type_id]:array();
                    if($value_1['is_fullnm1_email2_mobilenm3'] == '4') {
                        if(!isset($host_data[$value['location_id']])) {
                            $sql_2 ="SELECT `location_employees_id`,`first_name`,`last_name`,`email`,`mobile_number` FROM tbl_location_employees 
                                WHERE organization_id = '".trim($_SESSION['organization_id'])."' AND location_id = '".trim($_SESSION['location_id'])."' AND `master_employee_role_id` = '6' AND `is_active` = '1' ";
                            $statement_2 = $this->adapter->query($sql_2); 
                            $result_2 = $statement_2->execute();
                            $tmpAry = array();
                            foreach ($result_2 as $key_2 => $value_2) {
                                $value_2['id'] = $value_2['location_employees_id'];
                                $value_2['title'] = trim($value_2['first_name']." ".$value_2['last_name']);
                                $value_2['full_name'] = trim($value_2['first_name']." ".$value_2['last_name']);
                                $value_2['is_default_selection'] = '0';
                                $tmpAry[] = $value_2;
                            }
                            $host_data[$value['location_id']] = $tmpAry;
                        }
                        $value_1['dropdown_or_radio_list'] = $host_data[$value['location_id']];
                    }
                    $value['sign_in_fields_array'][$value_1['form_key_id']] = $value_1;
                }   
                $resultAry[] = $value;
            }
        }
        // echo "<pre>";
        //     print_r($resultAry);
        // die();
        return $resultAry;
    }
/* *
 * DEVELOPED BY :: NIKUNJ PATEL [ NP :: 01-08-2018 ]
 * DESCRIPTION :: GET THE FORM LIST DETAIL
 * */    
    public function getContactListData($role_id='')
    {
        $resultAry = array();
        if(!empty($role_id)) {
            $sql ="SELECT * FROM tbl_location_contact_list_role 
                WHERE organization_id = '".trim($_SESSION['organization_id'])."' AND location_id = '".trim($_SESSION['location_id'])."' AND `location_contact_list_role_id` = '".$role_id."' ";
            $statement = $this->adapter->query($sql); 
            $result = $statement->execute();
            if(count($result)>0) {
                $resultAry = $result->current();
                $tmpAry = json_decode($resultAry['form_wise_json_role'],true);
                $resultAry['form_wise_array'] = array();
                foreach ($tmpAry as $key => $value) {
                    $resultAry['form_wise_array'][$value['signin_flow_id']] = $value;
                }
            }
        }
        return $resultAry;
    }
/* *
 * DEVELOPED BY :: NIKUNJ PATEL [ NP :: 01-08-2018 ]
 * DESCRIPTION :: CHECK THE LIST NAME IS ALREADY EXIST OR NOT
 * */   
    public function chkContactListName($pData)
    {
        $where_condition = '';
        if(isset($pData['h_role_id']) && !empty($pData['h_role_id'])){
            $where_condition = " AND `location_contact_list_role_id` != '".$pData['h_role_id']."' ";
        } 
        $sql ="SELECT * FROM tbl_location_contact_list_role 
            WHERE organization_id = '".trim($_SESSION['organization_id'])."' AND location_id = '".trim($_SESSION['location_id'])."' AND contact_name = '".addslashes($pData['contact_list_name'])."' ".$where_condition." ";
        $statement = $this->adapter->query($sql); 
        $result = $statement->execute();
        if(count($result)>0) {
            return true;
        }
        else {
            return false;
        }
    }
/* *
 * DEVELOPED BY :: NIKUNJ PATEL [ NP :: 01-08-2018 ]
 * DESCRIPTION :: FOR SAVE THE CONTACT IN ADD/EDIT EHT CONTACT LIST.
 * */    
    public function saveContactList($pData)
    {
        $resultFlag = 0;
        if(!count($pData)>0) {
            return $resultFlag;
        }
        if(!(isset($pData['contact_list_name']) && !empty($pData['contact_list_name']))) {
            return $resultFlag;   
        }
        // echo "<pre>";
        //     print_r($pData);
        // die();
        $date = date('Y-m-d H:i:s');
        // //~
        $h_role_id = 0;
        if(isset($pData['h_role_id']) && !empty($pData['h_role_id'])) {
            $h_role_id = $pData['h_role_id'];
        }
        $contact_list_name = trim($pData['contact_list_name']);
        $description = trim($pData['contact_list_desc']);
        $is_auto_update = '0';
        if(isset($pData['auto_update']) && !empty($pData['auto_update'])) {
            $is_auto_update = '1';
        }
        $is_create_contact_list = '0';
        if(isset($pData['create_contact']) && !empty($pData['create_contact'])) {
            $is_create_contact_list = '1';
        }
        $is_all_customer = '1';
        if(isset($pData['is_all_customer']) && $pData['is_all_customer'] == '2') {
            $is_all_customer = '0';
        }
        $signin_flow_ids = '';
        if(isset($pData['signin_flow_id']) && !empty($pData['signin_flow_id'])) {
            $signin_flow_ids = trim($pData['signin_flow_id']);
        }
        else {
            return $resultFlag;
        }
        $columns_for_this_list = '';
        $selected_col_ary = array();
        $columns_for_this_list_ary = array();
        if(isset($pData['columns_for_this_list']) && count($pData['columns_for_this_list'])>0 && isset($pData['h_sign_in_fields']) && !empty($pData['h_sign_in_fields']) ) {
            $selected_col_ary = $pData['columns_for_this_list'];
            $columns_for_this_list = implode(',',$selected_col_ary);
            $tmp_ary = json_decode($pData['h_sign_in_fields'],true);
            foreach ($tmp_ary as $key => $value) {
                if(in_array($value['label'], $selected_col_ary)) {
                    $columns_for_this_list_ary[] = $value;
                }
            }
            if(in_array('Sign In', $selected_col_ary) || in_array('Sign Out', $selected_col_ary))
            {
                $tmp_fields_val = array(
                    'form_key_id' => 0,
                    'label' => '',
                    'place_holder' => '',
                    'is_display_field' => '0',
                    'is_display_pwd_format' => '0',
                    'signin_flow_id' => '0',
                    'sequence' => '0',
                    'is_search_sign_out_for' => '0',
                    'is_required' => '0',
                    'validation_message' => '',
                    'is_fullnm1_email2_mobilenm3' => '0',
                    'is_default_field' => '0',
                    'master_form_field_type_id' => '6',
                    'master_form_field_parent_id' => '0',
                    'is_dropdown_search_applicable' => '0',
                    'is_singledropdown1_multiselection2' => '0',
                    'search_form_key' => array(),
                    'display_dropdown_key' => '',
                    'dropdown_or_radio_list' => array(),
                );
                if(in_array('Sign In', $selected_col_ary)) {
                    $tmp_ary_1 = $tmp_fields_val;
                    $tmp_ary_1['form_key_id'] = 1001;
                    $tmp_ary_1['sequence'] = '1001';
                    $tmp_ary_1['label'] = 'Sign In';
                    $tmp_ary_1['place_holder'] = 'Sign In';
                    $tmp_ary_1['validation_message'] = 'Sign In';
                    $columns_for_this_list_ary[] = $tmp_ary_1;
                }
                if(in_array('Sign Out', $selected_col_ary)) {
                    $tmp_ary_1 = $tmp_fields_val;
                    $tmp_ary_1['form_key_id'] = 1002;
                    $tmp_ary_1['sequence'] = '1002';
                    $tmp_ary_1['label'] = 'Sign Out';
                    $tmp_ary_1['place_holder'] = 'Sign Out';
                    $tmp_ary_1['validation_message'] = 'Sign Out';
                    $columns_for_this_list_ary[] = $tmp_ary_1;
                }
            }
        }
        else {
            return $resultFlag;
        }
        $columns_for_this_list_json = json_encode($columns_for_this_list_ary);
        $unique_user_fields_name = '';
        if(isset($pData['unique_user_fields_name']) && count($pData['unique_user_fields_name'])>0 ) {
            $unique_user_fields_name = implode(',',$pData['unique_user_fields_name']);
        }
        $rule_option = '0';
        if(isset($pData['rule_option']) && $pData['rule_option'] == '1') {
            $rule_option = '1';
        }
        $json_array = array();
        if(isset($pData['form_option_json']) && count($pData['form_option_json'])>0 && empty($is_all_customer))
        {
            foreach ($pData['form_option_json'] as $key => $value)
            {
                $signin_flow_id = $key;
                $tmpAry = array();
                $tmpAry['signin_flow_id'] = $signin_flow_id;
                $tmpAry['is_all_rule_satisfy'] = $rule_option;
                $tmpAry['is_selected'] = '1';
                $tmpAry['sign_in_fields'] = array();
                foreach ($value as $key_1 => $value_1)
                {
                    $form_option = json_decode($value_1,true);
                    if(!empty($form_option) && count($form_option))
                    {
                        $master_form_field_type_id = 0;
                        if(isset($form_option['form_field_type_array']['master_form_field_type_id']) && !empty($form_option['form_field_type_array']['master_form_field_type_id'])) {
                            $master_form_field_type_id = $form_option['form_field_type_array']['master_form_field_type_id'];
                        }
                        $flagAry = array();
                        $flagAry['form_key_id'] = $form_option['form_key_id'];
                        $flagAry['label'] = $form_option['label'];
                        $flagAry['place_holder'] = $form_option['place_holder'];
                        $flagAry['signin_flow_id'] = $signin_flow_id;
                        $flagAry['is_search_sign_out_for'] = !empty($form_option['is_search_sign_out_for'])?$form_option['is_search_sign_out_for']:'0';
                        $flagAry['master_form_field_type_id'] = $form_option['master_form_field_type_id'];
                        $flagAry['master_form_field_parent_id'] = $form_option['master_form_field_parent_id'];
                        if(isset($form_option['is_fullnm1_email2_mobilenm3'])) {
                            $flagAry['is_fullnm1_email2_mobilenm3'] = $form_option['is_fullnm1_email2_mobilenm3'];
                        }
                        $flagAry['is_singledropdown1_multiselection2'] = $form_option['is_singledropdown1_multiselection2'];
                        $flagAry['display_dropdown_key'] = ((in_array($master_form_field_type_id,array('3','4')))?'title':'');
                        if($master_form_field_type_id == '3' && isset($form_option['display_dropdown_key']) && !empty($form_option['display_dropdown_key'])) {
                            $flagAry['display_dropdown_key'] = $form_option['display_dropdown_key'];
                        }
                        $flagAry['response_value'] = array();
                        if(isset($pData['form_option_value'][$key][$key_1])) {
                            $flagAry['response_value'] = $pData['form_option_value'][$key][$key_1];
                            if($master_form_field_type_id == '6' && (!empty($flagAry['response_value'][0]) && !empty($flagAry['response_value'][1])) ) {
                                $flagAry['response_value'][0] = date('Y-m-d', strtotime(str_replace('/', '-', $flagAry['response_value'][0])));
                                $flagAry['response_value'][1] = date('Y-m-d', strtotime(str_replace('/', '-', $flagAry['response_value'][1])));
                            }
                        }
                        $tmpAry['sign_in_fields'][] = $flagAry;
                    }
                }
                if(!empty($tmpAry['sign_in_fields']) && count($tmpAry['sign_in_fields'])>0) {
                    $json_array[] = $tmpAry;
                }
            }
        }
        $form_wise_json_role = '';
        if(!empty($json_array) && count($json_array)> 0) {
            $form_wise_json_role = json_encode($json_array);
        }
        $resultFlag = 1;
        $dataArray = array(
            'organization_id' => $_SESSION['organization_id'],
            'location_id' => $_SESSION['location_id'],
            'contact_name' => $contact_list_name,
            'description' => $description,
            'is_autoupd_visitor_entries_applicable' => $is_auto_update,
            'is_create_contact_list' => $is_create_contact_list,
            'is_all_customer' => $is_all_customer,
            'signin_flow_ids' => $signin_flow_ids,
            'form_wise_json_role' => $form_wise_json_role,
            'columns_for_this_list' => $columns_for_this_list,
            'columns_for_this_list_json' => $columns_for_this_list_json,
            'unique_user_fields_name' => $unique_user_fields_name,
            'is_active' => '1',
            'is_modified_voonotes' => '0',
            'modified_on' => $date,
            'modified_by' => $_SESSION['accountpanel_user_id']
        );
        $dataArray['is_created_voonotes'] = '0';
        $dataArray['created_on'] = $date;
        $dataArray['created_by'] = $_SESSION['accountpanel_user_id'];
        // echo "<pre>";
        //     print_r($dataArray);
        //     print_r($pData);
        // die();
        // //~
        $insert = new Insert('tbl_location_contact_list_role');
        $insert->values($dataArray);
        $statment = $this->adapter->createStatement();
        $insert->prepareStatement($this->adapter, $statment);
        $result = $statment->execute();     
        $location_contact_list_role_id = $this->adapter->getDriver()->getLastGeneratedValue();
        // //~
        if(!empty($location_contact_list_role_id) && $result && !empty($is_create_contact_list) )
        {    
            $postData = array();
            $postData['organization_id'] = trim($_SESSION['organization_id']);
            $postData['location_id'] = trim($_SESSION['location_id']);
            $postData['location_contact_list_role_id'] = trim($location_contact_list_role_id);
            $postData['user_id'] = trim($_SESSION['accountpanel_user_id']);
            $fields_string = '';
            foreach($postData as $key=>$value) { $fields_string .= $key.'='.$value.'&'; }
            rtrim($fields_string, '&');
            // echo "<br> :: ".NODE_IP_WITH_PORT."/saveCustomContact";die();
            $curl = curl_init(NODE_IP_WITH_PORT."/saveCustomContact");
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $fields_string);
            $curl_response = curl_exec($curl);
            if ($curl_response === false) {
                $info = curl_getinfo($curl);
                curl_close($curl);
                $resultFlag = 2;
            }
            else {
                curl_close($curl);
                $response = json_decode($curl_response,true);
                // //~
                if(!($response['STATUS'] == '1')) {
                    $resultFlag = 2;
                }
            }
        }
        return $resultFlag;
    }
/* *
 * DEVELOPED BY :: NIKUNJ PATEL [ NP :: 01-08-2018 ]
 * DESCRIPTION :: FOR SAVE THE CONTACT IN ADD/EDIT EHT CONTACT LIST.
 * */    
    public function updateContactList($pData)
    {
        $resultFlag = 0;
        if(!count($pData)>0) {
            return $resultFlag;
        }
        if(!(isset($pData['contact_list_name']) && !empty($pData['contact_list_name']))) {
            return $resultFlag;   
        }
        $date = date('Y-m-d H:i:s');
        // //~
        $h_role_id = 0;
        if(isset($pData['h_role_id']) && !empty($pData['h_role_id'])) {
            $h_role_id = $pData['h_role_id'];
        } else {
             return $resultFlag;   
        }
        $contact_list_name = trim($pData['contact_list_name']);
        $description = trim($pData['contact_list_desc']);
        $resultFlag = 1;
        $dataArray = array(
            'contact_name' => $contact_list_name,
            'description' => $description,
            'modified_on' => $date,
            'modified_by' => $_SESSION['accountpanel_user_id']
        );
        $sql = new Sql($this->adapter);
        $update = $sql->update();
        $update->table('tbl_location_contact_list_role');
        $update->set($dataArray);
        $update->where( array('location_contact_list_role_id' => $h_role_id));
        $statement  = $sql->prepareStatementForSqlObject( $update );
        $result = $statement->execute();
        if(!$result) {
            $resultFlag = 0;
        } 
        return $resultFlag;
    }
// // ~ ----------------------------------------------------------------------------------------------------------------- ~ // //	
	public function viewContactData($filter_data)
    {
        $resultArray = array();
        $resultArray['status'] = 0;
        $resultArray['column'] = array();
        $resultArray['contact_list'] = array();
        $resultArray['data'] = array();
        // //~
        $role_id = '0';
        $is_sms_ac_active = '0';
        if(isset($filter_data['id']) && !empty($filter_data['id']) ) {
            $role_id = (int) $filter_data['id'];
        }
        if(!empty($role_id))
        {
            $column_ary = array();
            $sql_0 ="SELECT * FROM `tbl_location_contact_list_role` WHERE organization_id = '".trim($_SESSION['organization_id'])."' AND location_id = '".trim($_SESSION['location_id'])."' AND `location_contact_list_role_id` = '".$role_id."' ";
            $statement_0 = $this->adapter->query($sql_0); 
            $result_0 = $statement_0->execute();
            if($result_0 > 0)
            {
                $row_0 = $result_0->current();
                $resultArray['contact_list'] = $row_0;
                if(isset($row_0['columns_for_this_list']) && !empty($row_0['columns_for_this_list'])) {
                   $column_ary = explode(",",$row_0['columns_for_this_list']);
                }
            }
            // //~
            if(count($column_ary)>0)
            {
                $resultArray['status'] = '1';
                $resultArray['column'] = $column_ary;
                $search = array('/','\\',':',';','!','@','#','$','%','^','*','(',')','_','+','=','|','{','}','[',']','"',"'",'<','>',',','?','~','`','&',' ','.');
                // //~
                $sql_1 ="SELECT * FROM tbl_location_contact_list_history WHERE organization_id = '".trim($_SESSION['organization_id'])."' AND location_id = '".trim($_SESSION['location_id'])."' AND `location_contact_list_role_id` = '".$role_id."' ";
                $statement_1 = $this->adapter->query($sql_1); 
                $result_1 = $statement_1->execute();
                // //~
                foreach($result_1 as $k=>$v)
                {
                    $column_value_ary = array();
                    $sign_in_key_value = (!empty($v['sign_in_key_value']))?json_decode($v['sign_in_key_value'],true):array();
                    foreach ($sign_in_key_value as $key => $value)
                    {
                        if(isset($value['label']) && !empty($value['label']) && isset($value['value']) && !empty($value['value']) )
                        {
                            $colKey = str_replace($search, '', str_replace(' ', '', $value['label']));
                            $column_value_ary[$colKey] = '';
                            if(is_array($value['value'])) {
                                $tmp_val_ary = array();
                                if(!empty($value['display_dropdown_key']) && count($value['value'])>0) {
                                    foreach ($value['value'] as $key_1 => $value_1) {
                                        $val = (isset($value_1[$value['display_dropdown_key']]) && !empty($value_1[$value['display_dropdown_key']]))?$value_1[$value['display_dropdown_key']]:'';
                                        if(!empty($val)) {
                                            $tmp_val_ary[] = $val;
                                        }
                                    }
                                }
                                if(!empty($tmp_val_ary) && count($tmp_val_ary)>0) {
                                    $column_value_ary[$colKey] = implode(", ", $tmp_val_ary);
                                }
                            }
                            else {
                                $column_value_ary[$colKey] = $value['value'];
                            }
                        }
                    }
                    $tmpAry = array();
                    $tmpAry[] = $v['location_contact_list_history_id'];
                    if(!(isset($filter_data['is_download']) && strtolower($filter_data['is_download']) == 'yes')) {
                        // $tmpAry[] = ((empty($v['is_user_block']))?$v['location_contact_list_history_id']:'');
                        $tmpAry[] = $v['location_contact_list_history_id']."_".$v['is_user_block'];
                    }
                    foreach ($column_ary as $key => $value) {
                        $colKey = str_replace($search, '', str_replace(' ', '', $value));
                        $tmpAry[] = (isset($column_value_ary[$colKey]) && !empty($column_value_ary[$colKey]))?$column_value_ary[$colKey]:"-";
                    }
                    if(!(isset($filter_data['is_download']) && strtolower($filter_data['is_download']) == 'yes')) {
                        $btn_string = '';
                        if(!empty($is_sms_ac_active) && !empty($v['mobile_number']) ) {
                            $btn_string = '<a href="javascript:void(0);" class="cls_send_sms" data-value="'.$v['mobile_number'].'" >Send SMS</a> | ' ;
                        }
                        $btn_string .= '<a href="javascript:void(0);" class="cls_user_block cls_block_user_'.$v['location_contact_list_history_id'].'" data-isblock ="'.$v['is_user_block'].'" data-hid="'.$v['location_contact_list_history_id'].'" >'.((!empty($v['is_user_block']))?'Unblock':'Block').'</a>' ;
                        $tmpAry[] = $btn_string;
                    }
                    $resultArray['data'][] = $tmpAry;
                }
                if(isset($filter_data['is_download']) && strtolower($filter_data['is_download']) == 'yes' && !empty($resultArray['data']) && count($resultArray['data'])>0)
                {
                    $tmpArray = $resultArray['data'];
                    // --------------------------------------------------------------------------------------------
                    $h_order_for = 1;
                    $h_order_by = SORT_ASC;
                    // //~
                    if(isset($filter_data['h_order_for']) && $filter_data['h_order_for'] != '') {
                        $filter_data['h_order_for'] = (int)$filter_data['h_order_for'];
                        $h_order_for = $filter_data['h_order_for']-1;
                    }
                    if(isset($filter_data['h_order_by']) && strtolower($filter_data['h_order_by']) == 'desc' ) {
                        $h_order_by = SORT_DESC;
                    }
                    try {
                        $tmpSort = array();
                        foreach($resultArray['data'] as $k_1 => $v_1) {
                            $tmpSort['SortKey'][$k_1] = strtolower($v_1[$h_order_for]);
                            $tmpSort['UniqueKey'][$k_1] = $v_1[0];
                        }
                        array_multisort($tmpSort['SortKey'], $h_order_by, $tmpSort['UniqueKey'], $h_order_by, $resultArray['data']);
                    } 
                    catch (Exception $e) { 
                        $resultArray['data'] = $tmpArray;
                    }
                    // --------------------------------------------------------------------------------------------
                }
            }  
        }
        // echo "<pre>";
        //     print_r($resultArray);
        // die();
		return $resultArray;
	}
    public function blockUser($pData)
    {
        $resultFlag = 0;
        $user_json = '';
        $role_id = '';
        $is_user_block = '0';
        if(!empty($pData) && count($pData)>0) {
            if(isset($pData['user_ids']) && !empty($pData['user_ids'])) {
                $user_json = $pData['user_ids'];
            }
            if(isset($pData['role_id']) && !empty($pData['role_id'])) {
                $role_id = $pData['role_id'];
            }
             if(isset($pData['is_user_block']) && !empty($pData['is_user_block'])) {
                $is_user_block = $pData['is_user_block'];
            }
        }
        if(empty($user_json) || empty($role_id)) {
            return $resultFlag;
        }
        $tmp_user_ary = json_decode($user_json,true);
        $user_ary = array();
        foreach ($tmp_user_ary as $key => $value) {
            if($value == '1') {
                $user_ary[$key] = $key;
            }
        }
        if(!empty($user_ary) && count($user_ary) >0)
        {
            $block_count = 50;
            $final_user_ary = array();
            $tmpAry = array();
            $tmp = 0;
            foreach ($user_ary as $key => $value) {
                $tmp++;
                $tmpAry[] = $value;
                if(($tmp == count($user_ary)) ||  (count($tmpAry) == $block_count)) {
                    $final_user_ary[] = $tmpAry;
                    $tmpAry = array();
                }
            }
            if(!empty($is_user_block)) {
                $where_condition = "`is_user_block` = '0'";
            } else {
                $where_condition = "`is_user_block` = '1'";
            }
            foreach ($final_user_ary as $key => $value)
            {
                try {
                    $sql ="UPDATE `tbl_location_contact_list_history` SET ".$where_condition." WHERE `location_contact_list_history_id` IN ('".implode("','", $value)."') AND `location_contact_list_role_id` = '".$role_id."' ";
                    $statement = $this->adapter->query($sql);
                    $result = $statement->execute();
                    $resultFlag = 1;
                } catch(Exception $e) {
                    $resultFlag = 0;
                }
            }
        }
        return $resultFlag;
    }
// // ~ ----------------------------------------------------------------------------------------------------------------- ~ // //
/* *
 * DEVELOPED BY :: NIKUNJ PATEL [ NP :: 24-08-2018 ]
 * DESCRIPTION :: FOR GET THE CAMPAIGN LIST
 * */   
    public function getCampaignList()
    {
        $resultAry['AllData'] = array();
        // //~
        $sql ="SELECT c.*,r.`contact_name` FROM `tbl_location_sms_compaign` c 
            INNER JOIN `tbl_location_contact_list_role` r ON r.`location_contact_list_role_id` = c.`location_contact_list_role_id`
            WHERE c.`organization_id` = '".trim($_SESSION['organization_id'])."' AND c.`location_id` = '".trim($_SESSION['location_id'])."' AND c.`is_active` = '1' ";
        // echo "<pre>".$sql; die();    
        $statement = $this->adapter->query($sql); 
        $result = $statement->execute();
        if(count($result)>0)
        {
            foreach ($result as $key => $value)
            {
                $sms_type = '';
                if($value['sms_type'] == '0') {
                    $sms_type = 'Now';
                } else if($value['sms_type'] == '1') {
                    $sms_type = 'Schedule for later';
                } else if($value['sms_type'] == '2') {
                    $sms_type = 'Based on date field';
                }
                $tmpAry = array();
                $tmpAry[] = $value['compaign_name'];
                $tmpAry[] = (!empty($value['compaign_ref_name'])?$value['compaign_ref_name']:'-');
                $tmpAry[] = (!empty($sms_type)?$sms_type:'-');
                $tmpAry[] = '<a data-id="'.$value['location_sms_compaign_id'].'" href="'.MODULE_ROUTE_ACCOUNTADMIN_URL.'/campaign/campaign/'.fnEncodeData($value['location_sms_compaign_id']).'">Edit</a> | <a class="cls_delete" data-id="'.$value['location_sms_compaign_id'].'" href="javascript:void(0);">Delete</a>';
                $tmpAry[] = (!empty($value['is_active']))?'Active':'Suspend';
                $tmpAry[] = $value['location_sms_compaign_id'];
                $resultAry['AllData'][] = $tmpAry;
            }
        }
        return $resultAry;
    }
/* *
 * DEVELOPED BY :: NIKUNJ PATEL [ NP :: 24-08-2018 ]
 * DESCRIPTION :: FOR DELETE THE CAMPAIGN LIST
 * */  
    public function deleteCampaign($compaign_id='')
    {
        $resultFlag = 0;
        if(!empty($compaign_id))
        {
            try {
                $sql ="DELETE FROM `tbl_location_sms_compaign` WHERE `location_sms_compaign_id` = '".$compaign_id."' ";
                $statement = $this->adapter->query($sql);
                $result = $statement->execute();
                $resultFlag = 1;
            } catch(Exception $e) {
                $resultFlag = 0;
            }
        }
        return $resultFlag;
    }    
/* *
 * DEVELOPED BY :: NIKUNJ PATEL [ NP :: 24-08-2018 ]
 * DESCRIPTION :: FOR GET THE CAMPAIGN LIST
 * */   
    public function getContactListForCampaign()
    {
        $resultArray = array();
        $resultArray['status'] = 0;
        $resultArray['contact_list'] = array();
        $resultArray['phone_field'] = array();
        $resultArray['date_field'] = array();
        $sql ="SELECT r.* FROM tbl_location_contact_list_role r 
            WHERE r.`organization_id` = '".trim($_SESSION['organization_id'])."' AND r.`location_id` = '".trim($_SESSION['location_id'])."' AND r.`is_active` = '1' ";
        // echo "<pre>".$sql; die();    
        $statement = $this->adapter->query($sql); 
        $result = $statement->execute();
        if(count($result)>0)
        {
            $resultArray['status'] = 1;
            foreach ($result as $key => $value)
            {
                $resultArray['contact_list'][$value['location_contact_list_role_id']] = $value['contact_name'];
                $resultArray['phone_field'][$value['location_contact_list_role_id']] = array();
                $resultArray['date_field'][$value['location_contact_list_role_id']] = array();
                $tmpAry = json_decode($value['columns_for_this_list_json'],true);
                foreach ($tmpAry as $key_2 => $value_2) {
                    // echo "<br> :: ".$value_2['master_form_field_parent_id']." :: ".$value_2['master_form_field_type_id'];
                    if($value_2['master_form_field_parent_id'] == '9' || $value_2['master_form_field_type_id'] == '9') {
                        if(!in_array(trim($value_2['label']),$resultArray['phone_field'][$value['location_contact_list_role_id']])) {
                            $resultArray['phone_field'][$value['location_contact_list_role_id']][] = trim($value_2['label']);    
                        }
                    }
                    if($value_2['master_form_field_parent_id'] == '6' || $value_2['master_form_field_type_id'] == '6') {
                        if(!in_array(trim($value_2['label']),$resultArray['date_field'][$value['location_contact_list_role_id']])) {
                            $resultArray['date_field'][$value['location_contact_list_role_id']][] = trim($value_2['label']);    
                        }
                    }
                }
            }
        }
        // echo "<pre>";
        //     print_r($resultArray);
        // die();
        return $resultArray;
    }
/* *
 * DEVELOPED BY :: NIKUNJ PATEL [ NP :: 27-08-2018 ]
 * DESCRIPTION :: CHECK THE CAMPAIGN NAME IS ALREADY EXIST OR NOT
 * */   
    public function chkCampaignListName($pData)
    {
        $where_condition = '';
        if(isset($pData['h_campaign_id']) && !empty($pData['h_campaign_id'])){
            $where_condition = " AND `location_sms_compaign_id` != '".$pData['h_campaign_id']."' ";
        } 
        $sql ="SELECT * FROM tbl_location_sms_compaign 
            WHERE organization_id = '".trim($_SESSION['organization_id'])."' AND location_id = '".trim($_SESSION['location_id'])."' AND compaign_name = '".addslashes($pData['compaign_name'])."' ".$where_condition." ";
        $statement = $this->adapter->query($sql); 
        $result = $statement->execute();
        if(count($result)>0) {
            return true;
        }
        else {
            return false;
        }
    }
/* *
 * DEVELOPED BY :: NIKUNJ PATEL [ NP :: 27-08-2018 ]
 * DESCRIPTION :: FOR SAVE THE CAMPAIGN LIST 
 * */    
    public function saveCampaignList($pData)
    {
        $resultFlag = 0;
        if(!count($pData)>0) {
            return $resultFlag;
        }
        if(!(isset($pData['compaign_name']) && !empty($pData['compaign_name']))) {
            return $resultFlag;   
        }
        $date = date('Y-m-d H:i:s');
        // //~
        $location_contact_list_role_id = 0;
        if(isset($pData['contact_list']) && !empty($pData['contact_list'])) {
            $location_contact_list_role_id = (int) $pData['contact_list'];
        }
        else {
             return $resultFlag;
        }
        $h_campaign_id = 0;
        if(isset($pData['h_campaign_id']) && !empty($pData['h_campaign_id'])) {
            $h_campaign_id = (int) $pData['h_campaign_id'];
        }
        $compaign_name = trim($pData['compaign_name']);
        $compaign_ref_name = trim($pData['compaign_ref_name']);
        $type_of_compaign = '1';
        $template_message = '';
        if(isset($pData['template_message']) && !empty($pData['template_message'])) {
            $template_message = trim($pData['template_message']);
        }
        $send_on_number_field = '';
        if(isset($pData['send_on_number_field']) && !empty($pData['send_on_number_field'])) {
            $send_on_number_field = trim($pData['send_on_number_field']);
        }
        $is_signle_sms_to_unique_number = '0';
        if(isset($pData['is_signle_sms_to_unique_number']) && !empty($pData['is_signle_sms_to_unique_number'])) {
            $is_signle_sms_to_unique_number = '1';
        }
        $sms_type = '0';
        $is_schedule_for_today = true;
        if(isset($pData['sms_type']) && ($pData['sms_type'] == '1' || $pData['sms_type'] == '2') ) {
            $sms_type = ($pData['sms_type'] == '1')?'1':'2';   
            $is_schedule_for_today = false;
        }
        $frequency_of_sms = '0';
        $sms_send_date = '';
        $sending_from_date = '';
        $sending_to_date = '';
        $repeat_frequenty = '0';
        $days = '';
        $dates = '';
        $execute_sms_time = '00:00:00';
        $contact_field_nm = '';
        $date_field_type = '0';
        $date_in_above_selected_field = '0';
        $expiry_duration = 0;
        $send_sms_before = 0;
        // //~
        if($sms_type == '1')
        {
            if(isset($pData['frequency_of_sms']) && !empty($pData['frequency_of_sms'])) {
                $frequency_of_sms = '1';
            }
            if($frequency_of_sms == '0') {
                $sms_send_date = date("Y-m-d",strtotime(DateConvert($date,"IST")));
                $tmp_ist_today = $sms_send_date;
                if(isset($pData['sms_send_date']) && !empty($pData['sms_send_date'])) {
                    $sms_send_date = date('Y-m-d', strtotime(str_replace('/', '-', $pData['sms_send_date'])));
                }
                if($tmp_ist_today == $sms_send_date) {
                    $is_schedule_for_today = true;
                }
            }
            else if($frequency_of_sms == '1') {
                $sending_from_date = date("Y-m-d",strtotime(DateConvert($date,"IST")));
                $sending_to_date = date("Y-m-d",strtotime(DateConvert($date,"IST")));
                if(isset($pData['sending_from_date']) && !empty($pData['sending_from_date'])) {
                    $sending_from_date = date('Y-m-d', strtotime(str_replace('/', '-', $pData['sending_from_date'])));
                }
                if(isset($pData['sending_to_date']) && !empty($pData['sending_to_date'])) {
                    $sending_to_date = date('Y-m-d', strtotime(str_replace('/', '-', $pData['sending_to_date'])));
                }
                $sending_from_date = DateConvert($sending_from_date." 00:00:00","GMT");
                $sending_to_date = DateConvert($sending_to_date." 23:59:59","GMT");
                if(strtotime($sending_from_date) <= strtotime($date) && strtotime($date) <= strtotime($sending_to_date)) {
                    $is_schedule_for_today = true;
                }
                if(isset($pData['repeat_freq']) && ($pData['repeat_freq'] == '1' || $pData['repeat_freq'] == '2' || $pData['repeat_freq'] == '3') ) {
                    if($pData['repeat_freq'] == '1') {
                        $repeat_frequenty = '1';
                    }
                    else if($pData['repeat_freq'] == '2') {
                        $repeat_frequenty = '2';
                    }
                    else if($pData['repeat_freq'] == '3') {
                        $repeat_frequenty = '3';
                    }
                }
                if($repeat_frequenty == '2' && isset($pData['repeat_days']) && !empty($pData['repeat_days']) && count($pData['repeat_days']) > 0) {
                    $days = implode(",", $pData['repeat_days']);
                }
                else if($repeat_frequenty == '3' && isset($pData['repeat_dates']) && !empty($pData['repeat_dates']) && count($pData['repeat_dates']) > 0) {
                    $dates = implode(",", $pData['repeat_dates']);
                }
            }
            if(isset($pData['execute_sms_time']) && !empty($pData['execute_sms_time'])) {
                $execute_sms_time = $pData['execute_sms_time'].":00";
            }
        }
        else if($sms_type == '2')
        {
            if(isset($pData['contact_date_option']) && !empty($pData['contact_date_option'])) {
                $contact_field_nm = trim($pData['contact_date_option']);
            }
            $date_field_type = '1';
            if(isset($pData['date_field_type']) && ($pData['date_field_type'] == '1' || $pData['date_field_type'] == '2') ) {
                $date_field_type = ($pData['date_field_type'] == '1')?'1':'2';   
            }
            if($date_field_type == '1') {
                $date_in_above_selected_field = '1';
                if(isset($pData['date_in_above_selected_field']) && ($pData['date_in_above_selected_field'] == '1' || $pData['date_in_above_selected_field'] == '2') ) {
                    $date_in_above_selected_field = ($pData['date_in_above_selected_field'] == '1')?'1':'2';   
                }
                if($date_in_above_selected_field == '2')
                {
                    $sending_from_date = date("Y-m-d",strtotime(DateConvert($date,"IST")));
                    $sending_to_date = date("Y-m-d",strtotime(DateConvert($date,"IST")));
                    if(isset($pData['date_from']) && !empty($pData['date_from'])) {
                        $sending_from_date = date('Y-m-d', strtotime(str_replace('/', '-', $pData['date_from'])));
                    }
                    if(isset($pData['date_to']) && !empty($pData['date_to'])) {
                        $sending_to_date = date('Y-m-d', strtotime(str_replace('/', '-', $pData['date_to'])));
                    }
                    $sending_from_date = DateConvert($sending_from_date." 00:00:00","GMT");
                    $sending_to_date = DateConvert($sending_to_date." 23:59:59","GMT");
                    if(strtotime($sending_from_date) <= strtotime($date) && strtotime($date) <= strtotime($sending_to_date)) {
                        $is_schedule_for_today = true;
                    }
                }
                else if($date_in_above_selected_field == '1') {
                    $is_schedule_for_today = true;
                }
            }
            else if($date_field_type == '2') {
                $is_schedule_for_today = true;
                $expiry_duration = 0;
                if(isset($pData['expiry_duration']) && !empty($pData['expiry_duration'])) {
                    $expiry_duration = (int) $pData['expiry_duration'];
                }
                $send_sms_before = 0;
                if(isset($pData['send_sms_before']) && !empty($pData['send_sms_before'])) {
                    $send_sms_before = (int) $pData['send_sms_before'];
                }
            }
            if(isset($pData['execute_sms_time']) && !empty($pData['execute_sms_time'])) {
                $execute_sms_time = $pData['execute_sms_time'].":00";
            }
        }
        $is_active = '0';
        if(isset($pData['is_active']) && !empty($pData['is_active']) ) {
            $is_active = '1';   
        }
        $resultFlag = 1;
        $dataArray = array(
            'organization_id' => $_SESSION['organization_id'],
            'location_id' => $_SESSION['location_id'],
            'location_contact_list_role_id' => $location_contact_list_role_id,
            'compaign_name' => $compaign_name,
            'compaign_ref_name' => $compaign_ref_name,
            'type_of_compaign' => $type_of_compaign,
            'template_message' => $template_message,
            'send_on_number_field' => $send_on_number_field,
            'is_signle_sms_to_unique_number' => $is_signle_sms_to_unique_number,
            'sms_type' => $sms_type,
            'frequency_of_sms' => $frequency_of_sms,
            'sms_send_date' => $sms_send_date,
            'sending_from_date' => $sending_from_date,
            'sending_to_date' => $sending_to_date,
            'repeat_frequenty' => $repeat_frequenty,
            'days' => $days,
            'dates' => $dates,
            'execute_sms_time' => $execute_sms_time,
            'contact_field_nm' => $contact_field_nm,
            'date_field_type' => $date_field_type,
            'date_in_above_selected_field' => $date_in_above_selected_field,
            'expiry_duration' => $expiry_duration,
            'send_sms_before' => $send_sms_before,
            'frequency_of_sms' => $frequency_of_sms,
            'is_modified_voonotes' => '0',
            'modified_on' => $date,
            'modified_by' => $_SESSION['accountpanel_user_id'],
            'is_active' => $is_active,
        );
        // echo "<br> :: ".$is_schedule_for_today;
        // echo "<pre>";
        //     print_r($dataArray);
        //     print_r($pData);
        // die();
        if(!empty($h_campaign_id))
        {
            $sql = new Sql($this->adapter);
            $update = $sql->update();
            $update->table('tbl_location_sms_compaign');
            $update->set($dataArray);
            $update->where( array('location_sms_compaign_id' => $h_campaign_id));
            $statement  = $sql->prepareStatementForSqlObject( $update );
            $result = $statement->execute();
            if($result && $is_active == '1')
            {
                $date_ist = DateConvert($date,"IST");
                // //~
                $postData = array();
                $postData['date'] = $postData['date'] = date("Y-m-d",strtotime($date_ist));
                $postData['compaign_id'] = $h_campaign_id;
                if(isset($h_sms_type) && empty($h_sms_type)) {
                    $postData['is_campaign_delete'] = '0';
                }
                else {
                    $postData['is_campaign_delete'] = '1';
                }
                $postData['is_schedule_for_today'] = $is_schedule_for_today;
                // //~
                $fields_string = '';
                foreach($postData as $key=>$value) { $fields_string .= $key.'='.$value.'&'; }
                rtrim($fields_string, '&');
                // //~ echo "<br> URL  :: ".NODE_IP_WITH_PORT."/setCampaignData";die();
                $curl = curl_init(NODE_IP_WITH_PORT."/setCampaignData");
                curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($curl, CURLOPT_POST, true);
                curl_setopt($curl, CURLOPT_POSTFIELDS, $fields_string);
                $curl_response = curl_exec($curl);
                if ($curl_response === false) {
                    $info = curl_getinfo($curl);
                    curl_close($curl);
                    $resultFlag = 2;
                }
                curl_close($curl);
                $response = json_decode($curl_response,true);
                if(!($response['STATUS'] == '1')) {
                    $resultFlag = 2;
                }
            }
        }
        else {
            $dataArray['is_created_voonotes'] = '0';
            $dataArray['created_on'] = $date;
            $dataArray['created_by'] = $_SESSION['accountpanel_user_id'];    
            // //~
            $insert = new Insert('tbl_location_sms_compaign');
            $insert->values($dataArray);
            $statment = $this->adapter->createStatement();
            $insert->prepareStatement($this->adapter, $statment);
            $result = $statment->execute();     
            $location_sms_compaign_id = $this->adapter->getDriver()->getLastGeneratedValue();
            if($result && $is_schedule_for_today && $is_active == '1')
            {
                $date_ist = DateConvert($date,"IST");
                // //~
                $postData = array();
                $postData['date'] = $postData['date'] = date("Y-m-d",strtotime($date_ist));
                $postData['compaign_id'] = $location_sms_compaign_id;
                // //~
                $fields_string = '';
                foreach($postData as $key=>$value) { $fields_string .= $key.'='.$value.'&'; }
                rtrim($fields_string, '&');
                // //~ echo "<br> URL  :: ".NODE_IP_WITH_PORT."/setCampaignData";die();
                $curl = curl_init(NODE_IP_WITH_PORT."/setCampaignData");
                curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($curl, CURLOPT_POST, true);
                curl_setopt($curl, CURLOPT_POSTFIELDS, $fields_string);
                $curl_response = curl_exec($curl);
                if ($curl_response === false) {
                    $info = curl_getinfo($curl);
                    curl_close($curl);
                    $resultFlag = 2;
                }
                curl_close($curl);
                $response = json_decode($curl_response,true);
                if(!($response['STATUS'] == '1')) {
                    $resultFlag = 2;
                } 
            }
        }
        if(!$result) {
             $resultFlag = 0;
        }
        return $resultFlag;
    }
/* *
 * DEVELOPED BY :: NIKUNJ PATEL [ NP :: 28-08-2018 ]
 * DESCRIPTION :: GET THE CAMPAIGN DETAIL
 * */    
    public function getCampaignDetail($campaign_id='')
    {
        $resultAry = array();
        if(!empty($campaign_id)) {
            $sql ="SELECT * FROM tbl_location_sms_compaign 
                WHERE organization_id = '".trim($_SESSION['organization_id'])."' AND location_id = '".trim($_SESSION['location_id'])."' AND `location_sms_compaign_id` = '".$campaign_id."' ";
            $statement = $this->adapter->query($sql); 
            $result = $statement->execute();
            if(count($result)>0) {
                $resultAry = $result->current();
                $resultAry['sending_from_date_gmt'] = $resultAry['sending_from_date'];
                if($resultAry['sending_from_date'] != '0000-00-00 00:00:00') {
                    $resultAry['sending_from_date'] = DateConvert($resultAry['sending_from_date'],"IST");
                }
                $resultAry['sending_to_date_gmt'] = $resultAry['sending_to_date'];
                if($resultAry['sending_to_date'] != '0000-00-00 00:00:00') {
                    $resultAry['sending_to_date'] = DateConvert($resultAry['sending_to_date'],"IST");
                }
            }
        }
        // echo "<pre>";
        //     print_r($resultAry);
        // die();
        return $resultAry;
    }       
// // ~ ----------------------------------------------------------------------------------------------------------------- ~ // //
}
