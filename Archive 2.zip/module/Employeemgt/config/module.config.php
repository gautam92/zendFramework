<?php

return array(
    'controllers' => array(
        'invokables' => array(
            'Employeemgt\Controller\Employeemgt' => 'Employeemgt\Controller\EmployeemgtController',
        ),
    ),

    // The following section is new and should be added to your file
    'router' => array(
        'routes' => array(
            'employeemgt' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/employee_management/employeemgt[/][:action][/:id]',
                    'constraints' => array(
                        'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                        'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        'controller' => 'Employeemgt\Controller\Employeemgt',
                        'action'     => 'index',
                    ),
                ),
            ),
           
        ),

    ),

    'view_manager' => array(
        'template_path_stack' => array(
            'employeemgt' => __DIR__ . '/../view',
        ),
    ),

	
);
