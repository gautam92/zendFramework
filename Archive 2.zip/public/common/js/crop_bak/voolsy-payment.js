$(document).ready(function(){
	$("#import_payment_submit").click(function(){
		var csvfile = jQuery('#payment_csv').val();
		if(csvfile.length==0){
			$('html, body').animate({scrollTop : 0},1000);
	    	var lblError = "Please select file to import";
	        $('#error_restaurant_msg').html('<div class="isa_error" style="z-index:99999;"><span><i class="fa fa-times-circle"></i>'+lblError+'</span></div>');
	            $(".isa_error").removeClass("hide_eroor").delay(2000).queue(function(){
	            $(this).addClass("hide_eroor").dequeue();
	        });
        	$('.popover-content').find('#view_res_web').css('border-color','red');
        	return false;
		}
		
		var allowedFiles = [".csv"];
		var lblError = "";
	    var fileUpload = document.getElementById("payment_csv");
	    var regex = new RegExp("([a-zA-Z0-9\s_\\.\-:])+(" + allowedFiles.join('|') + ")$");
	    if (!regex.test(fileUpload.value.toLowerCase())) {
	    	$('html, body').animate({scrollTop : 0},1000);
	    	var lblError = "Please upload files having extensions: " + allowedFiles.join(', ') + " only.";
	        $('#error_restaurant_msg').html('<div class="isa_error" style="z-index:99999;"><span><i class="fa fa-times-circle"></i>'+lblError+'</span></div>');
	            $(".isa_error").removeClass("hide_eroor").delay(2000).queue(function(){
	            $(this).addClass("hide_eroor").dequeue();
	        });
        	$('.popover-content').find('#view_res_web').css('border-color','red');
        	return false;
	    }
	    $(this).closest("form").submit();
	    return true;
	});
});



/* Start Edit Page Script */
function calculateAmounts(){
	var sub_total = parseFloat($("#sub_total").val().replace(',', '')).toFixed(2);
	var restaurant_service_charge = parseFloat((sub_total*parseFloat($("#restaurant_service_charge").attr('data-percentage')))/100).toFixed(2);
	var restaurant_service_tax = parseFloat(((parseFloat(sub_total)+parseFloat(restaurant_service_charge))*parseFloat($("#restaurant_service_tax").attr('data-percentage')).toFixed(2))/100).toFixed(2);
	var net_total = parseFloat(parseFloat(sub_total)+parseFloat(restaurant_service_charge)+parseFloat(restaurant_service_tax)).toFixed(2);
	
	var voolsy_discount = parseFloat($("#voolsy_discount").val().replace(',', '')).toFixed(2);
	var after_voolsy_discount_total = parseFloat(parseFloat(sub_total)+parseFloat(restaurant_service_charge)+parseFloat(restaurant_service_tax-voolsy_discount)).toFixed(2);
	
	var voolsy_handling_fee = parseFloat((net_total*$("#voolsy_handling_fee").attr('data-percentage'))/100).toFixed(2);
	var voolsy_handling_service_tax = parseFloat(voolsy_handling_fee*$("#voolsy_handling_service_tax").attr('data-percentage')/100).toFixed(2);
	var total_voolsy_handling_fee = parseFloat(voolsy_handling_fee+voolsy_handling_service_tax).toFixed(2);
	var restaurant_earning = parseFloat(net_total-total_voolsy_handling_fee).toFixed(2);
	
	var bank_charges = parseFloat($("#bank_charges").val().replace(',', '')).toFixed(2);
	var bank_charges_service_tax = parseFloat($("#bank_charges_service_tax").val().replace(',', '')).toFixed(2);
	var other_changes = parseFloat($("#other_changes").val().replace(',', '')).toFixed(2);
	var voolsy_earning = parseFloat(total_voolsy_handling_fee-other_changes).toFixed(2);
	
	$("#restaurant_service_charge").val(restaurant_service_charge);
	$("#restaurant_service_tax").val(restaurant_service_tax);
	$("#net_total").val(net_total);
	$("#after_voolsy_discount_total").val(after_voolsy_discount_total);
	$("#voolsy_handling_fee").val(voolsy_handling_fee);
	$("#voolsy_handling_service_tax").val(voolsy_handling_service_tax);
	$("#total_voolsy_handling_fee").val(total_voolsy_handling_fee);
	$("#restaurant_earning").val(restaurant_earning);
	$("#voolsy_earning").val(voolsy_earning);
}
$(document).ready(function(){
	$("#sub_total").keyup(function(){
		calculateAmounts();
		return false;
	});
	$("#edit_payment_submit").click(function(){
		if($.trim($("#sub_total").val()).length==0){
			$('html, body').animate({scrollTop : 0},1000);
	    	var lblError = "Subtotal must not be empty";
	        $('#error_restaurant_msg').html('<div class="isa_error" style="z-index:99999;"><span><i class="fa fa-times-circle"></i>'+lblError+'</span></div>');
	            $(".isa_error").removeClass("hide_eroor").delay(2000).queue(function(){
	            $(this).addClass("hide_eroor").dequeue();
	        });
        	$('.popover-content').find('#view_res_web').css('border-color','red');
			return false;
		}
		$(this).closest("form").submit();
		return true;
	});
});
/* End Edit Page Script */