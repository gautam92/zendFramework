

//BASE_URL= 'http://192.168.3.83:8888/Restaurantapp/public/superadmin';
var hostname = window.location.hostname;
var pageUrl = '';
//if($(location).attr('protocol') == 'https:'){  var pageUrl = 'https://'; }else{  var pageUrl = 'http://'; }
//console.log(hostname);
if (hostname == '192.168.3.32') {
    ROOT_URL = pageUrl+'http://192.168.3.32:8888/voolsy/';
    BASE_URL_MAIN = pageUrl+'http://192.168.3.32:8888/voolsy/superadmin';
    BASE_URL= pageUrl+'http://192.168.3.32:8888/voolsy/superadmin';
    BASE_URL_CUISINE = pageUrl+'http://192.168.3.32:8888/voolsy/superadmin/cuisine';
}else if(hostname == '192.168.3.35'){
    BASE_URL_MAIN = pageUrl+'http://192.168.3.35/voolsy/superadmin';
    BASE_URL= pageUrl+'http://192.168.3.35/voolsy/superadmin';
    BASE_URL_CUISINE = pageUrl+'http://192.168.3.35/voolsy/superadmin/cuisine';
}else if(hostname == '192.168.3.40'){
	ROOT_URL = pageUrl+'http://192.168.3.40:8888/voolsy/';
	
    BASE_URL_MAIN = pageUrl+'http://192.168.3.40:8888/voolsy/superadmin';
    BASE_URL= pageUrl+'http://192.168.3.40:8888/voolsy/superadmin';
    BASE_URL_CUISINE = pageUrl+'http://192.168.3.40:8888/voolsy/superadmin/cuisine';
    
    RESTAURANT_MODULE_BASE_URL = ROOT_URL+'restaurantadmin';
}else{
	
	ROOT_URL = pageUrl+'http://54.169.72.214/voolsy_v2/';
	
    BASE_URL_MAIN = pageUrl+ROOT_URL+'superadmin';
    BASE_URL= pageUrl+ROOT_URL+'superadmin';
    BASE_URL_CUISINE = pageUrl+ROOT_URL+'superadmin/cuisine'; 
    
    RESTAURANT_MODULE_BASE_URL = pageUrl+ROOT_URL+'restaurantadmin';
}

// Setting page Error
var SETTING_ERROR = 'Select facebook and google plus post option';

// Message 

var BLANK_VALIDATION = 'Please fill blank field';

var SUCC_SIGNUP_MSG =    'Signup successfully, please check your email for activation link';
var UPDATE_PROFILE_MSG = 'Profile has been updated sucessfully ';
var MISMATCH_PASSWORD = "Password does not match";

var PROFILE_IMG_BLANK = "Please upload file ";
var IMG_UNSUPPORTED = 'Unsupported file type!';
var IMG_SIZE_BIG = 'File is too big, it should be less than 5 MB.';
var UPGRADE_BROWSER = 'Please upgrade your browser, because your current browser lacks some new features we need!';
var SUCC_IMG_MSG = 'Profile picture has been updated sucessfully';
var UPDATE_SETTING_MSG = 'Setting has been updated sucessfully';

var EMAIL_INVALID = 'Enter valid email address';
//var MOBILE_VALID = 'Phone number must be at least 8 and less than 14 digits';
var MOBILE_VALID = 'Phone number must be at least 10 digits';
var PASSWORD_LENGTH_6 = 'Password must be at least 6 digits';
var PASSWORD_LENGTH_20 = 'Password must be less than 20 digits';
var PASSWORD_LENGTH_6_20 = 'Password must be at least 6 and less than 20 digits';
var PASSWORD_UPDATE = 'Password has been update successfully';
 
var BRANCH_AVAILABLE = 'Available checked';
var RESTAURANT_TIME = 'select timing';
var ITEM_CHECKED_AVAILABLE = 'Item select checke box';
var VALID_ZIPCODE = 'Enter valid zipcode';
var VALID_URL = 'Enter valid url';
//var PASSWORD_LENGTH_6 = 'New password must be at least 6 digits';
//var PASSWORD_LENGTH_20 = 'New password must be less than 20 digits';
//var MOBILE_VALID_14 = 'Phone number must be less than 14 digits';

var UPSELL_UPDATE = 'Upsell has been updated sucessfully'; 
var UPSELL_SUCCESS = 'Upsell has been updated sucessfully';
var UPSELL_ITEM = 'Select any one upsell item';

var URL_REGEX = /^(http|https)?:\/\/[a-zA-Z0-9-\.]+\.[a-z]{2,4}/;
var INVALID_WEBSITE = 'Invalid website url';
var INVALID_FACEBOOK_URL = 'Invalid facebook url';
var INVALID_TWITTER_URL = 'Invalid twitter url';

/* start changes by prashant shah 09-12-2015 */
var RESTAURANT_SUSPENSION_ERROR = 'You cannot suspend the account as restaurant branch/s is active';
var FOOD_TYPE_REQUERED = "Select menu type";
/* end changes by prashant shah 09-12-2015 */

var VAT_TIN_NUMBER = 'Please enter 9 digit valid TIN Number'; 
