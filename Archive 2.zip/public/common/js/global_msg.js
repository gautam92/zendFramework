// Setting page Error
var SETTING_ERROR = 'Select facebook and google plus post option';

// Message 
var BLANK_VALIDATION = 'Please fill blank field';

var SUCC_SIGNUP_MSG =    'Signup successfully, please check your email for activation link';
var UPDATE_PROFILE_MSG = 'Profile has been updated sucessfully ';
var MISMATCH_PASSWORD = "Password does not match";
var ENTER_PASSWORD = 'Please enter password';
var ENTER_CURRENT_PASSWORD = 'Please enter current password';
var ENTER_NEW_PASSWORD = 'Please enter new password';
var ENTER_CONFIRM_PASSWORD = 'Please enter confirm password';
var ENTER_PASSWORD_DOES_NOT_MATCH = 'Password does not match';
var INVALID_PASSWORD_LENGTH = 'Password must be at least 6 and less than 20 digits';
var INVALID_CONFRIM_PASSWORD_LENGTH = 'Confirm password must be at least 6 and less than 20 digits';
var CURRENT_PASSWORD_NEW_PASSWORD = 'Current and New password must not be same';
var SUCC_PASSWORD = 'Password has been updated successfully';

var PROFILE_IMG_BLANK = "Please upload file ";
var IMG_UNSUPPORTED = 'Unsupported file type!';
var IMG_SIZE_BIG = 'File is too big, it should be less than 5 MB.';
var UPGRADE_BROWSER = 'Please upgrade your browser, because your current browser lacks some new features we need!';
var SUCC_IMG_MSG = 'Profile picture has been updated sucessfully';
var UPDATE_SETTING_MSG = 'Setting has been updated sucessfully';

var EMAIL_INVALID = 'Enter valid legal email address.';
//var MOBILE_VALID = 'Phone number must be at least 10 digits';
var PASSWORD_LENGTH_6 = 'Password must be at least 6 digits';
var PASSWORD_LENGTH_20 = 'Password must be less than 20 digits';
var PASSWORD_LENGTH_6_20 = 'Password must be at least 6 and less than 20 digits';
var PASSWORD_UPDATE = 'Password has been update successfully';
 


var URL_REGEX = /^(http|https)?:\/\/[a-zA-Z0-9-\.]+\.[a-z]{2,4}/;
var INVALID_WEBSITE = 'Please enter a valid website URL';
var INVALID_FACEBOOK_URL = 'Please enter a valid facebook URL';
var INVALID_TWITTER_URL = 'Please enter a valid twitter URL';
var VAT_TIN_NUMBER = 'Please enter 9 digit valid TIN Number';

/* start changes by prashant shah 09-12-2015 */
var RESTAURANT_SUSPENSION_ERROR = 'You cannot suspend the account as restaurant branch/s is active';
/* end changes by prashant shah 09-12-2015 */

var FOOD_TYPE_REQUERED = "Select menu type";
var SELECT_REASON = "Please select reason for account suspension";
var ENTER_RESON = "Enter your reason";

var EMAIL_ENTER = "Please enter email address";
var PHONE_ENTER = "Please enter phone number";
var STREET1_ENTER = "Please enter first street address";
var STREET2_ENTER = "Please enter second street address";
var CITY_ENTER = "Please select any city name";
var STATE_ENTER = "Please select any state name";
var ZIPCODE_ENTER = "Please enter zip code";
var LEAGAL_EMAIL_ENTER = "Please enter leagal email address";


var ENTER_SEQUANCE_NO = "Please enter squance number";


/* HD :: Start Global Javascript Messages */
function forceAlphaNumeric(field){
    var invalidChars = /[^0-9()+-]/g;
    if(field.value.match(invalidChars))
        field.value = field.value.replace(invalidChars,'');
}

function forcenumericzipcode(field){
    var invalidChars = /[^0-9]/g;
    if(field.value.match(invalidChars))
        field.value = field.value.replace(invalidChars,'');
}
    
function cFnameLname(field) {
    var invalidChars = /[^0-9 A-Z a-z'-]/g;
    if(field.value.match(invalidChars))
        field.value = field.value.replace(invalidChars,'');
}
var BRANCH_SELECT_COUPON_ACCEPT = 'Please selecte Accept Coupon';
var NO_RECORDS_TO_EXPORT = ' No records to export';
var SELECT_MENU_CATEGORY = "Please select menu category";
var ENTER_NOTIFICATION_TITLE = 'Please enter notification title';
var ENTER_NOTIFICATION_DESCRIPTION = 'Please enter notification description';
var SELECT_ATLEAST_TABLE = 'Please select at least one table';
var SELECT_ALL_TABLE = 'Please select all table access';
var VALID_URL = 'Please enter valid URL';
var PHONE_LENGTH_8 = 'Phone number must be at least 8 digits';
var ALL_PASSWORD_SAME = 'Current, New and Retype password must not be same';
var ENTER_PRINTER_NAME = 'Please enter printer name';
var SELECT_PRINTER_TYPE= 'Please select printer type';
var SELECT_PRINTER_MANAGER= 'Please select manager';
var ENTER_MAC_ADD = 'Please enter MAC address';
var ENTER_IP_ADD = 'Please enter IP address';
var ENTER_PORT_NO = 'Please enter port no';
var SELECT_PRINTER_BRAND = 'Please select printer brand';
var SELECT_PRINTER_MODEL = 'Please select printer model';
var ENTER_KOT_PRINT_NO = 'Please enter numbers of KOT print';
var SELECT_MENU_ACCESS = 'Please select All menu access';
var SELECT_ONE_MENU = 'Please select at least one menu';
var SELECT_KOT_TABLE_ACCESS= 'Please select KOT table access';
var SELECT_ONE_TABLE = 'Please select at least one KOT table';
var ENTER_INVOICE_PRINT_NO = 'Please enter numbers of invoice print';
var SELECT_INVOICE_TABLE_ACCESS = 'Please select Invoice table access';
var SELECT_INVOICE_TABLE = 'Please select at least one Invoice table';
var SELECT_KOT_INVOICE = 'Please select KOT OR Invoice';
var SELECT_ATLEAT_ONE_PRICE = 'Please select atleast one price type';
var MOBILE_VALID = 'Phone number must be at least 8 digits'; // remove from top i have changed it.
var SELECT_IMAGE_TO_UPLOAD = 'Please select an image';
var SELECT_RESTAURANT_PLEASE = "Please select restaurant";
var SELECT_BRANCH_PLEASE = "Please select branch" ;
var UNIQUE_EXTRA_NAME = 'Please enter unique extra ingredients name';
var SELECT_CATEGORY = 'Please select at least one category';
var SELECT_RESTAURANT_BRANCH = 'Please select restaurant name and branch name';

var SELECT_NOTIFICATION_DEVICE_TYPE = 'Please select device type';

var ENTER_DEPOSIT_PRICE_GREATER_THAN_ZERO  = 'Please enter deposit amount greater than zero';
var ENTER_CREDIT_PRICE_GREATER_THAN_ZERO = 'Please enter credit limit greater than zero';
var ENTER_UNIQUE_EXTRA_INGREDIENTS_SEQUANCE ='Menu category sequence number already exist';
var ENTER_MIN_LESS_MAX_ITEM = "Please enter min item less than maximum item";

var ENTER_NUMERIC_VALUE = "Please enter only numeric value.";
var ENTER_REFERENCE_NAME = "Please select reference name.";
var GLOBAL_ERROR_MESSAGE = "Something went wrong with server.";
var GLOBAL_FORM_REQUIRED_MESSAGE = "Please fill all the mandatory fields";




