var fdLocale = {
fullMonths:["Janeiro", "Fevereiro", "Mar\u00E7o", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"],
monthAbbrs:["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"],
fullDays:["Segunda", "Ter\u00E7a", "Quarta", "Quinta", "Sexta", "S\u00E1bado", "Domingo"],
dayAbbrs:["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
titles:["M\u00EAs Anterior", "M\u00EAs Seguinte", "Ano Anterior", "Ano Seguinte", "Hoje", "Mostrar Calend\u00E1rio", "sem", "Semana [[%0%]] of [[%1%]]", "Semana", "Seleccionar data", "Arrastar", "Mostrar \u201C[[%0%]]\u201D first", "Ir para data actual", "Desabilitar data"]};
try { 
        if("datePickerController" in window) { 
                datePickerController.loadLanguage(); 
        }; 
} catch(err) {};