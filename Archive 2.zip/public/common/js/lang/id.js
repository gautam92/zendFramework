var fdLocale = {
fullMonths:["Januari", "Febuari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"],
monthAbbrs:["Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Ags", "Sep", "Okt", "Nov", "Des"],
fullDays:["Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu"],
dayAbbrs:["Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min"],
titles:["Bulan Lalu", "Bulan Depan", "Tahun Lalu", "Tahun Depan", "Hari Ini", "Kalender", "mg", "Minggu [[%0%]] dari [[%1%]]", "Minggu", "Pilih Tanggal", "Klik \u0026 drag untuk geser", "Tampilkan \u201C[[%0%]]\u201D diawal", "Ke tanggal hari ini", "Non\u002Daktifkan Kalender"]};
try { 
        if("datePickerController" in window) { 
                datePickerController.loadLanguage(); 
        }; 
} catch(err) {}; 
