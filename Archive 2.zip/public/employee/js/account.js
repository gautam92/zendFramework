function isPercentage(evt){
	 var valid = /^\d*(.\d{0,2})?$/.test(evt),
	  val = evt;
	if (isNaN(val) || val < 0 || val > 100 || !valid) {
		return val.substring(0, val.length - 1);
	}
	else
	{
		return val;
	}
}
function onlyNumeric(val) {
	var re = /^(?:[1-90]\d*|0)?(?:\.\d+)?$/;
	return re.test(val);
}
	function isPrice(evt){
      var valid = /^\d*(.\d{0,2})?$/.test(evt.value)
        val = evt.value;
      if (isNaN(val) || !valid || val < 0 || val > 100) {
          evt.value = val.substring(0, val.length - 1);
      }
}
function onlyDigit(val) {
	var re = /^\d+$/;
	return re.test(val);
}
	
function isNumber(evt) {
	evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    //console.log(charCode);
    if(charCode == 46 || charCode == 39 || charCode == 37) {
		return true;
	} else if (charCode > 31 && (charCode < 48 || charCode > 57)) {
		return false;
	}
	return true;
}	
$(document).on("click","#edit_account",function(){
	$("#view_html").addClass("hidden");
	$("#edit_html").removeClass("hidden");
	$("#account_pass_html").addClass("m-t-10");
	$("#div_edit_account").addClass("hidden");
	$("#account_name").text("Edit Account");
	$("#org_pass").removeClass('cls_error');
	$("#org_confirmpass").removeClass('cls_error');
});
$(document).on("click","#id_cancel",function(){
	$("#view_html").removeClass("hidden");
	$("#edit_html").addClass("hidden");
	$("#account_pass_html").removeClass("m-t-10");
	$("#div_edit_account").removeClass("hidden");
	$("#account_name").text("View Account");
});	
$('#org_pass').val('');
 $("input[name=first_nm],input[name=last_nm]").keypress(function (event) {
	if (event.charCode!=0) {
		if($(this).val().length == 1){
			 $(this).val($(this).val().toUpperCase());
		}
	}
 });
    
jQuery('#org_city,#org_state,#org_country,#org_name,#org_legal_name,#org_est_since,#first_nm,#last_nm').focusout(function(){
   if (jQuery.trim($(this).val()) == null || jQuery.trim($(this).val()) == '') {
		$(this).addClass('cls_error');   
	}else{
		$(this).removeClass('cls_error');  
	}
});


jQuery('#organization_type_id').change(function(){
   if (jQuery.trim($(this).val()) == null || jQuery.trim($(this).val()) == '') {
		 jQuery('[aria-labelledby=select2-organization_type_id-container]').addClass('cls_error');
	}else{
		 jQuery('[aria-labelledby=select2-organization_type_id-container]').removeClass('cls_error'); 
	}
});
jQuery('#org_email').focusout(function(){
	var filter = /^[_a-zA-Z0-9-]+(\.[_a-zA-Z0-9-]+)*@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*(\.[a-zA-Z]{2,10})$/;
	if (jQuery.trim($(this).val()) == null || jQuery.trim($(this).val()) == '') {
		$(this).addClass('cls_error');  
	}else if(!filter.test($(this).val())){
  
		$(this).addClass('cls_error');
	}else{
		$(this).removeClass('cls_error');
	}     
});

$(document).on("blur", "#org_pass,#org_confirmpass", function(){
	if (jQuery.trim($(this).val()) == null || jQuery.trim($(this).val()) == '') {
		$(this).addClass('cls_error');
	}else{
		$(this).removeClass('cls_error');
	}
});
$('#org_status_chk').click(function(){
	var chk_active = $(this).html();
	if(jQuery.trim(chk_active) == 'Suspend') {
		var chk_status = 'Active';
		$('#org_status_chk').text(chk_status);
	 }else{
		var chk_status = 'Suspend';
		$('#org_status_chk').text(chk_status);
	}
});
jQuery('.save_btn').click(function(){
	var inputid = jQuery(this).attr('data-id');
	var columenmid = jQuery(this).attr('data-colume');
	var DBdatavalue = jQuery('#'+inputid).attr('data-value');
	var DBtablename = jQuery('#'+inputid).attr('data-tbl');
	var data_value = $('#'+inputid).parent().find('.form-control').val();
	var filter = /^[_a-zA-Z0-9-]+(\.[_a-zA-Z0-9-]+)*@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*(\.[a-zA-Z]{2,10})$/;		
	var new_pwd =  $('#res_pass').val();
	var confirm_pwd = $('#res_confirmpass').val();
	var chk_blnk = true;
		
	if(jQuery.trim(new_pwd) == null || jQuery.trim(new_pwd) == ''){
		 jQuery('#org_pass').addClass('cls_error'); 
		 chk_blnk =false;
	}
	if(jQuery.trim(confirm_pwd) == null || jQuery.trim(confirm_pwd) == ''){
		 jQuery('#org_confirmpass').addClass('cls_error');
		 chk_blnk =false;
		}
	if(!chk_blnk){
		return false;
	}
	else if(new_pwd != confirm_pwd){
		error_msg(MISMATCH_PASSWORD);
		return false;
	}
	var  data_value = new_pwd;
	var user_id = jQuery('#user_id').val();
	var restaurant_id = jQuery('#restaurant_id').val();
	var res_owner_id = jQuery('#res_owner_id').val();
	var check_page_restaurant = $('#check_page').val();
	var restaurantupdateurl = jQuery("#"+check_page_restaurant).attr('action');
	   $('.cls_loader').removeClass('cls_hide');
		jQuery.ajax({
		type: 'POST',
		url: restaurantupdateurl,
		dataType: "json",
	   // async:false,
		data: {
		  colume: columenmid,
		  data_value: data_value,
		  data_tblnm: DBtablename,
		  user_id: user_id,
		  restaurant_id: restaurant_id,
		  res_owner_id: res_owner_id,
		  //curr_pwd:curr_pwd,
		},
		success: function(data) {
			$('.cls_loader').addClass('cls_hide');
			if(data.error != undefined){
				msgsignup_error = false;
				error_msg(data.error);
				jQuery('#org_pass').val('');
				jQuery('#org_confirmpass').val('');
			return false;
		  } else {
			if(inputid == 'password'){
			  jQuery('#org_pass').val('');
			  jQuery('#org_confirmpass').val('');
			  error_msg(PASSWORD_UPDATE);
			}
		  }
		},
		error : function(){
			error_msg(GLOBAL_ERROR_MESSAGE);
			$('.cls_loader').addClass('cls_hide');
			return false;
		}
	});
	return false;
});
   
function validation(){
	var error = false;
	var org_name = $.trim($("#org_name").val());	
	var organization_type_id = $.trim($("#organization_type_id").val());	
	var country_list_id = $.trim($("#country_list_id").val());	
	var state_list_id = $.trim($("#state_list_id").val());	
	var city_list_id = $.trim($("#city_list_id").val());	
	var first_nm = $.trim($("#first_nm").val());	
	var last_nm = $.trim($("#last_nm").val());	
	var org_email = $.trim($("#org_email").val());	
	var org_confirmpass = $.trim($("#org_confirmpass").val());	
	var org_pass = $.trim($("#org_pass").val());	
	var filter = /^[_a-zA-Z0-9-]+(\.[_a-zA-Z0-9-]+)*@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*(\.[a-zA-Z]{2,10})$/;
	if(org_name == '' || org_name == null){
		error = true;
		$("#org_name").addClass('cls_error');
	}
	if(organization_type_id == '' || organization_type_id == null){
		error = true;
		jQuery('[aria-labelledby=select2-organization_type_id-container]').addClass('cls_error');
	}
	if(country_list_id == '' || country_list_id == null){
		error = true;
		jQuery('[aria-labelledby=select2-country_list_id-container]').addClass('cls_error');
	}
	if(state_list_id == '' || state_list_id == null){
		error = true;
		jQuery('[aria-labelledby=select2-state_list_id-container]').addClass('cls_error');
	}
	if(city_list_id == '' || city_list_id == null){
		error = true;
		jQuery('[aria-labelledby=select2-city_list_id-container]').addClass('cls_error');
	}
	if(first_nm == '' || first_nm == null){
		error = true;
		$("#first_nm").addClass('cls_error');
	}
	if(last_nm == '' || last_nm == null){
		error = true;
		$("#last_nm").addClass('cls_error');
	}
	if(org_email == '' || org_email == null){
		error = true;
		$("#org_email").addClass('cls_error');
	} else if(!filter.test(org_email)) {
		$('#org_email').addClass('cls_error');
		error_msg(EMAIL_INVALID);
		error = true;
	}
	return error;
}
 
   
// Organization Submit 
$('#organization_submit').click(function(){
	var error = validation();
	if(error) {
		//$('html, body').animate({ scrollTop : 0 }, 1000);
		return false;
	} else {
	$(".cls_loader").removeClass('cls_hide');
	var vFD = new FormData(document.getElementById('viewaccount')); 
	var addorganizationurl = jQuery("#viewaccount").attr('action');
		jQuery.ajax({
		url: addorganizationurl,
		data: vFD,
		processData: false,
		contentType: false,
		dataType: "json",
		type: 'POST',
		success: function(data) {
			$(".cls_loader").addClass('cls_hide');
			if(data.error_log_out != undefined) {
				  location.reload();
				  return false;
			 }
			if(data.error != undefined){
			   $('.cls_loader').addClass('hide');
			   error_msg(data.error);
			   return false;
			}else{
				window.location = MODULE_ROUTE_ACCOUNTADMIN_URL+'/viewaccount';
			}
		 },
		 error : function(){
			$(".cls_loader").addClass('cls_hide');
			error_msg(GLOBAL_ERROR_MESSAGE);
			return false;
		 }
		});
	}
});
    
$('#country_list_id').select2().on("change", function(e) { 
	$('#org_country').val($(this).val());
	if ($('#country_list_id').val() == null || $('#country_list_id').val() == '') {
		 jQuery('[aria-labelledby=select2-country_list_id-container]').addClass('cls_error');
		 $('#state_list_id').empty();
		 jQuery('[aria-labelledby=select2-state_list_id-container]').children('span:first').html('Select');
		 $('#state_list_id').append('<option>Select state</option>');
	}else{
		$(".cls_loader").removeClass('cls_hide');
		var countryurl = MODULE_ROUTE_ACCOUNTADMIN_URL+'/getstatename';
		var datacountrylist  = 'country_id='+ $(this).val();
		jQuery.ajax({
			type: 'POST',
			url: countryurl,
			dataType: "json",
			async:false,
			data: datacountrylist,
			success: function(data) {
				if(data.error_log_out != undefined) {
					  location.reload();
					  return false;
				 }
				$(".cls_loader").addClass('cls_hide');
				if(data.statenmlist == '' || data.statenmlist == null){}else{
					$('#state_list_id').empty();
					$('#city_list_id').empty();
					jQuery('[aria-labelledby=select2-city_list_id-container]').children('span:first').html('Select');
				   
					jQuery('[aria-labelledby=select2-state_list_id-container]').children('span:first').html('Select');
					if (data == null || data == '') {
						  $('#state_list_id').append('<option>Select state</option>'); 
					}else{
					$('#state_list_id').append('<option value="">Select state</option>');       
					$.each( data['statenmlist'], function( index, value ){
						 $('#state_list_id').append('<option value="'+index+'" newval='+value+'>'+value+'</option>');
					  });
					}
				}
			},
			error : function(){
				$(".cls_loader").addClass('cls_hide');
				error_msg(GLOBAL_ERROR_MESSAGE);
				return false;
			 }
		});
		jQuery('[aria-labelledby=select2-country_list_id-container]').removeClass('cls_error');
	}
});
$('#state_list_id').select2().on("change", function(e) { 
        $('#org_state').val($(this).val());
        if ($(this).val() == null || $(this).val() == '') {
            jQuery('[aria-labelledby=select2-state_list_id-container]').addClass('cls_error');
        }else{
			$(".cls_loader").removeClass('cls_hide');
			var stateurl = MODULE_ROUTE_ACCOUNTADMIN_URL+'/getcityname';
			var datastatelist  = 'state_id='+ $(this).val();
			jQuery.ajax({
				type: 'POST',
				url: stateurl,
				dataType: "json",
				async:false,
				data: datastatelist,
				success: function(data) {
						$(".cls_loader").addClass('cls_hide');
						if(data.error_log_out != undefined) {
							  location.reload();
							  return false;
						 }
						$('#city_list_id').empty();
						jQuery('[aria-labelledby=select2-city_list_id-container]').children('span:first').html('Select');
						if (data == null || data == '') {
							  $('#city_list_id').append('<option>Select city</option>'); 
						}else{
							  $('#city_list_id').append('<option value="">Select city</option>'); 
						$.each( data, function( index, value ){
							  $('#city_list_id').append('<option value="'+index+'" newval='+value+'>'+value+'</option>');
						  });
						}
					},
					error : function(){
						$(".cls_loader").addClass('cls_hide');
						error_msg(GLOBAL_ERROR_MESSAGE);
						return false;
					 }
				});
            jQuery('[aria-labelledby=select2-state_list_id-container]').removeClass('cls_error'); 
        }
       
});
  
$('#city_list_id').select2().on("change", function(e) {
	$('#org_city').val($(this).val());      
	if ($(this).val() == null || $(this).val() == '') {
		jQuery('[aria-labelledby=select2-city_list_id-container]').addClass('cls_error');
	}else{
		jQuery('[aria-labelledby=select2-city_list_id-container]').removeClass('cls_error');
	}       
});        


	
