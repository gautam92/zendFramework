$(document).on("click",".editview",function(){
	var id= $(this).attr('id');
	$("#view"+id).addClass("hidden");
	$("#edit"+id).removeClass("hidden");
	$("#"+id).addClass("hidden");
});
$(document).on("click",".cancel_device_connect",function(){
	var id= $(this).attr('data-value');
	$("#view"+id).removeClass("hidden");
	$("#edit"+id).addClass("hidden");
	$("#"+id).removeClass("hidden");
});

$(document).on("click",".confirm-unlink-device",function(){
	$("#myModal").modal("show");
	var data_socket_id = $(this).attr('data-socket-id');
	var data_value = $(this).attr('data-value');
	$(".unlink-device").attr('data-socket-id',data_socket_id);
	$(".unlink-device").attr('data-value',data_value);
});
function onlyDigit(val) {
	var re = /^\d+$/;
	return re.test(val);
}	
$(document).on("click",".unlink-device",function(){
	var location_devices_id = $(this).attr('data-value');
	var data_socket_id = $(this).attr('data-socket-id');
	$("#myModal").modal("hide");
	if(location_devices_id != '') {
		$(".cls_loader").removeClass('cls_hide');
		$.ajax({
			type : 'POST',
			url : MODULE_ROUTE_ACCOUNTADMIN_URL+'/hardware/unlinkDevice',
			dataType : "json",
			data : {location_devices_id:location_devices_id,device_socket_id:data_socket_id},
			success : function(data) {
				$('.cls_loader').addClass('cls_hide');
				if(data.error_log_out != undefined) {
				  location.reload();
				  return false;
				}
				if(data.status == 1) {
					//location.reload();
					$("#datavalue"+location_devices_id+"").remove();
					if($(".boxes").length <= 0) {
						location.reload();
					} else {
						success_msg(data.msg);
					}
				} else {
					error_msg(data.msg);
				}
			},
			error: function(){  // error handling
				error_msg(GLOBAL_ERROR_MESSAGE);
				$('.cls_loader').addClass('cls_hide');
			}
		});
	} else {
		error_msg(GLOBAL_ERROR_MESSAGE);
	}
});
$('input[name="device_password"]').blur(function(){
    var device_password = $.trim($(this).val());
	//alert(!onlyDigit(device_password));
	if(device_password != '' && device_password != null) {
		if(device_password.length > 4 || device_password.length < 4 || !onlyDigit(device_password)){
			$(this).addClass('cls_error');
		} else {
			$(this).removeClass('cls_error');
		}
	}
});

$(document).on("click",".device_connect",function(){
	var location_devices_id = $(this).attr('data-value');
	var password = $.trim($("#device_password"+location_devices_id).val());
	var device_orientation = $("#device_orientation"+location_devices_id).val();
	
	var error = false;
	if(password != '' && password != null) {
		if(password.length > 4 || password.length < 4 || !onlyDigit(password)){
			$("#device_password"+location_devices_id).addClass('cls_error');
			error = true;
		} else {
			$("#device_password"+location_devices_id).removeClass('cls_error');
		}
	}
	
	if(!error) {
		//var checkin_type = jQuery("input[name=checkin_type"+location_devices_id+"]:checked").val();
		if(location_devices_id != '') {
			$(".cls_loader").removeClass('cls_hide');
			$.ajax({
				type : 'POST',
				url : MODULE_ROUTE_ACCOUNTADMIN_URL+'/hardware/updateDevice',
				dataType : "json",
				data : {location_devices_id:location_devices_id,password:password,device_orientation:device_orientation},
				success : function(data) {
					$('.cls_loader').addClass('cls_hide');
					if(data.error_log_out != undefined) {
					  location.reload();
					  return false;
					}
					if(data.status == 1) {
						var device_passcode = password;
						if(password == '' || password == null) {
							 device_passcode = '-';
						}
						$("#passcode"+location_devices_id).text(device_passcode);
						if(device_orientation == 0) {
							var chekType = 'Landscape';
						} else if(device_orientation == 1) {
							var chekType = 'Portrait';
						}  else {
							var chekType = 'Auto';
						}
						$("#deviceorientationview"+location_devices_id).text(chekType);
						$("#edit"+location_devices_id).addClass("hidden");
						$("#view"+location_devices_id).removeClass("hidden");
						$("#"+location_devices_id).removeClass("hidden");
						success_msg(data.msg);
					} else {
						error_msg(data.msg);
					}
				},
				error: function(){  // error handling
					error_msg(GLOBAL_ERROR_MESSAGE);
					$('.cls_loader').addClass('cls_hide');
					return false;
				}
			});
		} else {
			error_msg(GLOBAL_ERROR_MESSAGE);
		}
	}
});
