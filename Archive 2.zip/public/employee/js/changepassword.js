$('#org_pass').val('');
$(document).on("blur", "#org_pass,#org_confirmpass", function(){
	if (jQuery.trim($(this).val()) == null || jQuery.trim($(this).val()) == '') {
		$(this).addClass('cls_error');
	}else{
		$(this).removeClass('cls_error');
	}
});
jQuery('.save_btn').click(function(){
	var new_pwd =  $('#org_pass').val();
	var confirm_pwd = $('#org_confirmpass').val();
	var chk_blnk = true;
		
	if(jQuery.trim(new_pwd) == null || jQuery.trim(new_pwd) == ''){
		 jQuery('#org_pass').addClass('cls_error'); 
		 chk_blnk =false;
	}
	if(jQuery.trim(confirm_pwd) == null || jQuery.trim(confirm_pwd) == ''){
		 jQuery('#org_confirmpass').addClass('cls_error');
		 chk_blnk =false;
	} else if(new_pwd != confirm_pwd) {
		jQuery('#org_confirmpass').addClass('cls_error');
		error_msg(MISMATCH_PASSWORD);
		chk_blnk =false;
		return false;
	}
	if(!chk_blnk){
		return false;
	}
	var data_value = window.btoa(new_pwd);
	var user_id = jQuery('#user_id').val();
	var organization_id = jQuery('#organization_id').val();
	var employee_id = jQuery('#org_employee_id').val();
	var check_page = $('#check_page').val();
	var Bcnurl = jQuery("#viewhostdirectory").attr('action');
	var organization_master_employee_id = $('#organization_master_employee_id').val();
	   $(".cls_loader").removeClass('cls_hide');
	jQuery.ajax({
		type: 'POST',
		url: Bcnurl,
		dataType: "json",
		data: {
		  data_value: data_value,
		  user_id: user_id,
		  organization_id: organization_id,
		  employee_id: employee_id,
		  organization_master_employee_id: organization_master_employee_id,
		},
		success: function(data) {
			 $(".cls_loader").addClass('cls_hide');
			 if(data.error_log_out != undefined) {
				  location.reload();
				  return false;
			 }
			if(data.error != undefined){
				error_msg(data.error);
				jQuery('#org_pass').val('');
				jQuery('#org_confirmpass').val('');
			return false;
		  } else {
			 jQuery('#org_pass').val('');
			  jQuery('#org_confirmpass').val('');
			  $('#org_confirmpass').removeClass('cls_error');
			  $('#org_pass').removeClass('cls_error');
			  success_msg(PASSWORD_UPDATE);
		  }
		},
		error : function(){
			$(".cls_loader").addClass('cls_hide');
			error_msg(GLOBAL_ERROR_MESSAGE);
			return false;
		}
	});
	return false;
});
