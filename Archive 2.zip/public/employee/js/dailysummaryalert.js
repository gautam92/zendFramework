
$(document).on("click",".delete_emails",function(){
	$(this).parent().parent().parent().remove();
	if($("form .delete_emails").length == 1) {
		$("form .delete_emails:first").addClass('hidden');
	} else {
		$("form .delete_emails").removeClass('hidden');
	}
});

$(document).on("click","#add_email_content",function(){
	var emailHTML = $("#emailhtml").html();
	$("#email_html").append(emailHTML);
	if($("form .delete_emails").length > 1) {
		$("form .delete_emails").removeClass('hidden');
	}
});


$(document).on("blur","#alert_name",function(){
	var alert_name = $.trim($(this).val());
	if(alert_name == '' || alert_name == null) {
		$(this).addClass("cls_error");
	} else {
		$(this).removeClass("cls_error");
	}
});	
$(document).on("blur",".email_ids",function(){
	var email_ids = $.trim($(this).val());
	var filter = /^[_a-zA-Z0-9-]+(\.[_a-zA-Z0-9-]+)*@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*(\.[a-zA-Z]{2,10})$/;
	if(email_ids == '' || email_ids == null) {
		$(this).addClass("cls_error");
	} else if (!filter.test(email_ids)) {
		$(this).addClass("cls_error");
	} else {
		$(this).removeClass("cls_error");
	}
});	
function validationJquery() {
	var error = false;
	var alert_name = $.trim($("#alert_name").val());
	var signin_flow_ids = $.trim($(".signin_flow_ids option:selected").length);
	var filter = /^[_a-zA-Z0-9-]+(\.[_a-zA-Z0-9-]+)*@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*(\.[a-zA-Z]{2,10})$/;
	$("#id_org_msg").empty();
	if(alert_name == '' || alert_name == null){
		$("#alert_name").addClass('cls_error');
		error = true;
	} else {
		$("#alert_name").removeClass('cls_error');
	}
	if($("form .email_ids").length <= 0) {
		error_msg('Please add atleast one email');
		error = true;
	}
	if(signin_flow_ids <= 0) {
		error_msg('Please select atleast one form');
		error = true;
	}
	var texts = new Array();
	texts= $("form .email_ids").map(function() {
		return $.trim($(this).val());         
	}).get();
	
	duplicates = texts.reduce(function(acc, el, i, arr) {
	  if (arr.indexOf(el) !== i && acc.indexOf(el) < 0) acc.push(el); return acc;
	}, []);
	$("form .email_ids").each(function(){
		var email_ids = $.trim($(this).val());
		if(email_ids == '' || email_ids == null) {
			$(this).addClass("cls_error");
			error = true;
		} else if(!filter.test(email_ids)) {
			$(this).addClass("cls_error");
			error_msg(EMAIL_INVALID);
			error = true;
		} else if(duplicates.indexOf(email_ids) == '0') {
			$(this).addClass('cls_error');
			error_msg('Enter email are duplicate');
			error = true;
		} else {
			$(this).removeClass("cls_error");
		}
	});
	return error;
}

$(document).on("click","#add_summary",function(){
	var error = validationJquery();
	if(error) {
		if (!$(".isa_error").hasClass("isa_error") ) {
			error_msg(GLOBAL_FORM_REQUIRED_MESSAGE);
		}
		$('html, body').animate({ scrollTop : 0 }, 1000);
	} else {
		$(".cls_loader").removeClass('cls_hide');
		var Bcnurl = jQuery("#addsummary").attr('action');
		var vFD = new FormData(document.getElementById('addsummary')); 
		$.ajax({
			type : 'POST',
			url : Bcnurl,
			dataType : "json",
			data : vFD,
			cache: false,
			processData: false,
			contentType: false,
			success : function(data) {
				$('.cls_loader').addClass('cls_hide');
				if(data.error_log_out != undefined) {
				  location.reload();
				  return false;
				}
				if(data.status == 1) {
					window.location = MODULE_ROUTE_ACCOUNTADMIN_URL+'/tools/dailysummaryalertlist';
				} else {
					error_msg(data.msg);
				}
			},
			error: function(){  // error handling
				error_msg(GLOBAL_ERROR_MESSAGE);
				$('.cls_loader').addClass('cls_hide');
				return false;
			}
		});
	}
});




