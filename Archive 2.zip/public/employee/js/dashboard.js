var $j = jQuery.noConflict();
var oTable = $j('#dashboard_table');
$j(document).ready(function(){
	// //~ START :: DatePicker
	var currentDate = new Date()
	var year = currentDate.getFullYear()
	var month = ((currentDate.getMonth() + 1) >= 10) ? (currentDate.getMonth() + 1) : '0' + (currentDate.getMonth() + 1);
	var day = ((currentDate.getDate()) >= 10) ? (currentDate.getDate()) : '0' + (currentDate.getDate());
	var todayDate = year + "" + month + "" + day;
	var monthStartDate = year + "" + month + "01";
	// For Date and Time picker
	var FromDate = day+"/"+month+"/"+year;
	// var FromDate = "01/03/2017";
	var ToDate = day+"/"+month+"/"+year;
	var Flag_ToDate = year+"/"+month+"/"+day;
	FromDate = $("#sess_date_from").val();
	if(FromDate != "") {
		FromDate = FromDate.substring(0,2)+"/"+FromDate.substring(3,5)+"/"+FromDate.substring(6,10);
		Flag_FromDate = FromDate.substring(6,10)+"/"+FromDate.substring(3,5)+"/"+FromDate.substring(0,2);
	} else {
		FromDate = day+"/"+month+"/"+year;
		Flag_FromDate = year+"/"+month+"/"+day;
	}
	ToDate = $("#sess_date_to").val();
	if(ToDate != "") {
		ToDate = ToDate.substring(0,2)+"/"+ToDate.substring(3,5)+"/"+ToDate.substring(6,10);
		Flag_ToDate = ToDate.substring(6,10)+"/"+ToDate.substring(3,5)+"/"+ToDate.substring(0,2);
	} else {
		ToDate = day+"/"+month+"/"+year;
		Flag_ToDate = year+"/"+month+"/"+day;
	}
	$j("#date_from").val(FromDate);
	$j("#date_to").val(ToDate);
	$j('#date_from').datetimepicker({
		format:'d/m/Y',
		step:30,
		timepicker: false,
		maxDate: Flag_ToDate,
		dayOfWeekStart : 1,
		scrollInput : false,
		closeOnDateSelect:true,
		onShow:function( ct ){
			var to_cur_val = $j('#date_to').val();
			var to_cur_date_dd = to_cur_val.substring(0,2);
			var to_cur_date_mm = to_cur_val.substring(3,5);
			var to_cur_date_yy = to_cur_val.substring(6,10);
			this.setOptions({
				maxDate:to_cur_date_yy+"/"+to_cur_date_mm+"/"+to_cur_date_dd
			})
		}
	});
	$j('#date_to').datetimepicker({
		format:'d/m/Y',
		step:30,
		timepicker: false,
		minDate:Flag_ToDate,
		maxDate: Flag_ToDate,
		dayOfWeekStart : 1,
		scrollInput : false,
		closeOnDateSelect:true,
		onShow:function( ct ){
			var from_cur_val = $j('#date_from').val();
			var from_cur_date_dd = from_cur_val.substring(0,2);
			var from_cur_date_mm = from_cur_val.substring(3,5);
			var from_cur_date_yy = from_cur_val.substring(6,10);
			this.setOptions({
				minDate:from_cur_date_yy+"/"+from_cur_date_mm+"/"+from_cur_date_dd
			})
		}
	});
	$j('#h_date_from').val($j('#date_from').val());
	$j('#h_date_to').val($j('#date_to').val());

function datafetch(){
	$j('#h_date_from').val($j('#date_from').val());
	$j('#h_date_to').val($j('#date_to').val());	
	$j('#h_form_type').val($j('#form_type').val());	
	$j('#h_form_type_name').val($j('#form_type :selected').text());	
}
datatable();
datafetch();
if($("#visitorlog").hasClass("active")) {
	getdata();
}
function datatable(response) {
	var data = "";
	if(response != undefined) {
		if(response.data != '' || response.data != undefined) {
			data = response.data;
		}
	}
	var daraar = {};
	var aoColumns = [];
	var payAry = '';
	if($("#dynamic_fields").val() != '' && $("#dynamic_fields").val() != null && $j.parseJSON($("#dynamic_fields").val()) != '') {
		var payAry = $j.parseJSON($("#dynamic_fields").val());
	}
	if(payAry == '' || payAry == null || $("#dynamic_fields").val() == null) {
		aoColumns.push({ "sTitle": "", sClass:'hidden-role sortin hidden', 'bSortable': false }); // 1
		aoColumns.push({ "sTitle": "Name", sClass:'hidden-role sortin'}); // 2
		aoColumns.push({ "sTitle": "Email", sClass:'hidden-srno sortin'}); // 3
		aoColumns.push({ "sTitle": "Phone Number", sClass:'hidden-srno sortin'}); // 4
	} else {
		if(payAry != null && payAry != undefined) {
			var i = 0;
			$j.each(payAry, function (index,value) {
				if(value.is_visitor_sign_out_applicable == 1) {
					var Sortable = true;
					var coloumnlable = value.label;
					if(value.label == 'ProfilePhoto') {
						Sortable = false;
						coloumnlable = '';
					}
					var sortDatavalue = '';
					if(index == 'CheckInTime') {
						sortDatavalue = (i+1);
					} else {
						sortDatavalue = i;
					}
					aoColumns.push({ "sTitle": coloumnlable, sClass:'hidden-srno sortin' , "bVisible": value.display , 'bSortable': Sortable, 'orderData':[sortDatavalue], 'targets': [sortDatavalue] });	
					daraar[index] = i;
					i = (i+1);
				}
			});
		}
	}
	var SortFor = (parseInt(daraar['CheckInTime'])+1);
	var SortBy = 'DESC';
	var orderingDataColoumn = (parseInt(daraar['CheckInTime'])+1);
	if(daraar['CheckInTime'] == undefined) {
		orderingDataColoumn = 1;
	}
	SortFor = $("#session_order_for").val();
	if(SortFor == "") { SortFor = orderingDataColoumn; } 
	SortFor = parseInt(SortFor);
	SortBy = $("#session_order_by").val();
	if(SortBy == "") { SortBy = "DESC"; }
	$j("#dashboard_table").html('');
	oTable.dataTable( {
		"destroy": true,
		"aaData": data,
		"aoColumns": aoColumns,
		'responsive': true,
		"oLanguage": {
			"sSearch": "",
			"sZeroRecords": "No records found",
			"sEmptyTable": function(){ return "No records found"; }
		},
		"aLengthMenu": [[5, 10, 15, 20, 25, 50, 75, -1], [5, 10, 15, 20, 25, 50, 75, "All"]],
		"iDisplayLength": 10,
		"bPaginate": true,			
		"bLengthChange": true,
		"bFilter": true,
		"order": [[ SortFor, SortBy ]],
		"fnDrawCallback": function( oSettings ) {
			var api = this.api();
			var rows = api.rows({filter: 'applied'}).nodes().to$();
			if(rows.length>0) {
				$j("#h_is_data").val("Yes");
			} else {
				$j("#h_is_data").val("No");
				if( $("#dashboard_table tbody td.dataTables_empty").length > 0) {
					$("#dashboard_table tbody tr:first").addClass('tr_dataTables_empty');
					$(".dataTables_empty").attr('colspan','6');
				}
			}
		}
	});
	$("#dashboard_table_filter").addClass("hidden");
	$("#dashboard_table_length").addClass("hidden");
}

$j(document).on("click",".field_ids",function(e){
	var datacoloumn = $(this).attr('data-column');
	//var column = oTable.DataTable().column(datacoloumn).visible(false);
	var payAry = $j.parseJSON($("#dynamic_fields").val());
	if(payAry != undefined) {
		if($j(this).is(":checked")) {
			payAry[$j(this).val()].display = true;
		} else {
			payAry[$j(this).val()].display = false;
		}
		if($j('.field_ids:checked').length <= 0) {
			$j.each(payAry, function (index,value) {
				//console.log(value);
				if(value.is_default_field > 0) {
					payAry[index].display = true;
					$j("#"+index).prop("checked",true);
					$j(".field_ids:checked").each(function() {
						oTable.DataTable().column($j(this).attr('data-column')).visible(true);
						//(oTable.DataTable().column($j(this).attr('data-column')).visible() === true ? 'visible' : 'not visible')
					});
				} else {
					payAry[index].display = false;
					$j("#"+index).prop("checked",false);
					$j(".field_ids:not(checked)").each(function() {
						oTable.DataTable().column($j(this).attr('data-column')).visible(false);
					});
				}
			});
			
		} else {
			var column = oTable.DataTable().column( $(this).attr('data-column') );
			column.visible( ! column.visible() );
		}
		if($j('.field_ids:not(":checked")').length > 0){
			$j('.checkall').prop("checked",false);
		} else {
			$j('.checkall').prop("checked",true);
		}
		//console.log(payAry);
		$("#dynamic_fields").html(JSON.stringify(payAry));
		if( $("#dashboard_table tbody td.dataTables_empty").length > 0) {
			$("#dashboard_table tbody tr:first").addClass('tr_dataTables_empty');
			$(".dataTables_empty").attr('colspan','6');
		}
	}
	//oTable.DataTable().column(0).visible(true);
});
$j(document).on("click",".checkall",function(){
	var payAry = $j.parseJSON($("#dynamic_fields").val());
	if(payAry != undefined) {
		if($j(this).is(":checked")) {
			$j(".field_ids").prop("checked",true);
			$j.each(payAry, function (index,value) {
				if(payAry[index].is_hidden != 1) {
					payAry[index].display = true;
				}
			});
			$j(".field_ids:checked").each(function() {
				oTable.DataTable().column($j(this).attr('data-column')).visible(true);
			});
		} else {
			$j.each(payAry, function (index,value) {
				if(value.is_default_field > 0) {
					payAry[index].display = true;
					$j("#"+index).prop("checked",true);
				} else {
					payAry[index].display = false;
					$j("#"+index).prop("checked",false);
				}
			});
			$j(".field_ids:not(:checked)").each(function() {
				oTable.DataTable().column($j(this).attr('data-column')).visible(false);
			});
		}
		$("#dynamic_fields").html(JSON.stringify(payAry));
		if( $("#dashboard_table tbody td.dataTables_empty").length > 0) {
			$("#dashboard_table tbody tr:first").addClass('tr_dataTables_empty');
			$(".dataTables_empty").attr('colspan','6');
		}
	}
});
$j(document).on("click","#id_apply",function(){
	if ($j('#form_type').val() == null || $j('#form_type').val()== '') {
		jQuery('[aria-labelledby=select2-form_type-container]').addClass('cls_error');
	} else {
		jQuery('[aria-labelledby=select2-form_type-container]').removeClass('cls_error');
		getdata();
	}
});

function getdata() {
	datafetch();
	var searchAry = {};
	$(".cls_loader").removeClass('cls_hide');
	searchAry['field'] = $j("#dynamic_fields").val();
	searchAry['start_date'] = $j("#h_date_from").val();
	searchAry['end_date'] = $j("#h_date_to").val();
	searchAry['form_type'] = $j("#h_form_type").val();
	searchAry['h_form_type_flag'] = $j("#h_form_type_flag").val();
	jQuery.ajax({
		type: 'POST',
		url: MODULE_ROUTE_ACCOUNTADMIN_URL+'/Ajaxdashboard',
		dataType: "json",
		type: "post", 
		data: searchAry,
		success: function(response) {
			$(".cls_loader").addClass('cls_hide');
			if(response.error_log_out != undefined) {
				location.reload();
				return false;
			}
			if(response.data.length>0) {
				$("#dynamic_fields").text(response.Fieldsarr);
				var payAry = $j.parseJSON($("#dynamic_fields").val());
				var html = "";
				var k = 1;
				//console.log(payAry);
				$j.each(payAry, function (index,value) {
					if(value.is_hidden == '1') {
						k = k+1; 
					}
					if(value.is_hidden != '1') {
						if(value.is_visitor_sign_out_applicable == 1 && value.label != 'ProfilePhoto') {
							if(value.display) {
								$j("#"+index).prop("checked",true);
								html +='<div class="checkbox check-success">';
									html +='<input checked="checked" value="'+index+'" name="field_ids[]" id="'+index+'" data-column="'+k+'" class="field_ids" type="checkbox">';
									html +='<label for="'+index+'">'+value.label+'</label>';
								html +='</div>';
							} else {
								html +='<div class="checkbox check-success">';
									html +='<input value="'+index+'" name="field_ids[]" id="'+index+'" data-column="'+k+'" class="field_ids" type="checkbox">';
									html +='<label for="'+index+'">'+value.label+'</label>';
								html +='</div>';
								$j("#"+index).prop("checked",false);
							}
							k = k+1; 
						}
					}
				});
				if(html != '' && html != null) {
					$j("#field_checkbox").html('');
					$j("#field_checkbox").html(html);
				}
				
				if($j('.field_ids:not(":checked")').length > 0){
					$j('.checkall').prop("checked",false);
				} else {
					$j('.checkall').prop("checked",true);
				}
				window.oTable.fnDestroy();
				datatable(response);
			} else {
				$("#dynamic_fields").text(response.Fieldsarr);
				var payAry = $j.parseJSON($("#dynamic_fields").val());
				var html = "";
				var k = 0;
				html = $("#non_field_html").html(); 
				if(html != '' && html != null) {
					$j("#field_checkbox").html(html);
				}
				$j('.checkall').prop("checked",false);
				window.oTable.fnDestroy();
				datatable(response);
				$j("#dashboard_table .dataTables_empty").html('No records found');
			}
			$("#h_form_type_flag").val($("#form_type").val());
		},
		error: function(){  // error handling
			$j("#dashboard_table .dataTables_empty").html('Something Wrong!! Please try again');
			$j(".cls_loader").addClass('cls_hide');
			return false;
		}
	});
}
});

$(document).on("click",".visitor_details", function() {
	var ID = $(this).attr("data-id");
	filterSave(ID);
});

function filterSave(ID) {
	var searchAry = {};
	$(".cls_loader").removeClass('cls_hide');
	var current_page = $(".current").text();
	var order_for = $j("#h_order_for").val();
		order_for =(order_for-1);
	var order_by = $j("#h_order_by").val();
		order_by = order_by.toLowerCase();
	var is_checked = '0';
	if($j('.checkall').is(":checked")) {
		is_checked = '1';
	}
	searchAry['filter_settings'] = 'dashboard_settings';
	searchAry['field'] = $j("#dynamic_fields").val();
	searchAry['start_date'] = $j("#h_date_from").val();
	searchAry['end_date'] = $j("#h_date_to").val();
	searchAry['form_type'] = $j("#h_form_type").val();
	searchAry['h_form_type_flag'] = $j("#h_form_type_flag").val();
	searchAry['isallcheck'] = is_checked;
	//searchAry['current_page'] = current_page;
	//searchAry['order_for'] = order_for;
	//searchAry['order_by'] = order_by;	
	$.ajax({
		url: MODULE_ROUTE_ACCOUNTADMIN_URL+'/setSessionData',
		type: 'post',
		dataType: "json",
		data: searchAry,
		success: function(data) {
			$(".cls_loader").addClass('cls_hide');
			if(data.error_log_out != undefined) {
				  location.reload();
				  return false;
			}
			var URL = MODULE_ROUTE_ACCOUNTADMIN_URL+'/visitordetails/'+ID;
			window.location.href = URL;
		},
		error: function() {
			$(".cls_loader").addClass('cls_hide');
		}
	}); 
}

$(document).on('submit','form#dashboard_form',function(){
	var flag_is_data = $("#h_is_data").val();
	if(flag_is_data != "Yes") {
		error_msg(NO_RECORDS_TO_EXPORT);
		return false;
	}
});

/* For Order Sort */
$j(document).ready(function(){
	
	$j("#h_order_for").val("1");
	$j("#h_order_by").val("DESC");
	$j("#dashboard_table th").each(function( index ) {
		$j(document).on('click', '#dashboard_table th:nth-child('+(index+1)+')',function(e){
			var flag_sort_by = "";
			if ( $( this ).hasClass( "sorting_desc" ) ) {
				flag_sort_by = "DESC";
			} else {
				flag_sort_by = "ASC";
			}
			var flag_sort_for = index+1;
			$j("#h_order_by").val(flag_sort_by);
			$j("#h_order_for").val(flag_sort_for);
		});
	});
});


//~ ========================= START :: Pre Registration PART  ========================= ~//
if(jQuery.type( $j("#pre_register_sess_date_to").val() ) != "undefined") {	
var doTable;	
$j(document).ready(function(){
	// //~ START :: DatePicker
	var currentDate = new Date()
	var year = currentDate.getFullYear()
	var month = ((currentDate.getMonth() + 1) >= 10) ? (currentDate.getMonth() + 1) : '0' + (currentDate.getMonth() + 1);
	var day = ((currentDate.getDate()) >= 10) ? (currentDate.getDate()) : '0' + (currentDate.getDate());
	var todayDate = year + "" + month + "" + day;
	var monthStartDate = year + "" + month + "01";
	// For Date and Time picker
	var FromDate = day+"/"+month+"/"+year;
	// var FromDate = "01/03/2017";
	var ToDate = day+"/"+month+"/"+year;
	var Flag_ToDate = year+"/"+month+"/"+day;
	FromDate = $("#pre_register_sess_date_from").val();
	if(FromDate != "") {
		FromDate = FromDate.substring(0,2)+"/"+FromDate.substring(3,5)+"/"+FromDate.substring(6,10);
		Flag_FromDate = FromDate.substring(6,10)+"/"+FromDate.substring(3,5)+"/"+FromDate.substring(0,2);
	} else {
		FromDate = day+"/"+month+"/"+year;
		Flag_FromDate = year+"/"+month+"/"+day;
	}
	ToDate = $("#pre_register_sess_date_to").val();
	if(ToDate != "") {
		ToDate = ToDate.substring(0,2)+"/"+ToDate.substring(3,5)+"/"+ToDate.substring(6,10);
		Flag_ToDate = ToDate.substring(6,10)+"/"+ToDate.substring(3,5)+"/"+ToDate.substring(0,2);
	} else {
		ToDate = day+"/"+month+"/"+year;
		Flag_ToDate = year+"/"+month+"/"+day;
	}
	$j("#pre_register_date_from").val(FromDate);
	$j("#pre_register_date_to").val(ToDate);
	$j('#pre_register_date_from').datetimepicker({
		format:'d/m/Y',
		step:30,
		timepicker: false,
		maxDate: Flag_ToDate,
		dayOfWeekStart : 1,
		scrollInput : false,
		closeOnDateSelect:true,
		onShow:function( ct ){
			var to_cur_val = $j('#pre_register_date_to').val();
			var to_cur_date_dd = to_cur_val.substring(0,2);
			var to_cur_date_mm = to_cur_val.substring(3,5);
			var to_cur_date_yy = to_cur_val.substring(6,10);
			this.setOptions({
				maxDate:to_cur_date_yy+"/"+to_cur_date_mm+"/"+to_cur_date_dd
			})
		}
	});
	$j('#pre_register_date_to').datetimepicker({
		format:'d/m/Y',
		step:30,
		timepicker: false,
		minDate:Flag_ToDate,
		maxDate: Flag_ToDate,
		dayOfWeekStart : 1,
		scrollInput : false,
		closeOnDateSelect:true,
		onShow:function( ct ){
			var from_cur_val = $j('#pre_register_date_from').val();
			var from_cur_date_dd = from_cur_val.substring(0,2);
			var from_cur_date_mm = from_cur_val.substring(3,5);
			var from_cur_date_yy = from_cur_val.substring(6,10);
			this.setOptions({
				minDate:from_cur_date_yy+"/"+from_cur_date_mm+"/"+from_cur_date_dd
			})
		}
	});
	$j('#h_pre_register_date_from').val($j('#pre_register_date_from').val());
	$j('#h_pre_register_date_to').val($j('#pre_register_date_to').val());
	
	
	var datatable_array = $j('#datatable_array').val();
	var data = JSON.parse(datatable_array);
	doTable = $j('#id_datatable').dataTable( {
		"aaData": data,
		"aaSorting": [[ 6, "desc" ]],
		//"aaSorting": [],
		"aoColumns": [
			{ "sTitle": "", sClass:'hidden-phone sortin','bSortable': false}, //0
			{ "sTitle": "Visitor Name", sClass:'hidden-phone sortin','orderData':[1,10]},//1
			{ "sTitle": "Host Name", sClass:'hidden-phone sortin','orderData':[2,10]},//2
			{ "sTitle": "Form", sClass:'hidden-phone sortin','orderData':[3,10]},//3
			{ "sTitle": "Expected arrival time", sClass:'hidden-phone sortin','targets': [8], 'orderData':[8,10]},//4
			{ "sTitle": "Signed in at", sClass:'hidden-phone sortin','targets': [11],'orderData':[11,10]},//5
			{ "sTitle": "Created On", sClass:'hidden-phone sortin','targets': [11],'orderData':[11,10]},//6
			{ "sTitle": "Action", sClass:'hidden-phone sortin'}, // 7
			{ "sTitle": "IS visitor sign in", sClass:'hidden-phone sortin',"bVisible":false },//8
			{ "sTitle": "strtotime Expected arrival Date", sClass:'hidden-phone sortin',"bVisible":false},//9
			{ "sTitle": "Unique ID", sClass:'hidden-phone sortin',"bVisible":false},//10			
			{ "sTitle": "strtotime Signed in at", sClass:'hidden-phone sortin',"bVisible":false},//11
		],
		"aLengthMenu": [[5, 10, 15, 20, 25, 50, 75, -1], [5, 10, 15, 20, 25, 50, 75, "All"]],
		"bInfo" : true,
		"iDisplayLength": 10,
		"bPaginate": true,			
		"bLengthChange": false,
		"bFilter": true,
		"sPaginationType": "full_numbers",
		"oLanguage": {
			"sSearch": "",
			"sProcessing":function(){
				return "Loading data...";
			},
			"sZeroRecords": "No record found",
			"sEmptyTable": function(){
				return "No record found";
			}
		},
		"fnDrawCallback": function( oSettings ) {
			var api = this.api();
			var rows = api.rows({filter: 'applied'}).nodes().to$();
			if(rows.length>0) {
				$j("#h_pre_is_data").val("Yes");
			} else {
				$j("#h_pre_is_data").val("No");
			}
		},
		"bAutoWidth": false
	});
	$j(".dataTables_filter").addClass("hidden");
	if($j('#serach_user').val() != '' && $j('#serach_user').val() != null) {
		doTable.api().search($j('#serach_user').val(),true,false).draw();
	}
	if($j('#visitorname').val() != '' && $j('#visitorname').val() != null) {
		var choosedFilter = $j('#visitorname').val();
		if(choosedFilter != "") {
			choosedFilter = "^"+choosedFilter+"$";
		}
		doTable.fnFilter(choosedFilter,3,true,false);
	}
	$j('#visitorname').on("change", function(e) {
		var choosedFilter = $(this).val();
		if(choosedFilter != "") {
			choosedFilter = "^"+choosedFilter+"$";
		}
		doTable.fnFilter(choosedFilter,3,true,false);
	});
	$j('#serach_user').on('keyup', function(e){
		doTable.api().search(this.value,true,false).draw();
	});
	$j(document).on("click","#is_visitor_signin",function(){
		if($j(this).is(":checked")) {
			doTable.fnFilter('1',8,true,false);
		} else {
			doTable.fnFilter('',8,true,false);
		}
	});
	
	if($("#pre_registration_settings").val() != '' && $("#pre_registration_settings").val() != null) {
		getpreregistrationdata();
	}
	$j("#h_pre_register_date_from").val($.trim($("#pre_register_date_from").val()));
	$j("#h_pre_register_date_to").val($.trim($("#pre_register_date_to").val()));
});

function getpreregistrationdata(){
	$j('#h_pre_register_date_from').val($j('#pre_register_date_from').val());
	$j('#h_pre_register_date_to').val($j('#pre_register_date_to').val());
	var pre_register_date_from = $.trim($("#pre_register_date_from").val());
	var pre_register_date_to = $.trim($("#pre_register_date_to").val());
	$j(".cls_loader").removeClass('cls_hide');
	$j.ajax({
		url: MODULE_ROUTE_ACCOUNTADMIN_URL+'/getpreRegistrationData',
		data : { pre_register_date_from:pre_register_date_from, pre_register_date_to : pre_register_date_to},
		cache : false,
		dataType : "json",
		type : 'POST',
		success : function(data) {
			$j(".cls_loader").addClass('cls_hide');
			if(data.error_log_out != undefined) {
				location.reload();
				return false;
			}
			window.doTable.fnClearTable();
			if(data != null && data.allData.length>0) {
				window.doTable.fnAddData(data.allData);
				$j('#h_pre_is_data').val('Yes');
				//var html = '<option value="">Select Form</option>';
				//$j.each(data.visitorArray, function (index,value) {
					//html += '<option value="'+value+'">'+value+'</option>';
				//});
				//$("#visitorname").html(html);
			}
			else {
				$j("#id_datatable .dataTables_empty").html("No record found");	
				$j('#h_pre_is_data').val('No');
			}
		},
		error: function() {
			console.log("Error :: Something Wrong On Response!!");
			$j("#id_datatable .dataTables_empty").html('Something Wrong!! Please try again');
			$j(".cls_loader").addClass('cls_hide');
		},
		complete: function(){
			$j(".cls_loader").addClass('cls_hide');
			return false;
		}
	});
}

}
$(document).on("click","#pre_registration",function(){
	$j('#h_pre_register_date_from').val($j('#pre_register_date_from').val());
	$j('#h_pre_register_date_to').val($j('#pre_register_date_to').val());
	getpreregistrationdata();
});	
$(document).on("click",".pre_register_details", function() {
	var ID = $(this).attr("data-id");
	filterSavepreRegistration(ID);
});

function filterSavepreRegistration(ID) {
	var searchAry = {};
	$(".cls_loader").removeClass('cls_hide');
	var current_page = $(".current").text();
	var order_for = $j("#h_order_for").val();
		order_for =(order_for-1);
	var order_by = $j("#h_order_by").val();
		order_by = order_by.toLowerCase();
	var is_checked = '0';
	if($j('.checkall').is(":checked")) {
		is_checked = '1';
	}
	searchAry['filter_settings'] = 'pre_registration_settings';
	searchAry['pre_register_date_from'] = $j('#h_pre_register_date_from').val();
	searchAry['pre_register_date_to'] = $j('#h_pre_register_date_to').val();
	searchAry['pre_register_form_type'] = $j("#visitorname").val();
	searchAry['pre_register_search_value'] = $j("#serach_user").val();
	$.ajax({
		url: MODULE_ROUTE_ACCOUNTADMIN_URL+'/setSessionData',
		type: 'post',
		dataType: "json",
		data: searchAry,
		success: function(data) {
			$(".cls_loader").addClass('cls_hide');
			if(data.error_log_out != undefined) {
				  location.reload();
				  return false;
			}
			var URL = MODULE_ROUTE_ACCOUNTADMIN_URL+'/viewpreregister/'+ID;
			window.location.href = URL;
		},
		error: function() {
			$(".cls_loader").addClass('cls_hide');
		}
	}); 
}
$(document).on('submit','form#pre_dashboard_form',function(){
	var flag_is_data = $("#h_pre_is_data").val();
	if(flag_is_data != "Yes") {
		error_msg(NO_RECORDS_TO_EXPORT);
		return false;
	}
});
/* For Order Sort */
$j(document).ready(function(){
	$j("#h_pre_order_for").val("6");
	$j("#h_pre_order_by").val("DESC");
	$j("#id_datatable th").each(function( index ) {
		$j(document).on('click', '#id_datatable th:nth-child('+(index+1)+')',function(e){
			var flag_sort_by = "";
			if ( $( this ).hasClass( "sorting_desc" ) ) {
				flag_sort_by = "DESC";
			} else {
				flag_sort_by = "ASC";
			}
			var flag_sort_for = index+1;
			$j("#h_pre_order_by").val(flag_sort_by);
			$j("#h_pre_order_for").val(flag_sort_for);
		});
	});
});

$j(document).on("click",".pre_register_delete",function(){
	var historyID = $j(this).attr('data-id');
	$j(".delete_preregister").attr('data-id',historyID);
	$j("#myModal").modal("show");
});

$j(document).on("click",".delete_preregister",function(){
	var dataID = $j(this).attr('data-id');
	$j('#h_pre_register_date_from').val($j('#pre_register_date_from').val());
	$j('#h_pre_register_date_to').val($j('#pre_register_date_to').val());
	var pre_register_date_from = $.trim($("#pre_register_date_from").val());
	var pre_register_date_to = $.trim($("#pre_register_date_to").val());
	if(dataID != '' && dataID != null) {
		$.ajax({
			url: MODULE_ROUTE_ACCOUNTADMIN_URL+'/deletePreregistration/'+dataID,
			type: 'post',
			dataType: "json",
			data: { signin_history_id:dataID },
			success: function(data) {
				$j(".cls_loader").addClass('cls_hide');
				if(data.error_log_out != undefined) {
					location.reload();
					return false;
				}
				$j("#myModal").modal("hide");
				if(data.status == 0) {
					error_msg(data.msg);
				} else {
					getpreregistrationdata();
					success_msg(data.msg);
				}
			},
			error: function() {
				$j("#myModal").modal("hide");
				$(".cls_loader").addClass('cls_hide');
			}
		}); 
	}	
});
//~ ========================= END :: Pre Registration PART  ========================= ~//
