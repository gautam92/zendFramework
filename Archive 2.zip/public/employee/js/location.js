function isPercentage(evt){
	 var valid = /^\d*(.\d{0,2})?$/.test(evt),
	  val = evt;
	if (isNaN(val) || val < 0 || val > 100 || !valid) {
		return val.substring(0, val.length - 1);
	}
	else
	{
		return val;
	}
}
function onlyNumeric(val) {
	var re = /^(?:[1-90]\d*|0)?(?:\.\d+)?$/;
	return re.test(val);
}
	function isPrice(evt){
      var valid = /^\d*(.\d{0,2})?$/.test(evt.value)
        val = evt.value;
      if (isNaN(val) || !valid || val < 0 || val > 100) {
          evt.value = val.substring(0, val.length - 1);
      }
}
function onlyDigit(val) {
	var re = /^\d+$/;
	return re.test(val);
}
	
function isNumber(evt) {
	evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    //console.log(charCode);
    if(charCode == 46 || charCode == 39 || charCode == 37) {
		return true;
	} else if (charCode > 31 && (charCode < 48 || charCode > 57)) {
		return false;
	}
	return true;
}	
	

$('#city_list_id').select2().on("change", function(e) { 
	$('#b_city').val($(this).val());  
	if ($('#city_list_id').val() == null || $('#city_list_id').val() == '') {
		 jQuery('[aria-labelledby=select2-city_list_id-container]').css('border-color','red');
	}
});  

$('#org_pass').val('');
	
jQuery('#location_name').focusout(function(){
   if (jQuery.trim($(this).val()) == null || jQuery.trim($(this).val()) == '') {
		$(this).addClass('cls_error'); 
	}else{
		$(this).removeClass('cls_error');    
	}
});
jQuery('#country_list_id,#state_list_id,#city_list_id').focusout(function(){
	var id = $(this).attr('id');
   if (jQuery.trim($(this).val()) == null || jQuery.trim($(this).val()) == '') {
		jQuery('[aria-labelledby=select2-'+id+'-container]').addClass('cls_error');
	}else{
		jQuery('[aria-labelledby=select2-'+id+'-container]').removeClass('cls_error');    
	}
});

function validation(){
	var error = false;
	var location_name = $.trim($("#location_name").val());
	var country_list_id = $.trim($("#country_list_id").val());
	var state_list_id = $.trim($("#state_list_id").val());
	var city_list_id = $.trim($("#city_list_id").val());
	//alert($("#res_is_delete_sus").is(":checked"))
	if(location_name == '' || location_name == null){
		error = true;
		$("#location_name").addClass('cls_error');
	}
	if(country_list_id == null || country_list_id == '') {
		jQuery('[aria-labelledby=select2-country_list_id-container]').addClass('cls_error');
		error = true;
	}
	if(state_list_id == null || state_list_id == '') {
		jQuery('[aria-labelledby=select2-state_list_id-container]').addClass('cls_error');
		error = true;
	}
	if(city_list_id == null || city_list_id == '') {
		jQuery('[aria-labelledby=select2-city_list_id-container]').addClass('cls_error');
		error = true;
	}
	return error;
}   
// Location Submit 
$('#location_submit').click(function(){
	var error = validation();
	if(error) {
		error_msg(GLOBAL_FORM_REQUIRED_MESSAGE);
		$('html, body').animate({ scrollTop : 0 }, 1000);
	} else {
		$(".cls_loader").removeClass('cls_hide');
		var check_page = $('#check_page').val();        
		var vFD = new FormData(document.getElementById('addlocation')); 
		var addlocationurl = jQuery("#addlocation").attr('action');
		jQuery.ajax({
				url: addlocationurl,
				data: vFD,
				//cache: false,
				processData: false,
				contentType: false,
				dataType: "json",
				type: 'POST',
				success: function(data) {
					if(data.error_log_out != undefined) {
						  location.reload();
						  return false;
					 }
					if(data.error != undefined){
						$(".cls_loader").addClass('cls_hide');
						error_msg(data.error);
						return false;
					}else{
						var location_id = data.id;
						window.location = MODULE_ROUTE_ACCOUNTADMIN_URL+'/settings/viewlocation/'+location_id;
					}
				 },
				error : function(){
					$(".cls_loader").addClass('cls_hide');
					error_msg(GLOBAL_ERROR_MESSAGE);
					return false;
				}
		 });
	}
});
    
$('#country_list_id').select2().on("change", function(e) { 
	$('#org_country').val($(this).val());
	if ($('#country_list_id').val() == null || $('#country_list_id').val() == '') {
		 jQuery('[aria-labelledby=select2-country_list_id-container]').addClass('cls_error');
		 $('#state_list_id').empty();
		 jQuery('[aria-labelledby=select2-state_list_id-container]').children('span:first').html('Select');
		 $('#state_list_id').append('<option>Select state</option>');
	}else{
		$(".cls_loader").removeClass('cls_hide');
		var countryurl = MODULE_ROUTE_ACCOUNTADMIN_URL+'/settings/getstatename';
		var datacountrylist  = 'country_id='+ $(this).val();
		jQuery.ajax({
			type: 'POST',
			url: countryurl,
			dataType: "json",
			async:false,
			data: datacountrylist,
			success: function(data) {
				$(".cls_loader").addClass('cls_hide');
				if(data.error_log_out != undefined) {
					  location.reload();
					  return false;
				 }
				if(data.statenmlist == '' || data.statenmlist == null){}else{
					$('#state_list_id').empty();
					$('#city_list_id').empty();
					jQuery('[aria-labelledby=select2-city_list_id-container]').children('span:first').html('Select');
				   
					jQuery('[aria-labelledby=select2-state_list_id-container]').children('span:first').html('Select');
					if (data == null || data == '') {
						  $('#state_list_id').append('<option>Select state</option>'); 
					}else{
					$('#state_list_id').append('<option value="">Select state</option>');       
					$.each( data['statenmlist'], function( index, value ){
						 $('#state_list_id').append('<option value="'+index+'" newval='+value+'>'+value+'</option>');
					  });
					}
				}
			},
			error : function(){
				$(".cls_loader").addClass('cls_hide');
				error_msg(GLOBAL_ERROR_MESSAGE);
				return false;
			}
		});
		jQuery('[aria-labelledby=select2-country_list_id-container]').removeClass('cls_error');
	}
});
$('#state_list_id').select2().on("change", function(e) { 
	$('#org_state').val($(this).val());
	if ($(this).val() == null || $(this).val() == '') {
		jQuery('[aria-labelledby=select2-state_list_id-container]').addClass('cls_error');
	}else{
		$(".cls_loader").removeClass('cls_hide');
		var stateurl = MODULE_ROUTE_ACCOUNTADMIN_URL+'/settings/getcityname';
		var datastatelist  = 'state_id='+ $(this).val();
		jQuery.ajax({
			type: 'POST',
			url: stateurl,
			dataType: "json",
			async:false,
			data: datastatelist,
			success: function(data) {
				if(data.error_log_out != undefined) {
					  location.reload();
					  return false;
				 }
					$(".cls_loader").addClass('cls_hide');
					$('#city_list_id').empty();
					jQuery('[aria-labelledby=select2-city_list_id-container]').children('span:first').html('Select');
					if (data == null || data == '') {
						  $('#city_list_id').append('<option>Select city</option>'); 
					}else{
						  $('#city_list_id').append('<option value="">Select city</option>'); 
					$.each( data, function( index, value ){
						  $('#city_list_id').append('<option value="'+index+'" newval='+value+'>'+value+'</option>');
					  });
					}
				},
				error : function(){
					$(".cls_loader").addClass('cls_hide');
					error_msg(GLOBAL_ERROR_MESSAGE);
					return false;
				}
			});
		jQuery('[aria-labelledby=select2-state_list_id-container]').removeClass('cls_error');
	}
});
  
$('#city_list_id').select2().on("change", function(e) {
	$('#org_city').val($(this).val());      
	if ($(this).val() == null || $(this).val() == '') {
		jQuery('[aria-labelledby=select2-city_list_id-container]').addClass('cls_error');
	}else{
		jQuery('[aria-labelledby=select2-city_list_id-container]').removeClass('cls_error');
	}    
});        


	
