function replaceAll(str, term, replacement) {
	return str.replace(new RegExp(term, 'g'), replacement);
}	
function onlyDigit(val) {
	var re = /^\d+$/;
	return re.test(val);
}
var isLRating = 0;
$(document).on("click","#next_page",function(){
	var iserror = false;
	if($.trim($("#form_name").val()) == '' || $("#form_name").val() == null) {
		$("#form_name").addClass('cls_error');
		iserror = true;
	} else {
		$("#form_name").removeClass('cls_error');
	}
	if(!iserror) {
		if($("#id_master_form_type").val() == 4) {
			$("#phone_coloumn").addClass("hidden");
			$("#email_coloumn").addClass("hidden");
			$("#host_coloumn").addClass("hidden");
			$(".h_sequence").val('1');
			$("#drag_popup").removeClass('dropup');
			$("#drag_popup").addClass('dropdown');
		} else {
			$("#phone_coloumn").removeClass("hidden");
			$("#email_coloumn").removeClass("hidden");
			$("#host_coloumn").removeClass("hidden");
		}
		$("#signin_create_form").addClass("hidden");
		$("#signin_form_field").removeClass("hidden");
		$("#breadcrumb_text").text("Sign in");
	}
});



$(document).on("click",".add_photo_field",function(){
	var id_photo_html = $("#id_photo_html").html();
	if($("form #id_Photo_field_html").length <= 0) { 
		if($("#id_master_form_type").val() == 4 && $("#is_rating_form").val() == 1) {
			var rating_html = '';
			rating_html+='<div class="card-block fields m-t-20"><select class="form-control" id="h_id_photo_required" name="h_id_photo_required">';
			var RatingValue = JSON.parse( $.trim($("#rating_array").html()));
			if(RatingValue != '' && RatingValue != null) {
				$.each( RatingValue, function( key, value ) {
					rating_html+= "<option value='"+value.master_rating_id+"'>"+value.rating_name+"</option>";
				});
			}
		rating_html+='</select></div>';
		} else {
			var rating_html = '';
			rating_html+='<div class="card-block m-t-20">';
				rating_html+='<div class="checkbox check-success">';
					rating_html+='<input checked="checked" value="1" type="checkbox" id="id_photo_required" name="id_photo_required">';
					rating_html+='<label for="id_photo_required"></label>';
				rating_html+='</div>';
			rating_html+='</div>';
		}
		id_photo_html = replaceAll(id_photo_html,"##REQUIREDFILED##",rating_html);
		$("#h_photo_html").html(id_photo_html);
		$("form #is_profile_photo_applicable").val('1');
		$("#photo_fieled").addClass('hidden');
	}
});
$(document).on("click",".id_photo_delete",function(){
	$("form #id_Photo_field_html").remove();
	$("#photo_fieled").removeClass('hidden');
});

$(document).on("click",".h_id_drodown",function(){
	//$("#dropdown_multi_list_html").find('.dropdown-text-area').text('');
	var DataID = $(this).attr("data-id");
	//alert($("#dropdown_inner_html"+DataID).attr('data-value'));
	if($("#dropdown_inner_html"+DataID).find('.drodown-textbox').length == 3 && $("#dropdown_inner_html"+DataID).attr('data-value') == DataID) {
		return false;
	}  
	if($("#dropdown_inner_html"+DataID).find('.dropdown-text-area').attr("class") == undefined){
		var drop_html = $("#dropdown_list_html").html(); 
		drop_html = replaceAll(drop_html,"#ID#",DataID);
		drop_html = replaceAll(drop_html,"#TEXTVALUE#",'');
		$("#dropdown_inner_html"+DataID).append(drop_html);
	}
	var lines = [];
	$.each($("#dropdown_inner_html"+DataID).find('.dropdown-text-area').text().split(/\n/), function(i, line){
	   if(line && line.length){
		  lines.push(line);
	   }
	});
	if(lines.length > 0) {
		$("#dropdown_inner_html"+DataID).html('');
	}
	$.each(lines, function(index, value) { 
		var drop_html = $("#dropdown_list_html").html(); 
		drop_html = replaceAll(drop_html,"#TEXTVALUE#",value);
		drop_html = replaceAll(drop_html,"#ID#",DataID);
		$("#dropdown_inner_html"+DataID).append(drop_html);
	});
});

$(document).on("click",".id_deleted_dropdown",function(){
	$(this).parent().parent().parent().remove();
});

$(document).on("click",".h_id_drodown_multi",function(){
	var DataID = $(this).attr("data-id");
	if($(this).attr('data-value') == 0) {
		var containtname = '';
		$("#dropdown_inner_html"+DataID+" :text").each(function(){
			containtname += $(this).val() + "\n";
		});
		$("#dropdown_multi_list_html").find('.dropdown-text-area').text(containtname);
		var drop_html = $("#dropdown_multi_list_html").html(); 
		drop_html = replaceAll(drop_html,"#ID#",DataID);
		$("#dropdown_inner_html"+DataID).html(drop_html);
		$(this).attr('data-value','1');
		$("#single_"+DataID).addClass('hidden');
		$(this).text('Switch To Single');
	} else {
		if($.trim($("#dropdown_inner_html"+DataID).find('.dropdown-text-area').val()) == null || $.trim($("#dropdown_inner_html"+DataID).find('.dropdown-text-area').val()) == ''){
			var drop_html = $("#dropdown_list_html").html(); 
			drop_html = replaceAll(drop_html,"#TEXTVALUE#",'');
			drop_html = replaceAll(drop_html,"#ID#",DataID);
			$("#dropdown_inner_html"+DataID).html(drop_html);
			$(this).attr('data-value','0');
			$("#single_"+DataID).removeClass('hidden');
			$(this).text('Add Multiple');
		} else {
			var lines = [];
			//console.log($("#dropdown_inner_html"+DataID).find('.dropdown-text-area').val());
			$.each($("#dropdown_inner_html"+DataID).find('.dropdown-text-area').val().split(/\n/), function(i, line){
			   if(line && line.length){
				  lines.push(line);
			   }
			});
			if(lines.length > 0) {
				$("#dropdown_inner_html"+DataID).html('');
			}
			$.each(lines, function(index, value) { 
				var drop_html = $("#dropdown_list_html").html(); 
				drop_html = replaceAll(drop_html,"#TEXTVALUE#",value);
				drop_html = replaceAll(drop_html,"#ID#",DataID);
				$("#dropdown_inner_html"+DataID).append(drop_html);
			});
			$(this).attr('data-value','0');
			$("#single_"+DataID).removeClass('hidden');
			$(this).text('Add Multiple');
		}
	}
});
var filedcounts = parseInt($(".h_field_total").val());
$(document).on("click",".add_new_text_field",function(){
	filedcounts = (filedcounts+1);
	if(filedcounts > 2) {
		$("#drag_popup").removeClass('dropdown');
		$("#drag_popup").addClass('dropup');
	}
	
	var seqence = parseInt($(".h_sequence").val())+1;
	var h_field_total = parseInt($(".h_field_total").val());
	var dataID = '';
	var dataName = $(this).text();
	if($(this).attr('data-value') == 3 || $(this).attr('data-parent-id') == 3 || $(this).attr('data-value') == 5 || $(this).attr('data-parent-id') == 5 || $(this).attr('data-value') == 4 || $(this).attr('data-parent-id') == 4) {
		var html = $("#id_dropdown_html").html();
		html = replaceAll(html,"#SEQUENCE#",seqence);
		html = replaceAll(html,"#FORMTYPEID#",$(this).attr('data-value'));
		html = replaceAll(html,"#FORMTYPEPARENTID#",$(this).attr('data-parent-id'));
		html = replaceAll(html,"#ID#",h_field_total);
		var rating_html = getRatingHtml(h_field_total,$(this).attr('data-value'));
		html = replaceAll(html,"##REQUIREDFILED##",rating_html);
		html = replaceAll(html,"##RATETYPE##",$(this).attr('data-value'));
		if(isLRating == 1) {
			html = replaceAll(html,"##RATEINGREQUIRED##",'cls_rating_required');
		} else {
			html = replaceAll(html,"##RATEINGREQUIRED##",'');
		}
		if($(this).attr('data-value') == 5 || $(this).attr('data-parent-id') == 5) {
			if($("#id_master_form_type").val() == 4) {
				$("#is_rating_form").val('1');
			}
			html = replaceAll(html,"##CLASS##",'hidden');
			html = replaceAll(html,"##FILEDSCLASS##",'');
			html = replaceAll(html,"disabled",'');
			var drophtml1 = "<option value='5_1'>Number</option>";
				drophtml1+="<option value='5_2'>Icon</option>";
				drophtml1+="<option value='5_3'>Number in color</option>";
				drophtml1+="<option value='5_4'>Icon in color</option>";
			html = replaceAll(html,"##DROPDOWNVALUE##",drophtml1);
			html = replaceAll(html,"##RATEFIELDS##",'cls_rating_field');
			$("#formfield_dynamic_div").append(html);
		} else if($(this).attr('data-value') == 4 || $(this).attr('data-parent-id') == 4) {
			html = replaceAll(html,"##CLASS##",'');
			html = replaceAll(html,"##FILEDSCLASS##",'fields');
			html = replaceAll(html,"disabled",'disabled');
			var drophtml1 = "<option>Radio</option>";
			html = replaceAll(html,"##DROPDOWNVALUE##",drophtml1);
			html = replaceAll(html,"##RADIOID##",h_field_total);
			html = replaceAll(html,"##RADIOCLASS##",'radiolist');
			var drop_html = $("#dropdown_list_html").html(); 
			drop_html = replaceAll(drop_html,"#ID#",h_field_total);
			drop_html = replaceAll(drop_html,"#TEXTVALUE#",'');
			$("#formfield_dynamic_div").append(html);
			$("#dropdown_inner_html"+h_field_total).append(drop_html);
		} else {
			html = replaceAll(html,"##CLASS##",'');
			html = replaceAll(html,"##FILEDSCLASS##",'');
			html = replaceAll(html,"disabled",'');
			var drophtml1 = "<option value='3_1'>Single</option>";
				drophtml1+="<option value='3_2'>Multiple</option>";
				drophtml1+="<option value='3_3'>Single with search</option>";
				drophtml1+="<option value='3_4'>Multiple with search</option>";
			html = replaceAll(html,"##DROPDOWNVALUE##",drophtml1);
			var drop_html = $("#dropdown_list_html").html(); 
			drop_html = replaceAll(drop_html,"#ID#",h_field_total);
			drop_html = replaceAll(drop_html,"#TEXTVALUE#",'');
			$("#formfield_dynamic_div").append(html);
			$("#dropdown_inner_html"+h_field_total).append(drop_html);
		}
		
	} else if($(this).attr('data-value') == 50 || $(this).attr('data-parent-id') == 50) {
		var html = $("#id_rating_html").html();
		html = replaceAll(html,"#SEQUENCE#",seqence);
		html = replaceAll(html,"#FORMTYPEID#",$(this).attr('data-value'));
		html = replaceAll(html,"#FORMTYPEPARENTID#",$(this).attr('data-parent-id'));
		html = replaceAll(html,"#ID#",h_field_total);
		var rating_html = getRatingHtml(h_field_total,$(this).attr('data-value'));
		html = replaceAll(html,"##REQUIREDFILED##",rating_html);
		html = replaceAll(html,"##RATETYPE##",$(this).attr('data-value'));
		$("#formfield_dynamic_div").append(html);
	} else {
		var placeholderName = "";
		var html = $("#id_text_html").html();
		html = replaceAll(html,"#SEQUENCE#",seqence);
		html = replaceAll(html,"#FORMTYPEID#",$(this).attr('data-value'));
		html = replaceAll(html,"#FORMTYPEPARENTID#",$(this).attr('data-parent-id'));
		html = replaceAll(html,"#ID#",h_field_total);
		html = replaceAll(html,"#TEXT#",dataName);
		var rating_html = getRatingHtml(h_field_total,$(this).attr('data-value'));
		html = replaceAll(html,"##REQUIREDFILED##",rating_html);
		html = replaceAll(html,"##RATETYPE##",$(this).attr('data-value'));
		if(isLRating == 1) {
			html = replaceAll(html,"##RATEINGREQUIRED##",'cls_rating_required');
		} else {
			html = replaceAll(html,"##RATEINGREQUIRED##",'');
		}
		$("#formfield_dynamic_div").append(html);
		if($(this).attr('data-value') == 15) {
			$("#formfield_dynamic_div #textfield_html"+h_field_total).find('.form-lable-required').val("NPS");
			$("#formfield_dynamic_div #textfield_html"+h_field_total).find('.form-ph-required').val("How likely would you recommend us?");
		}
	}
	$(".h_sequence").val(seqence);
	$(".h_field_total").val(h_field_total+1);
});

function getRatingHtml(h_field_total,fieldtype){
	var rating_html = '';
	if($("#is_rating_form").val() != '1' || fieldtype == '5') {
		var h_id_required = '';
		if(fieldtype == 5 || $("#is_rating_form").val() > 0) {
			 h_id_required = 'h_id_required';
		}
		rating_html+='<div class="card-block m-t-20"><div class="checkbox check-success '+h_id_required+'">';
		rating_html+='<input checked="checked" value="1" type="checkbox" id="id_required['+h_field_total+']" name="id_required['+h_field_total+']">';
		rating_html+='<label for="id_required['+h_field_total+']"></label>';
		rating_html+='</div></div>';
	} else {
		isLRating = (isLRating+1);
		rating_html+='<div class="card-block fields m-t-20"><select class="form-control rating_dropdown" id="h_id_required['+h_field_total+']" name="h_id_required['+h_field_total+']">';
			var RatingValue = JSON.parse( $.trim($("#rating_array").html()));
			if(RatingValue != '' && RatingValue != null) {
				$.each( RatingValue, function( key, value ) {
					rating_html+= "<option value='"+value.master_rating_id+"'>"+value.rating_name+"</option>";
				});
			}
		rating_html+='</select></div>';
	}
	return rating_html;
} 

$(document).on("change",".rating_dropdown",function(){
	var Dvalue = $(this).val();
	if(Dvalue != '0' && Dvalue != '-1') {
		$(this).addClass('h_id_required');
	} else {
		$(this).removeClass('h_id_required');
	}
});

$(document).on("click",".id_delete_field",function(){
	$("#textfield_html"+$(this).attr('id')).remove();
	if($(this).attr('data-id-dropdown') == 1) {
		$("#dropdown_inner_html"+$(this).attr('id')).remove();
	}
	if($("#id_master_form_type").val() == 4) {
		var aoColumns = [];
		$("form .h_id_required").each(function () {  
			var datavals = $(this).parent().parent().parent().find('.form-sequence-required').val();
			aoColumns.push(datavals);
		});
		if(aoColumns.length == 0) {
			$("#is_rating_form").val('0');
		}
	}
	
	//var h_field_total = parseInt($(".h_field_total").val());
	//$(".h_field_total").val(h_field_total-1);
});

$(document).on("blur","form .form-sequence-required",function(){
	var datavalue = $.trim($(this).val());
	if(datavalue == '' || datavalue == null || datavalue <= 0 || !onlyDigit(datavalue)) {
		$(this).parent().addClass('cls_error');
	} else {
		$(this).parent().removeClass('cls_error');
	}	
});

$(document).on("blur","form .form-lable-required",function(){
	var datavalue = $.trim($(this).val());
	var letters = /^[0-9 a-z A-Z]+$/;
	if(datavalue == '' || datavalue == null  || !datavalue.match(letters)) {
		$(this).parent().addClass('cls_error');
	} else {
		$(this).parent().removeClass('cls_error');
	}	
});
$(document).on("blur","form .form-ph-required",function(){
	var datavalue = $.trim($(this).val());
	if(datavalue == '' || datavalue == null) {
		$(this).parent().addClass('cls_error');
	} else {
		$(this).parent().removeClass('cls_error');
	}	
});


$(document).on("blur","form .dropdown-text-area",function(){
	var datavalue = $.trim($(this).val());
	if(datavalue == '' || datavalue == null) {
		$(this).parent().addClass('cls_error');
	} else {
		$(this).parent().removeClass('cls_error');
	}	
});

$(document).on("blur","form .drodown-textbox",function(){
	var datavalue = $.trim($(this).val());
	if(datavalue == '' || datavalue == null) {
		$(this).parent().addClass('cls_error');
	} else {
		$(this).parent().removeClass('cls_error');
	}	
});

function validationJquery(){
	var error = false;
	var letters = /^[0-9 a-z A-Z]+$/;
	$("form .form-lable-required").each(function () {  
		var datavalue = $.trim($(this).val());
		if(datavalue == '' || datavalue == null || !datavalue.match(letters)) {
			$(this).parent().addClass('cls_error');
			error = true;
		} else {
			$(this).parent().removeClass('cls_error');
		}
	}); 
	$("form .dropdown-text-area").each(function () {  
		var datavalue = $.trim($(this).val());
		if(datavalue == '' || datavalue == null) {
			$(this).parent().addClass('cls_error');
			error = true;
		} else {
			$(this).parent().removeClass('cls_error');
		}
	}); 
	
	$("form .h_id_drodown").each(function () {  
		var id = $(this).attr('data-id');
		if(!$(this).is(':hidden')) {
			if($('form #dropdown_inner_html'+id).find('.drodown-textbox').length <= 0 && $('form #dropdown_inner_html'+id).find('.dropdown-text-area').length <= 0) {
				error_msg('Please add dropdown value');
				error = true;
			} else if($('form #dropdown_inner_html'+id).find('.dropdown-text-area').length <= 0 && $('form #dropdown_inner_html'+id).find('.drodown-textbox').length <= 0) {
				error_msg('Please add dropdown value');
				error = true;
			}
		}
	});
	$("form .drodown-textbox").each(function () {  
		var datavalue = $.trim($(this).val());
		if(datavalue == '' || datavalue == null) {
			$(this).parent().addClass('cls_error');
			error = true;
		} else {
			$(this).parent().removeClass('cls_error');
		}
	}); 
	var ratingflg = 0;
	$("form .form-sequence-required").each(function () {  
		var datavalue = $.trim($(this).val());
		var datarating = $.trim($(this).attr('data-value'));
		if(datarating == 5) {
			ratingflg++;
		}
		if(datavalue == '' || datavalue == null || datavalue <= 0 || !onlyDigit(datavalue)) {
			$(this).parent().addClass('cls_error');
			error = true;
		} else {
			$(this).parent().removeClass('cls_error');
		}
	}); 
	
	
	if(ratingflg <= 0 && $("#id_master_form_type").val() == 4) {
		error_msg('Please add rating field');
		error = true;
	}
	
	if($("#id_master_form_type").val() == 4) {
		var flgerror = false;
		var flgerror1 = false;
		var requierdfld = $("form .cls_rating_required:first").parents().prevAll('.row').find('.form-sequence-required').attr('data-value');
		var breakflg = 0;
		var aoColumns = [];
		var aoColumns1 = [];
		$("form .h_id_required").each(function () {  
			var datavalues = $(this).parent().parent().parent().find('.form-sequence-required').attr('data-value');
			if(datavalues == 5) {
				if(!$(this).find('input:checkbox').is(":checked")) {
					flgerror1 = true;	
				}
				var datavals1 = $(this).parent().parent().parent().find('.form-sequence-required').val();
				aoColumns1.push(datavals1);
			} else {
				var datavals = $(this).parent().parent().parent().find('.form-sequence-required').val();
				aoColumns.push(datavals);
			}
		});
		
		var minseq = Math.min.apply(Math,aoColumns1); // 1
		$.each(aoColumns, function (index,value) {
			console.log(value);
			if(parseInt(minseq) >= parseInt(value)) {
				error_msg('Form Not Valid');
				error = true;
				flgerror = true;
			}
		});
		if(flgerror) {
			error_msg('Form Not Valid');
			error = true;
		} else if(flgerror1) {
			error_msg('All rating field are required');
			error = true;
		}
	}
	$("form .form-ph-required").each(function () {  
		var datavalue = $.trim($(this).val());
		if(datavalue == '' || datavalue == null) {
			$(this).parent().addClass('cls_error');
			error = true;
		} else {
			$(this).parent().removeClass('cls_error');
		}
	}); 
	$("form .form-ph-required").each(function () {  
		var datavalue = $.trim($(this).val());
		if(datavalue == '' || datavalue == null) {
			$(this).parent().addClass('cls_error');
			error = true;
		} else {
			$(this).parent().removeClass('cls_error');
		}
	}); 
	
	$('form .radiolist').each(function(){
		var radiolength = $(this).find('.drodown-textbox').length;
		//var dropdowntextarea = $(this).find('.dropdown-text-area');
		var datavalues = $(this).attr("data-value");
		//sif(radiolength > 3 && radiolength > 0) {
		//	$(".id_dropdown_name"+datavalues).addClass('cls_error');
		//	error = true;
		//} else 
		if($("#dropdown_inner_html"+datavalues).length > 0 && radiolength <= 0) {
			var lines = [];
			$.each($("#dropdown_inner_html"+datavalues).find('.dropdown-text-area').val().split(/\n/), function(i, line){
			   if(line && line.length){
				  lines.push(line);
			   }
			});
//lines.length > 3 || 
			if(lines.length <= 0) {
				$(".id_dropdown_name"+datavalues).addClass('cls_error');
				error = true;
			} else {
				$(".id_dropdown_name"+datavalues).removeClass('cls_error');
			}
		} else {
			//$(".id_dropdown_name"+datavalues).removeClass('cls_error');
		}
	});
	return error;
}

 $(document).on("click", "#submit_signin_form", function() {
	var error = validationJquery();
	if(error) {
		$('html, body').animate({ scrollTop : 0 }, 1000);
	} else {
		$(".cls_loader").removeClass('cls_hide');
		var Bcnurl = jQuery("#addsigninform").attr('action');
		var vFD = new FormData(document.getElementById("addsigninform")); 
		$.ajax({
			type : 'POST',
			url : Bcnurl,
			dataType : "json",
			data : vFD,
			cache: false,
			processData: false,
			contentType: false,
			success : function(data) {
				$('.cls_loader').addClass('cls_hide');
				if(data.error_log_out != undefined) {
				  location.reload();
				  return false;
				}
				if(data.status == 1) {
					if(data.data_param == 1) {
						window.location = MODULE_ROUTE_ACCOUNTADMIN_URL+'/settings/signout';
					} else {
						window.location = MODULE_ROUTE_ACCOUNTADMIN_URL+'/settings/signin';
					}
				} else {
					error_msg(data.msg);
				}
			},
			error : function(){
				$(".cls_loader").addClass('cls_hide');
				error_msg(GLOBAL_ERROR_MESSAGE);
				return false;
			}
		});
	}
 });
 
$(document).on("change","#visitor_sign_out",function(){
	if($(this).is(":checked")) {
		$(".show-signout").removeClass("hidden");
	} else {
		$(".show-signout").addClass("hidden");
	}
});
$(document).on("click",".is_field_display",function(){
	var id = '.'+$(this).attr('id');
	var dataid = '.'+$(this).attr('data-value');
	if(!$(this).is(":checked")) {
		$(dataid).prop('readonly',true);
		$(dataid).parent().parent().find('.has-class-remove').addClass("fields");
		$(dataid).parent().parent().find('.check-success:first').parent().addClass("readonly");
	} else {
		$(dataid).prop('readonly',false);
		$(dataid).parent().parent().find('.has-class-remove').removeClass("fields");
		$(dataid).parent().parent().find('.check-success:first').parent().removeClass("readonly");
	}
});

$(document).ready(function(){
	if($("#id_master_form_type").val() == 4) {
		if(parseInt($(".h_field_total").val()) > 2) {
			$("#drag_popup").removeClass('dropdown');
			$("#drag_popup").addClass('dropup');
		}	
	}
});
