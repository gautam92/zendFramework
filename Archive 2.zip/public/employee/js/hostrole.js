function replaceAll(str, term, replacement) {
	return str.replace(new RegExp(term, 'g'), replacement);
}	 	
var locationJosonArr = {};
var fldDropDown = 0;
$(document).on("click",".edit_btn",function(){
	var DataID = $(this).attr("data-value");
	$("#view"+DataID).addClass("hidden");	
	$("#edit"+DataID).removeClass("hidden");	
});

$(document).on("click",".edit_cancel",function(){
	var DataID = $(this).attr("data-value");
	document.getElementById("hostroleForm"+DataID+"").reset(); 
	$(".hostroleForm"+DataID).find("select").removeAttr('disabled');
	$(".hostroleForm"+DataID).find("tr").removeAttr('style');
	$(this).parent().parent().parent().find('.h_host_innerhtml').remove();
	$("#view"+DataID).removeClass("hidden");	
	$("#edit"+DataID).addClass("hidden");	
});

$(document).on("click",".addlocation",function(){
	var id = $(this).attr("data-id");	
	$("#view"+id+" .nodata").remove();
	$("#edit"+id+" .nodata").remove();
	var copyHtml = $("#copy_inner_html").html();
	$(".replacebody"+id).append(copyHtml);
});
$(document).on("click",".cls_delete",function(){
	var id = $(this).attr("data-id");	
	$(this).parent().parent().find("select").attr('disabled','disabled');
	$(this).parent().parent().hide();	
});
$(document).on("change",".location_id",function(){
	if($(this).val() == '' || $(this).val() == null) {
		$(this).addClass('cls_error');
	} else {
		$(this).removeClass('cls_error');
	}
});
$(document).on("change",".location_role_id",function(){
	if($(this).val() == '' || $(this).val() == null) {
		$(this).addClass('cls_error');
	} else {
		$(this).removeClass('cls_error');
	}
});

function validation() {
	var error = false;
	var location_list = $.trim($("#location_list").val());
	var organization_master_employee_id = $.trim($("#organization_master_employee_id").val());
	if(location_list == '' || location_list == null || location_list == undefined) {
		//$(".add_table_row #location_list").addClass('cls_error');
		jQuery('[aria-labelledby=select2-location_list-container]').addClass('cls_error');
		error = true;
	} else {
		jQuery('[aria-labelledby=select2-location_list-container]').removeClass('cls_error');
	}
	if(organization_master_employee_id == '' || organization_master_employee_id == null || organization_master_employee_id == undefined) {
		//$(".add_table_row #organization_master_employee_id").addClass('cls_error');
		jQuery('[aria-labelledby=select2-organization_master_employee_id-container]').addClass('cls_error');
		error = true;
	} else {
		jQuery('[aria-labelledby=select2-organization_master_employee_id-container]').removeClass('cls_error');
	}
	var texts = new Array();
	texts= $(".add_table_row .location_id:not(:disabled)").map(function() {
		return $(this).val();         
	}).get();
	
	duplicates = texts.reduce(function(acc, el, i, arr) {
	  if (arr.indexOf(el) !== i && acc.indexOf(el) < 0) acc.push(el); return acc;
	}, []);
	$(".add_table_row .location_role_id:not(:disabled)").each(function(){
		if($(this).val() == '' || $(this).val() == null) {
			$(this).addClass('cls_error');
			error = true;
		} else {
			$(this).removeClass('cls_error');
		}
	});
	$(".add_table_row .location_id:not(:disabled)").each(function() {
		if(duplicates.indexOf($(this).val()) == '0' && $(this).val() != ''){
			$(this).addClass('cls_error');
			$("#error").text('Your selected location is duplicate');
			$("#error").removeClass('hidden');
			error = true;
		} else if($(this).val() == '' || $(this).val() == null) {
			$(this).addClass('cls_error');
			error = true;
		} else {
			$(this).removeClass('cls_error');
		}
	});
	//~ if($(".add_table_row .location_id").length <= 0) {
		//~ $("#error").text('Please add atleast one location role');
		//~ $("#error").removeClass('hidden');
		//~ error = true;
	//~ }
	return error;
}

function form_validation(id) {
	var error = false;
	
	var texts = new Array();
	texts= $(".hostroleForm"+id+" .location_id:not(:disabled)").map(function() {
		return $(this).val();         
	}).get();
	
	duplicates = texts.reduce(function(acc, el, i, arr) {
	  if (arr.indexOf(el) !== i && acc.indexOf(el) < 0) acc.push(el); return acc;
	}, []);
	$(".hostroleForm"+id+" .location_role_id:not(:disabled)").each(function(){
		if($(this).val() == '' || $(this).val() == null) {
			$(this).addClass('cls_error');
			error_msg('Please select location role');
			error = true;
		} else {
			$(this).removeClass('cls_error');
		}
	});
	$(".hostroleForm"+id+" .location_id:not(:disabled)").each(function(){
		if(duplicates.indexOf($(this).val()) == '0' && $(this).val() != ''){
			$(this).addClass('cls_error');
			error_msg('Your selected location is duplicate');
			error = true;
		} else if($(this).val() == '' || $(this).val() == null) {
			error_msg('Please select location');
			$(this).addClass('cls_error');
			error = true;
		} else {
			$(this).removeClass('cls_error');
		}
	});
	//~ if($(".hostroleForm"+id+" .location_id").length <= 0) {
		//~ error_msg('Please add atleast one location role');
		//~ error = true;
	//~ }
	return error;
}

$(document).on("click","#save_modal",function(){
	var id = $(this).attr("data-id");	
	var error = validation();
	if(!error){
		$(".cls_loader").removeClass('cls_hide');
		var URL = $(".addhostroleForm").attr('action');
		var vFD = new FormData(document.getElementById('addhostroleForm')); 
		$.ajax({
			type : 'POST',
			url : URL,
			dataType : "json",
			data : vFD,
			cache: false,
			processData: false,
			contentType: false,
			success : function(data) {
				$('.cls_loader').addClass('cls_hide');
				if(data.error_log_out != undefined) {
				  location.reload();
				  return false;
				}
				if(data.status == 1) {
					$("#id_modal_cancel").trigger("click");
					location.reload();
					//var html = "";
					//~ $.each(data.updateData, function(key,val) {
						//~ html += "<tr>";
							//~ $.each(val, function(k,v) {
								//~ html +='<td class="v-align-middle">'+v.location_name+'</td>';
								//~ html +='<td class="v-align-middle">'+v.user_role_name+'</td>';
							//~ });
						//~ html += "<tr>";
					//~ });
					//$("#viewrole"+id).html(html);
					//$("#view"+id).removeClass("hidden");	
					//$("#edit"+id).addClass("hidden");	
					//var edit_html = $(".add_table_row").html();
					//edit_html = replaceAll(edit_html,"cls_delete_modal_row",'cls_delete');
					//$(".replacebody"+id).html(edit_html);
					//~ if($(".hostroleForm"+id+" .location_id").length <= 0) {
						//~ var html='<tr id="nodata">';
							//~ html+='<td colspan="3" align="center">No data found</td>';
						//~ html+='</tr>';
						//~ $("#view"+id).html(html);
						//~ $("#edit"+id).html(html);
					//~ }
				} else {
					error_msg(data.msg);
				}
			},
			error: function(){  // error handling
				error_msg(GLOBAL_ERROR_MESSAGE);
				$('.cls_loader').addClass('cls_hide');
				return false;
			}
		});
	}
});

$(document).on("click",".save_host_role",function(){
	var id = $(this).attr("data-id");	
	var error = form_validation(id);
	if(!error){
		$(".cls_loader").removeClass('cls_hide');
		var URL = $(".hostroleForm"+id).attr('action');
		var vFD = new FormData(document.getElementById('hostroleForm'+id+'')); 
		$.ajax({
			type : 'POST',
			url : URL,
			dataType : "json",
			data : vFD,
			cache: false,
			processData: false,
			contentType: false,
			success : function(data) {
				$('.cls_loader').addClass('cls_hide');
				if(data.error_log_out != undefined) {
				  location.reload();
				  return false;
				}
				//console.log(data.updateData);
				if(data.status == 1) {
					$(".hostroleForm"+id).find("select:disabled").parent().parent().remove();
					if($(".hostroleForm"+id+" select:enabled").length > 0) {
						var html1 = "";
						$.each(data.updateData, function(key,val) {
							html1 += "<tr>";
								$.each(val, function(k,v) {
									if(v.user_role_name != '' && v.user_role_name != null) {
										html1 +='<td class="v-align-middle">'+v.location_name+'</td>';
										html1 +='<td class="v-align-middle">'+v.user_role_name+'</td>';
									}
								});
							html1 += "<tr>";
						});
						if($(".hostroleForm"+id+" .location_id").length <= 0) {
							var html1='<tr id="nodata">';
								html1+='<td colspan="3" align="center">No data found</td>';
							html1+='</tr>';
							$("#view"+id).html(html1);
							$("#edit"+id).html(html1);
						}
						$("#viewrole"+id).html(html1);
						$("#view"+id).removeClass("hidden");	
						$("#edit"+id).addClass("hidden");	
					
					
					// EDIT HTML //
					
					var html = "";
					var locationJson = "";
					var employeeJson = "";
					if($("#locationJson").text() != '') {
						locationJson = JSON.parse($("#locationJson").text());
					}
					if($("#locationJson").text() != '') {
						employeeJson = JSON.parse($("#employeeJson").text());
					}
					var flg_emp = 0;
					$.each(data.updateData, function(key,val) {
						var location_ids = JSON.parse($("#location_ids").val());
							$.each(val, function(k,v) {
								if($.inArray(k,location_ids) != -1 && v.master_employee_role_id != 6 && v.master_employee_role_id != null) {
									html += "<tr>";
									html += '<td class="v-align-middle semi-bold">';
										html += '<select class="form-control location_id" name="location_id[]">';
										html += '<option value="">Select</option>'; 
											$.each(locationJson, function(key1,val1) {
												var sele = "";
												//if(val1.location_id != locationJosonArr[val1.location_id]) {
												if(v.location_id == val1.location_id) {
													locationJosonArr[val1.location_id] = val1.location_id;
													sele="selected='selected'";
												}
												html += '<option '+sele+' value="'+val1.location_id+'">'+val1.location_name+'</option>';
												//}
											});
										html += '</select>';
									html += '</td>';
									html += '<td class="v-align-middle">';
										html += '<select class="form-control location_role_id" name="location_role_id[]">';
										html += '<option value="">Select</option>'; 
											$.each(employeeJson, function(key2,val2) {
												var sele = "";
												if(v.master_employee_role_id == val2.master_employee_role_id) {
													sele="selected='selected'";
												}
												 html += '<option '+sele+' value="'+val2.master_employee_role_id+'">'+val2.user_role_name+'</option>';
											});
										html += '</select>';
									html += '</td>';
									html += '<td class="v-align-middle text-center">';
										html += '<button type="button" class="btn btn-danger cls_delete_modal_row" data-id="'+id+'">';
											html += '<i class="fs-16 fa fa-trash"></i>';
										html += '</button>';
									html += '</td>';
									html += "<tr>";
									flg_emp = (flg_emp+1);
								}
							});
					});
					// EDIT HTML //
					$(".replacebody"+id+"").html(html);
				}
					if($(".hostroleForm"+id+" select:enabled").length <= 0) {
						$("#view"+id).addClass('hidden');
						$("#view"+id).parent().parent().addClass("hidden");
						$("#edit"+id).addClass('hidden');
					}
					success_msg(data.msg);
				} else {
					error_msg(data.msg);
				}
			},
			error: function(){  // error handling
				error_msg(GLOBAL_ERROR_MESSAGE);
				$('.cls_loader').addClass('cls_hide');
				return false;
			}
		});
	}
});
$(document).on("change",".location_id",function(){
	var ID = $(this).val();
	//$("option",this).removeAttr('selected');
	$('option[value='+ID+']',this).attr('selected','selected');
});
$(document).on("change",".location_role_id",function(){
	var ID = $(this).val();
	$('option[value='+ID+']',this).attr('selected','selected');
});
$(document).on("change","#organization_master_employee_id",function(){
	var ID = $(this).val();
	if(ID == '' || ID == null) {
		return false;
	}
	$("#save_modal").attr("data-id",ID);
	$(".cls_loader").removeClass('cls_hide');
	$.ajax({
			type : 'POST',
			url : MODULE_ROUTE_ACCOUNTADMIN_URL+'/hostdirectory/gethostwiselocationdetails',
			dataType : "json",
			data : { organization_master_employee_id:ID },
			success : function(data) {
				$('.cls_loader').addClass('cls_hide');
				if(data.error_log_out != undefined) {
				  location.reload();
				  return false;
				}
				$(".add_table_row").html('');
				var html = '';
				if(data.status == 1) {
					var html = "";
					var locationJson = "";
					var employeeJson = "";
					if($("#locationJson").text() != '') {
						locationJson = JSON.parse($("#locationJson").text());
					}
					if($("#locationJson").text() != '') {
						employeeJson = JSON.parse($("#employeeJson").text());
					}
					var flg_emp = 0;
					$.each(data.hostLocationrole, function(key,val) {
						var location_ids = JSON.parse($("#location_ids").val());
							$.each(val, function(k,v) {
								if($.inArray(k,location_ids) != -1 && v.master_employee_role_id != 6 && v.master_employee_role_id != null) {
									html += "<tr>";
									html += '<td class="v-align-middle semi-bold">';
										html += '<select class="form-control location_id" name="location_id[]">';
										html += '<option value="">Select</option>'; 
											$.each(locationJson, function(key1,val1) {
												var sele = "";
												//if(val1.location_id != locationJosonArr[val1.location_id]) {
												if(v.location_id == val1.location_id) {
													locationJosonArr[val1.location_id] = val1.location_id;
													sele="selected='selected'";
												}
												html += '<option '+sele+' value="'+val1.location_id+'">'+val1.location_name+'</option>';
												//}
											});
										html += '</select>';
									html += '</td>';
									html += '<td class="v-align-middle">';
										html += '<select class="form-control location_role_id" name="location_role_id[]">';
										html += '<option value="">Select</option>'; 
											$.each(employeeJson, function(key2,val2) {
												var sele = "";
												if(v.master_employee_role_id == val2.master_employee_role_id) {
													sele="selected='selected'";
												}
												 html += '<option '+sele+' value="'+val2.master_employee_role_id+'">'+val2.user_role_name+'</option>';
											});
										html += '</select>';
									html += '</td>';
									html += '<td class="v-align-middle text-center">';
										html += '<button type="button" class="btn btn-danger cls_delete_modal_row">';
											html += '<i class="fs-16 fa fa-trash"></i>';
										html += '</button>';
									html += '</td>';
									html += "<tr>";
									flg_emp = (flg_emp+1);
								}
							});
					});
					if(flg_emp > 0) {
						$(".add_table_row").html(html);
					} else if($(".add_table_row .location_id:not(:disabled)").length <= 0) {
						$("#nodata").remove();
						var copyHtml = $("#copy_inner_html").html();
						copyHtml = replaceAll(copyHtml,"cls_delete",'cls_delete_modal_row');
						$(".add_table_row").append(copyHtml);	
					} else {
						var html='<tr id="nodata">';
							html+='<td colspan="3" align="center">No data found</td>';
						html+='</tr>';
						$(".add_table_row").html(html);
					}
					$("#role_mgt").removeClass("hidden");
					$("#save_modal").removeClass("hidden");
				} else {
					var html='<tr id="nodata">';
						html+='<td colspan="3" align="center">No data found</td>';
					html+='</tr>';
					$("#add_table_row").html(html);
					error_msg(data.msg);
				}
			},
			error: function(){  // error handling
				error_msg(GLOBAL_ERROR_MESSAGE);
				$('.cls_loader').addClass('cls_hide');
				return false;
			}
		});
});


$(document).on("change","#location_list",function(){
	var error = false;
	if($(this).val() == '' || $(this).val() == null) {
		$("#organization_master_employee_id").select2("val", "");
		//$("#organization_master_employee_id").html("");
		$("#role_mgt").addClass("hidden");
		$("#save_modal").addClass("hidden");
		error = true;
	}
	if(!error){
		$("#organization_master_employee_id").select2("val", "");
		//jQuery('[aria-labelledby=select2-location_list-container]').removeClass('cls_error');
		$("#role_mgt").addClass("hidden");
		$("#save_modal").addClass("hidden");
		$(".cls_loader").removeClass('cls_hide');
		var datavalue = $(this).val();
		$.ajax({
			type : 'POST',
			url : MODULE_ROUTE_ACCOUNTADMIN_URL+'/hostdirectory/getlocationwisehostdata',
			dataType : "json",
			data : {location_id:datavalue},
			success : function(data) {
				$('.cls_loader').addClass('cls_hide');
				if(data.error_log_out != undefined) {
				  location.reload();
				  return false;
				}
				var html = '';
				//console.log();
				if(data.hostlocJsonData != null && data.hostlocJsonData != '') {
					$("#locationJson").text(JSON.stringify(data.hostlocJsonData));
				} else {
					$("#locationJson").text(JSON.stringify(data.hostlocJsonData));
				}
				if(data.status == 1) {
					if (data.hostEmpData == null || data.hostEmpData == '') {
					   html += '<option value="">Select</option>'; 
					   $("#organization_master_employee_id").html(html);
					} else {
						  html += '<option value="">Select</option>';
						  $.each( data.hostEmpData, function( index, value ){
							  html += '<option value="'+index+'" data-value="'+value.id+'">'+value.name+'</option>';
						  });
						  $("#organization_master_employee_id").html(html);
					}
				} else {
					 var html = '<option value="">Select</option>';
					$("#organization_master_employee_id").html(html);
					error_msg(data.msg);
				}
			},
			error: function(){  // error handling
				error_msg(GLOBAL_ERROR_MESSAGE);
				$('.cls_loader').addClass('cls_hide');
				return false;
			}
		});
	} 
});
$(document).on("change","#organization_master_employee_id",function(){
	var employee_id = $(this).find(':selected').attr('data-value');
	$("#location_employees_ids").val(employee_id);
});
$(document).on("click","#addlocationBtn",function(){
	document.getElementById("addhostroleForm").reset();
	$("#location_list").select2("val", ""); 	
	$("#organization_master_employee_id").select2("val", ""); 	
	$("#role_mgt").addClass("hidden");
	$("#save_modal").addClass("hidden");
	$("#error").addClass('hidden');
});
$(document).on("click",".add_host_modal",function(){
	$("#nodata").remove();
	var copyHtml = $("#copy_inner_html").html();
	copyHtml = replaceAll(copyHtml,"cls_delete",'cls_delete_modal_row');
	$(".add_table_row").append(copyHtml);	
});

$(document).on("click",".cls_delete_modal_row",function(){
	$(this).parent().parent().remove();	
	if($(".cls_delete_modal_row").length <= 0) {
		var html='<tr id="nodata">';
			html+='<td colspan="3" align="center">No data found</td>';
		html+='</tr>';
		$(".add_table_row").append(html);
	}
});
