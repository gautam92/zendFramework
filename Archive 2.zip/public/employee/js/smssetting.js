$(document).on("blur","#sender_id",function(){
	if($.trim($(this).val()) == '' || $.trim($(this).val()) == null || $.trim($(this).val()).length > 6 || $.trim($(this).val()).length < 6) {
		$(this).addClass('cls_error');
	} else {
		$(this).removeClass('cls_error');
	}
});

$("#sender_id").on('keydown', function(e) {
    if (e.which == 13) {
        e.preventDefault();
        $("#save_sender").trigger("click");
    }
});
$(document).on("click","#save_sender",function(){ 
	var sender_id = $.trim($("#sender_id").val());
	var orginization_sms_account_id = $.trim($("#orginization_sms_account_id").val());
	var is_error = false;
	if(sender_id == '' || sender_id == null || sender_id.length > 6 || sender_id.length < 6) {
		$("#sender_id").addClass('cls_error');
		is_error = true;
	} else {
		$("#sender_id").removeClass('cls_error');
	}
	if(!is_error) {
		$.ajax({
			type : 'POST',
			url : MODULE_ROUTE_ACCOUNTADMIN_URL+'/smssettings/updateSenderId',
			dataType : "json",
			data : {orginization_sms_account_id:orginization_sms_account_id,sender_id:sender_id},
			success : function(data) {
				$('.cls_loader').addClass('cls_hide');
				if(data.error_log_out != undefined) {
				  location.reload();
				  return false;
				}
				if(data.status == 1) {
					success_msg(data.msg);
				} else {
					error_msg(data.msg);
				}
			},
			error : function(){
				error_msg(GLOBAL_ERROR_MESSAGE);
				$('.cls_loader').addClass('cls_hide');
				return false;
			}
		});
	}
});
$(document).on("click",".accout_submit",function(){
	$(".cls_loader").removeClass('cls_hide');
	var Bcnurl = jQuery("#smssettings").attr('action');
	var vFD = new FormData(document.getElementById('smssettings')); 
	$.ajax({
		type : 'POST',
		url : Bcnurl,
		dataType : "json",
		data : vFD,
		cache: false,
		processData: false,
		contentType: false,
		success : function(data) {
			$('.cls_loader').addClass('cls_hide');
			if(data.error_log_out != undefined) {
			  location.reload();
			  return false;
			}
			if(data.status == 1) {
				$("#sms_activation_div").addClass("hidden");
				$("#sms_pending_sms_div").removeClass("hidden");
			} else {
				error_msg(data.msg);
			}
		},
		error : function(){
			error_msg(GLOBAL_ERROR_MESSAGE);
			$('.cls_loader').addClass('cls_hide');
			return false;
		}
	});
});
