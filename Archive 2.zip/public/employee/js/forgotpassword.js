jQuery(document).ready(function(){
var filter = /^[_a-zA-Z0-9-]+(\.[_a-zA-Z0-9-]+)*@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*(\.[a-zA-Z]{2,10})$/;	
    jQuery('#email').focusout(function(){
    	if ($(this).val() == null || $(this).val() == '') {
            $(this).addClass('cls_error');    
        }else if(!filter.test($(this).val())){
            $(this).addClass('cls_error');
        }else{
            $(this).removeClass('cls_error'); 
        }
    });  
  
$(document).on("blur","#id_email",function(){
	var id_email = $.trim($(this).val());
	if (id_email == null || id_email == '') {
		$(this).addClass('cls_error');    
	}else if(!filter.test(id_email)){
		$(this).addClass('cls_error');
	}else{
		$(this).removeClass('cls_error'); 
	}
});
$(document).on("click","#resend_email",function(){
	$("#mail_email_id").text('-');
	$("#forgot_password_div").removeClass("hidden");
	$("#forgot_password_mail_div").addClass("hidden");
});
$(document).keypress(function(e) {
    if(e.which == 13) {
       $("#forgot_pass").click();
       return false;
    }
});

$(document).on("click","#forgot_pass",function(){
	var id_email = $.trim($("#id_email").val());
	var error = false;
	if(id_email == '' || id_email == null || !filter.test(id_email)) {
		$("#id_email").addClass("cls_error");
		error = true;
	}
	if(!error) {
		var form_data = new FormData(document.getElementById('forgotpassword'));
		var forgoturl = jQuery("#forgotpassword").attr('action');
		var msg_res = true;
		jQuery('#cls_loader').removeClass('cls_hide');
		jQuery.ajax({
			type : 'POST',
			url : forgoturl,
			dataType : "json",
			data :  form_data,
			processData : false,
			contentType : false,
			success : function(data) {
				jQuery('#cls_loader').addClass('cls_hide');
				if (data != undefined) {
					if (data.status == 0){
						error_msg(data.msg);
						return false;
					} else {
						$("#mail_email_id").text('- '+id_email);
						$("#forgot_password_div").addClass("hidden");
						$("#forgot_password_mail_div").removeClass("hidden");
					}
				}
			},
			error : function(){
				$(".cls_loader").addClass('cls_hide');
				error_msg(GLOBAL_ERROR_MESSAGE);
				return false;
			}
		});
	}
})
});
