$("#brand_logo").change(function() {
	var val = $(this).val();
	switch(val.substring(val.lastIndexOf('.') + 1).toLowerCase()){
		case 'png':
		case 'jpg':
		case 'jpeg':
		case 'gif':
			break;
		default:
			$(this).val('');
			error_msg('File format not supported.');
			break;
	}
});
$("#welcome_image").change(function() {
	var val = $(this).val();
	switch(val.substring(val.lastIndexOf('.') + 1).toLowerCase()){
		case 'png':
		case 'jpg':
		case 'jpeg':
		case 'gif':
			break;
		default:
			$(this).val('');
		error_msg('File format not supported.');
		break;
	}
});
$(document).on("blur","#sign_up_button_text",function(){
	var sign_up_button_text = $.trim($(this).val());
	if(sign_up_button_text == '' || sign_up_button_text == null) {
		$(this).addClass("cls_error");
	} else {
		$(this).removeClass("cls_error");
	}
});	
 $(document).on("click", "#branding_submit", function() {
	var error = false;
	var myfile = $('#brand_logo').val();
	var ext = myfile.split('.').pop();
	var myfile1 = $('#welcome_image').val();
	var sign_up_button_text = $.trim($('#sign_up_button_text').val());
	var ext1 = myfile1.split('.').pop();
	$("#sign_up_button_text").removeClass("cls_error");
	if(myfile.trim() != "" && ext != 'png' && ext != 'jpg' && ext != 'jpeg' && ext != "gif"){
		error_msg('File format not supported.');
		error = true;
	} 
	if(myfile1.trim() != "" && ext1 != 'png' && ext1 != 'jpg' && ext1 != 'jpeg' && ext1 != "gif"){
		error_msg('File format not supported.');
		error = true;
	} 
	if(sign_up_button_text == '' || sign_up_button_text == null) {
		$("#sign_up_button_text").addClass("cls_error");
		error = true;
	}
	if(error) {
		$('html, body').animate({ scrollTop : 0 }, 1000);
	} else {
		$(".cls_loader").removeClass('cls_hide');
		var chPage = $("#check_page").val();
		var Bcnurl = jQuery("#"+chPage).attr('action');
		var vFD = new FormData(document.getElementById(chPage)); 
		$.ajax({
			type : 'POST',
			url : Bcnurl,
			dataType : "json",
			data : vFD,
			cache: false,
			processData: false,
			contentType: false,
			success : function(data) {
				$('.cls_loader').addClass('cls_hide');
				if(data.error_log_out != undefined) {
				  location.reload();
				  return false;
				}
				if(data.succ_msg) {
					success_msg(data.succ_msg);
					if(data.dataIDs['signupID'] != '' && data.dataIDs['signupID'] != null && data.dataIDs['signupID'] > 0) {
						$("#sign_up_location_entity_id").val(data.dataIDs['signupID']);
					}
					if(data.dataIDs['visitorID'] != '' && data.dataIDs['visitorID'] != null && data.dataIDs['visitorID'] > 0) {
						$("#visitor_location_entity_id").val(data.dataIDs['visitorID']);
					}
				} else {
					error_msg(data.error);
				}
			},
			error : function(){
				$(".cls_loader").addClass('cls_hide');
				error_msg(GLOBAL_ERROR_MESSAGE);
				return false;
			 }
		});
	}
 });
  
jQuery(document).ready(function(){
  jQuery(".isa_success").removeClass("hide_eroor").delay(2000).queue(function(){
	  jQuery(this).addClass("hide_eroor").dequeue();
		var that = this; setTimeout(function(){ jQuery(that).addClass("hide").dequeue(); }, 1100);
   });
   $('html, body').animate({scrollTop : 0},1000);  
   if((jQuery('#sample_image').attr('src')) === (jQuery('#add_image').val())){
      jQuery('#remove_image').addClass('hidden');
   } else { 
      jQuery('#remove_image').removeClass('hidden');
    }
    jQuery('#remove_image').click(function() {
      jQuery('#remove_image').addClass('hidden');
      jQuery('#sample_image').attr("src",jQuery('#add_image').val());
      jQuery('#is_remove_image').val('1');
      jQuery('#brand_logo').val('');
      //jQuery('#tmp_brand_logo').val('');
      
    });
    jQuery('.avatar-save').click(function() {
      jQuery('#remove_image').removeClass('hidden');
      jQuery('#is_remove_image').val('0');
    });
    if((jQuery('#sample_image1').attr('src')) === (jQuery('#add_image1').val())) {
      jQuery('#remove_image1').addClass('hidden');
    }
    else { 
      jQuery('#remove_image1').removeClass('hidden');
    }
    jQuery('#remove_image1').click(function() {
      jQuery('#remove_image1').addClass('hidden');
      jQuery('#sample_image1').attr("src",jQuery('#add_image1').val());
      jQuery('#is_remove_image1').val('1');
      jQuery('#welcome_image').val('');
     // jQuery('#tmp_welcome_image').val('');
    });
    jQuery('.avatar-save').click(function() {
      jQuery('#remove_image1').removeClass('hidden');
      jQuery('#is_remove_image1').val('0');
    });
 });
function OnProgress(event, position, total, percentComplete){ }

function bytesToSize(bytes) {
   var sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
   if (bytes == 0) return '0 Bytes';
   var i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)));
   return Math.round(bytes / Math.pow(1024, i), 2) + ' ' + sizes[i];
}    
  
var iBytesUploaded = 0;
var iBytesTotal = 0;
var iPreviousBytesLoaded = 0;
var iMaxFilesize = 5242880; // 1MB
var oTimer = 0;
var sResultFileSize = ''; 
function secondsToTime(secs) { // we will use this function to convert seconds in normal time format
    var hr = Math.floor(secs / 3600);
    var min = Math.floor((secs - (hr * 3600))/60);
    var sec = Math.floor(secs - (hr * 3600) -  (min * 60));

    if (hr < 10) {hr = "0" + hr; }
    if (min < 10) {min = "0" + min;}
    if (sec < 10) {sec = "0" + sec;}
    if (hr) {hr = "00";}
    return hr + ':' + min + ':' + sec;
}

function bytesToSize(bytes) {
    var sizes = ['Bytes', 'KB', 'MB'];
    if (bytes == 0) return 'n/a';
    var i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)));
    return (bytes / Math.pow(1024, i)).toFixed(1) + ' ' + sizes[i];
}
function Uploadimg(){
      $('#brand_logo').trigger('click');
      return false;
 }

function fileSelected() {
    var oFile = document.getElementById('brand_logo').files[0];
	var rFilter = /^(image\/bmp|image\/gif|image\/jpeg|image\/png|image\/tiff)$/i;
    if (! rFilter.test(oFile.type)) {
		error_msg(IMG_UNSUPPORTED);
        return false;
}
if (oFile.size > iMaxFilesize) {
	error_msg(IMG_SIZE_BIG);
	return false;
}
var oImage2 = document.getElementById('sample_image');
var oProfileImg = document.getElementById('profile_img_display');
var oReader = new FileReader();
oReader.onload = function(e) {
	oImage2.src = e.target.result;
};
oReader.readAsDataURL(oFile);
jQuery('#remove_image').removeClass('hidden');
}
function startUploading() {
	var error_val = true; 
	if (!error_val) {
		$('html, body').animate({scrollTop : 0},700);
		return false;
	}else{
		var oFilesize  = document.getElementById('brand_logo').files[0].size;
		if (oFilesize < iMaxFilesize) {
			 iPreviousBytesLoaded = 0;
			var updateurl = jQuery('#update_profile').attr('action');
			var vFD = new FormData(document.getElementById('update_profile')); 
			var oXHR = new XMLHttpRequest();        
			oXHR.upload.addEventListener('progress', uploadProgress, false);
			oXHR.addEventListener('load', uploadFinish, false);
			oXHR.addEventListener('error', uploadError, false);
			oXHR.addEventListener('abort', uploadAbort, false);
			oXHR.open('POST', updateurl);
			oXHR.send(vFD);
		}
	}
}
function uploadProgress(e) {
	if (e.lengthComputable) {
		iBytesUploaded = e.loaded;
		iBytesTotal = e.total;
		var iPercentComplete = Math.round(e.loaded * 100 / e.total);
		var iBytesTransfered = bytesToSize(iBytesUploaded);
	}
}
function Uploadimg1(){
      $('#welcome_image').trigger('click');
      return false;
}
function fileSelected1() {
	var oFile = document.getElementById('welcome_image').files[0];
	var rFilter = /^(image\/bmp|image\/gif|image\/jpeg|image\/png|image\/tiff)$/i;
    if (! rFilter.test(oFile.type)) {
         error_msg(IMG_UNSUPPORTED);   
    }
	if (oFile.size > iMaxFilesize) {
        error_msg(IMG_SIZE_BIG);                        
        return false;
    }       
	var oImage2 = document.getElementById('sample_image1');
	var oProfileImg = document.getElementById('profile_img_display1');
	var oReader = new FileReader();
	oReader.onload = function(e){
		oImage2.src = e.target.result;
	};
	oReader.readAsDataURL(oFile);
    jQuery('#remove_image1').removeClass('hidden');
}
function uploadProgress1(e) {
    if (e.lengthComputable) {
        iBytesUploaded = e.loaded;
        iBytesTotal = e.total;
        var iPercentComplete = Math.round(e.loaded * 100 / e.total);
        var iBytesTransfered = bytesToSize(iBytesUploaded);
}
}

