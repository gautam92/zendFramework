$(document).on('click', '.browse', function(){
  var file = $(this).parent().parent().parent().find('.file');
  file.trigger('click');
});
$(document).on('change', '.file', function(){
  $(this).parent().find('.form-control').val($(this).val().replace(/C:\\fakepath\\/i, ''));
});

function validation(){
	var first_name = $.trim($("#first_name").val());	
	var last_name = $.trim($("#last_name").val());	
	var email = $.trim($("#email").val());	
	var letters = /^[A-Z]+$/;  
	var error = false;
	if(first_name != '' && first_name.match(letters)) {
		$('[aria-labelledby=select2-first_name-container]').removeClass('cls_error');
	} else {
		$('[aria-labelledby=select2-first_name-container]').addClass('cls_error');
		error = true;
	}
	if(last_name != '' && last_name.match(letters)) {
		$('[aria-labelledby=select2-last_name-container]').removeClass('cls_error');
	} else {
		$('[aria-labelledby=select2-last_name-container]').addClass('cls_error');
		error = true;
	}
	if(email != '' && email.match(letters)) {
		$('[aria-labelledby=select2-email-container]').removeClass('cls_error');
	} else {
		$('[aria-labelledby=select2-email-container]').addClass('cls_error');
		error = true;
	}
	if($("#user_csv").val() == '' || $("#user_csv").val() == null) {	
		error_msg('Please upload user csv');
		error = true;
	} else if( document.getElementById("user_csv").value.toLowerCase().lastIndexOf(".csv")==-1) {	
		error_msg('Please upload csv format');
		error = true;
	}
	return error;
}

$(document).on("click","#save_modal",function(){
	$("#myModal").modal('hide');
	var vFD = new FormData(document.getElementById('importcsv'));
	var murl = $("#importcsv").attr('action');
	$(".cls_loader").removeClass('cls_hide');
	$.ajax({
		url : murl,
		data : vFD,
		cache : false,
		processData : false,
		contentType : false,
		dataType : "json",
		type : 'POST',
		success : function(data) {
			$('.cls_loader').addClass('cls_hide');
			if (data.status == 1) {
				window.location = MODULE_ROUTE_ACCOUNTADMIN_URL+'/hostdirectory';
			} else {
				error_msg(data.msg);
				return false;
			}
		},
		error : function(){
			error_msg(GLOBAL_ERROR_MESSAGE);
			$('.cls_loader').addClass('cls_hide');
			return false;
		}
	});
});
$(document).on("click","#id_import_csv",function(){
	var error = validation();
	if(!error) {
		$("#myModal").modal('show');
	}
});


var alphabet = new Array("A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z","AA","AB","AC","AD","AE","AF","AG","AH","AI","AJ","AK","AL","AM","AN","AO","AP","AQ","AR","AS","AT","AU","AV","AW","AX","AY","AZ");
var CsvAry = new Array();
var OrgCsvAry = new Array();
var SboxData = new Array("","");
$(document).on('change', '#user_csv', function(e){
	var csv_chk = true;
	if( document.getElementById("user_csv").value.toLowerCase().lastIndexOf(".csv")==-1) {	
		error_msg('Please upload csv format');
		csv_chk = false;
	}
	if(csv_chk)
	{
		CsvAry = new Array();
		if (e.target.files != undefined)
		{
			var flagRead = 0;
			var reader = new FileReader();
			reader.onload = function(e) {
				if(flagRead == 0)
				{
					var inputrad = "";
					var csvval = e.target.result.split("\n");
					var csvvalue = csvval[0].split(",");
					for(var i=0;i<csvvalue.length;i++)
					{
						var temp = csvvalue[i];
						if(temp != undefined && temp != '') {
							var tmpFirst = temp.charAt(0);
							var tmpLast = temp.slice(-1);
							if(tmpFirst == '"' && tmpLast == '"') {
								temp = temp.slice(1, -1);
							}
						}
						inputrad += "<option value='"+alphabet[i]+"'>" + temp + "</option>";
						CsvAry[alphabet[i]] = "<option value='"+alphabet[i]+"'>" + temp + "</option>";
					}
					OrgCsvAry = CsvAry;
					var html_sbox1 = "<option value='' selected='selected'>Select First Name</option>"+inputrad;
					$("#first_name").html(html_sbox1);
					$("#first_name").select2().val('Select User Name');
					$("#first_name").select2("val", "");
					$("#id_fname").removeClass("hidden");
					$('[aria-labelledby=select2-first_name-container]').removeClass('cls_error');
				}
				flagRead++;
			};
			reader.readAsText(e.target.files.item(0));
		}
	} else {
		CsvAry = new Array();
		var html_sbox1 = "<option value=''>Select First Name</option>";
		$("#first_name").html(html_sbox1);
	}
	return true;
});
$(document).on("change","#first_name",function(){
	var cbox_chk = check_csv_select_box($(this).attr("id")); 
	var cur_val = $(this).val();
	var inputrad = "";
	SboxData[0] = "";
	SboxData[1] = "";
	SboxData[2] = "";
	if(cbox_chk && cur_val) {
		SboxData[0] = cur_val;
		for (var k in CsvAry) {
			if (typeof CsvAry[k] !== 'function' && SboxData.indexOf(k) == -1) {
				inputrad += CsvAry[k];
			}
		}
		var html_sbox1 = "<option value='' selected='selected'>Select Last Name</option>"+inputrad;
		$("#last_name").html(html_sbox1);
		$("#last_name").select2().val('Select Last Name');
		$("#last_name").select2("val", "");
		$("#id_lname").removeClass("hidden");
	} else {
		$("#id_lname").addClass("hidden");
	}
});
$(document).on("change","#last_name",function(){
	var cbox_chk = check_csv_select_box($(this).attr("id")); 
	var cur_val = $(this).val();
	var inputrad = "";
	SboxData[1] = "";
	SboxData[2] = "";
	if(cbox_chk && cur_val) {
		for (var k in CsvAry) {
			SboxData[1] = cur_val;
			if (typeof CsvAry[k] !== 'function' && SboxData.indexOf(k) == -1) {
				inputrad += CsvAry[k];
			}
		}
		var html_sbox1 = "<option value='' selected='selected'>Select Corporate Email</option>"+inputrad;
		$("#email").html(html_sbox1);
		$("#email").select2().val('Select Email');
		$("#email").select2("val", "");
		$("#id_email").removeClass("hidden");
	} else {
		$("#id_email").addClass("hidden");
	}
});

$(document).on("change","#email",function(){
	var cbox_chk = check_csv_select_box($(this).attr("id")); 
	var cur_val = $(this).val();
	var inputrad = "";
	SboxData[2] = "";
	if(cbox_chk && cur_val) {
		for (var k in CsvAry) {
			SboxData[2] = cur_val;
			if (typeof CsvAry[k] !== 'function' && SboxData.indexOf(k) == -1) {
				inputrad += CsvAry[k];
			}
		}
		var html_sbox1 = "<option value='' selected='selected'>Select Phone Number</option>"+inputrad;
		$("#phone_number").html(html_sbox1);
		$("#phone_number").select2().val('Select Phone Number');
		$("#phone_number").select2("val", "");
		$("#id_phone").removeClass("hidden");
	} else {
		$("#id_phone").addClass("hidden");
	}
});
function check_csv_select_box(id)
{
	if(id == undefined || id == "" || id == null) {
		return false;
	}
	var cur_value = $("#"+id).val().trim();
	var letters = /^[A-Z]+$/;  
	if(cur_value != '' && cur_value.match(letters)) {
		$('[aria-labelledby=select2-'+id+'-container]').removeClass('cls_error');
		return true;
	} else {
		$('[aria-labelledby=select2-'+id+'-container]').addClass('cls_error');
		return false;
	}
}
