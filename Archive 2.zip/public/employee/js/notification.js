function replaceAll(str, term, replacement) {
	return str.replace(new RegExp(term, 'g'), replacement);
}	
var dataarr = {};
$(document).on("change","#host_sms_notification",function(){
	if($(this).is(":checked")) {
		$("#host_template").removeClass("hidden");
	} else {
		$("#host_template").addClass("hidden");
	}
});
$(document).on("change","#visitor_sms_notification",function(){
	if($(this).is(":checked")) {
		$("#visitor_tamplate").removeClass("hidden");
	} else {
		$("#visitor_tamplate").addClass("hidden");
	}
});
$(document).on("change","#host_email_notification",function(){
	if($(this).is(":checked")) {
		$("#host_email_template").removeClass("hidden");
	} else {
		$("#host_email_template").addClass("hidden");
	}
});
$(document).on("change","#visitor_email_notification",function(){
	if($(this).is(":checked")) {
		$("#visitor_email_tamplate").removeClass("hidden");
	} else {
		$("#visitor_email_tamplate").addClass("hidden");
	}
});
$(document).on("change","#feedback_rating",function(){
	if($(this).is(":checked")) {
		$("#feedback_notify").removeClass("hidden");
	} else {
		$("#feedback_notify").addClass("hidden");
	}
});
$(document).on("change","#is_feedback_sms_notification",function(){
	if($(this).is(":checked")) {
		$("#sms_notify").removeClass("hidden");
	} else {
		$("#sms_notify").addClass("hidden");
	}
});
$(document).on("change","#is_feedback_email_notification",function(){
	if($(this).is(":checked")) {
		$("#visitor_email_notify").removeClass("hidden");
	} else {
		$("#visitor_email_notify").addClass("hidden");
	}
});
// SIGN OUT //
$(document).on("change","#host_sms_notification_signout",function(){
	if($(this).is(":checked")) {
		$("#host_template_signout").removeClass("hidden");
	} else {
		$("#host_template_signout").addClass("hidden");
	}
});
$(document).on("change","#visitor_sms_notification_signout",function(){
	if($(this).is(":checked")) {
		$("#visitor_tamplate_signout").removeClass("hidden");
	} else {
		$("#visitor_tamplate_signout").addClass("hidden");
	}
});
$(document).on("change","#host_email_notification_signout",function(){
	if($(this).is(":checked")) {
		$("#host_email_template_signout").removeClass("hidden");
	} else {
		$("#host_email_template_signout").addClass("hidden");
	}
});
$(document).on("change","#visitor_email_notification_signout",function(){
	if($(this).is(":checked")) {
		$("#visitor_email_tamplate_signout").removeClass("hidden");
	} else {
		$("#visitor_email_tamplate_signout").addClass("hidden");
	}
});
// SIGN OUT //

function onlyNumeric(val) {
	var re = /^(?:[1-90]\d*|0)?(?:\.\d+)?$/;
	return re.test(val);
}
	function isPrice(evt){
      var valid = /^\d*(.\d{0,2})?$/.test(evt.value)
        val = evt.value;
      if (isNaN(val) || !valid || val < 0 || val > 100) {
          evt.value = val.substring(0, val.length - 1);
      }
}
function onlyDigit(val) {
	var re = /^\d+$/;
	return re.test(val);
}
	
function isNumber(evt) {
	//alert(evt);
	evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    //console.log(charCode);
    if(charCode == 46 || charCode == 39 || charCode == 37) {
		return true;
	} else if (charCode > 31 && (charCode < 48 || charCode > 57)) {
		return false;
	}
	return true;
}

$("#minimum_rating").keydown(function (e) {
        // Allow: backspace, delete, tab, escape, enter and .
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110]) !== -1 ||
             // Allow: Ctrl+A, Command+A
            (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) || 
             // Allow: home, end, left, right, down, up
            (e.keyCode >= 35 && e.keyCode <= 40)) {
                 // let it happen, don't do anything
                 return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
    });

$("#maximum_rating").keydown(function (e) {
        // Allow: backspace, delete, tab, escape, enter and .
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110]) !== -1 ||
             // Allow: Ctrl+A, Command+A
            (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) || 
             // Allow: home, end, left, right, down, up
            (e.keyCode >= 35 && e.keyCode <= 40)) {
                 // let it happen, don't do anything
                 return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
    });

function validation(){
	var error = false;
	var filter = /^[_a-zA-Z0-9-]+(\.[_a-zA-Z0-9-]+)*@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*(\.[a-zA-Z]{2,10})$/;
	var host_sms_notification = $("#host_sms_notification").is(":checked");
	var visitor_sms_notification = $("#visitor_sms_notification").is(":checked");
	var host_email_notification = $("#host_email_notification").is(":checked");
	var visitor_email_notification = $("#visitor_email_notification").is(":checked");
	var host_sms_notification_signout = $("#host_sms_notification_signout").is(":checked");
	var visitor_sms_notification_signout = $("#visitor_sms_notification_signout").is(":checked");
	var host_email_notification_signout = $("#host_email_notification_signout").is(":checked");
	var visitor_email_notification_signout = $("#visitor_email_notification_signout").is(":checked");
	var is_notification_applicable = $(".is_notification_applicable").is(":checked");
	if(host_sms_notification) {
		if($.trim($("#host_sms_template").val()) == '') {
			$("#host_sms_template").addClass('cls_error');
			error = true;
		} else {
			$("#host_sms_template").removeClass('cls_error');
		}
	}
	if(visitor_sms_notification) {
		if($.trim($("#visitor_sms_template").val()) == '') {
			$("#visitor_sms_template").addClass('cls_error');
			error = true;
		} else {
			$("#visitor_sms_template").removeClass('cls_error');
		}
	}
	if(host_email_notification) {
		if($.trim($("#host_email_text").val()) == '') {
			$("#host_email_text").addClass('cls_error');
			error = true;
		} else if (!filter.test($('#host_email_text').val())) {
			$('#host_email_text').addClass('cls_error');
			error_msg(EMAIL_INVALID);
			error = true;
		}	else {
			$("#host_email_text").removeClass('cls_error');
		}
	}
	if(visitor_email_notification) {
		if($.trim($("#visitor_email_text").val()) == '') {
			$("#visitor_email_text").addClass('cls_error');
			error = true;
		} else if (!filter.test($('#visitor_email_text').val())) {
			$('#visitor_email_text').addClass('cls_error');
			error_msg(EMAIL_INVALID);
			error = true;
		} else {
			$("#visitor_email_text").removeClass('cls_error');
		}
	}
	
	if(host_sms_notification_signout) {
		if($.trim($("#host_sms_template_signout").val()) == '') {
			$("#host_sms_template_signout").addClass('cls_error');
			error = true;
		} else {
			$("#host_sms_template_signout").removeClass('cls_error');
		}
	}
	if(visitor_sms_notification_signout) {
		if($.trim($("#visitor_sms_template_signout").val()) == '') {
			$("#visitor_sms_template_signout").addClass('cls_error');
			error = true;
		} else {
			$("#visitor_sms_template_signout").removeClass('cls_error');
		}
	}
	if(host_email_notification_signout) {
		if($.trim($("#host_email_text_signout").val()) == '') {
			$("#host_email_text_signout").addClass('cls_error');
			error = true;
		} else if (!filter.test($('#host_email_text_signout').val())) {
			$('#host_email_text_signout').addClass('cls_error');
			error_msg(EMAIL_INVALID);
			error = true;
		}	else {
			$("#host_email_text_signout").removeClass('cls_error');
		}
	}
	if(visitor_email_notification_signout) {
		if($.trim($("#visitor_email_text_signout").val()) == '') {
			$("#visitor_email_text_signout").addClass('cls_error');
			error = true;
		} else if (!filter.test($('#visitor_email_text_signout').val())) {
			$('#visitor_email_text_signout').addClass('cls_error');
			error_msg(EMAIL_INVALID);
			error = true;
		} else {
			$("#visitor_email_text_signout").removeClass('cls_error');
		}
	}
	$("form .custom_msg").filter(function () {
		if($.trim($(this).val()) == '' || $.trim($(this).val()) == null) {
			$(this).addClass('cls_error');
			error_msg('Please add custom messages');
			error = true;
		} else {
			$(this).removeClass('cls_error');
		}
	});
	if(is_notification_applicable) {
		if($("form .custom_msg").length <= 0) {
			error_msg('Please add custom messages');
			error = true;
		}
	}
	
	$("form .custom-front-notify").filter(function () {
		if($(this).parent().parent().find('.custom_msg').length > 5) {
			error_msg('You add maximum 5 custom messages');
			error = true;
		}
	});

	if($("#feedback_rating").prop('checked') == true){
		var minvalue = $('#minimum_rating').val();
		var maxvalue = $('#maximum_rating').val();
		if(minvalue != "" && maxvalue!="") {
			if(parseInt(minvalue) > parseInt(maxvalue)){
				error_msg(MIN_NOT_GREATER_THEN_MAX);
				$("#minimum_rating").addClass('cls_error');
				error = true;
			} else if(maxvalue > 5){
				error_msg(MAX_VALUE_ONLY_FIVE);
				$("#maximum_rating").addClass('cls_error');
				error = true;
			}
		}
		if(minvalue == "" || minvalue=="0") {
			$("#minimum_rating").addClass('cls_error');
			error = true;
		} else {
			$("#minimum_rating").removeClass('cls_error');
		}
		
		if(maxvalue == "" || maxvalue=="0") {
			$("#maximum_rating").addClass('cls_error');
			error = true;
		} else {
			$("#maximum_rating").removeClass('cls_error');
		}

	   if($("#is_feedback_sms_notification").prop('checked') == true) {
			var phone = $("#feedback_phone").val();
			var feedback_sms_template = $("#feedback_sms_template").val();
			if(phone =="") {
				$("#feedback_phone").addClass('cls_error');
				error = true;
			} else {
				$("#feedback_phone").removeClass('cls_error');
			}
			if(feedback_sms_template =="") {
				$("#feedback_sms_template").addClass('cls_error');
				error = true;
			} else {
				$("#feedback_sms_template").removeClass('cls_error');
			}
	   }

	   if($("#is_feedback_email_notification").prop('checked') == true){
			var feedback_email = $("#feedback_email").val();
			var feedback_email_template = $("#feedback_email_template").val();
			if(feedback_email=="" ) {
				$("#feedback_email").addClass('cls_error');
				error = true;
			} else if (!filter.test($('#feedback_email').val())) {
					$("#feedback_email").addClass('cls_error');
					error_msg(EMAIL_INVALID);
					error = true;
			} else {
				$("#feedback_email").removeClass('cls_error');
			}	

			if(feedback_email_template==""){
				$("#feedback_email_template").addClass('cls_error');
				error = true;
			} else {
				$("#feedback_email_template").removeClass('cls_error');

			}
	   }
	}
	return error;	
}

$(document).on("click","#save_notification",function(){
	var error = validation();
	$("#delete_ids").val(JSON.stringify(dataarr));
	 var url = jQuery("#sendnotification").attr('action');
	 var form_data = new FormData(document.getElementById('sendnotification'));
	if(error) {
		 jQuery('html, body').animate({scrollTop : 0}, 1000);
	} else {
		jQuery('#cls_loader').removeClass('cls_hide');
		jQuery.ajax({
			type : 'POST',
			url : url,
			dataType : "json",
			data :  form_data,
			processData : false,
			contentType : false,
			success : function(data) {
				if(data.error_log_out != undefined) {
					  location.reload();
					  return false;
				 }
				if(data.status == 1) {
					 var redirectURL = MODULE_ROUTE_ACCOUNTADMIN_URL+'/settings/formlist';
					 window.location = redirectURL; 
				} else {
					error_msg(data.msg);
				}
			},
			error: function() {
				 error_msg(GLOBAL_ERROR_MESSAGE);
				 jQuery('#cls_loader').addClass('cls_hide');
				 return false;
			}
		});
	}
});

$(document).on("click",".acc_title",function(){
	var id = $(this).attr('data-id');
	$("#acc_title"+id).toggleClass("acc_title_active");
	$("#acc_panel"+id).toggleClass("anim_in");
	$("#acc_panel"+id).toggleClass("acc_panel_col");
});
$(document).on("click",".custom-front-notify",function(){
	var id = $(this).attr('id');
	if($(this).parent().parent().find('.custom_msg').length == 5) {
		error_msg('You add maximum 5 custom messages');
		return false;
	}
	var apphtml = $("#hidden_html_div").html();
	apphtml = replaceAll(apphtml,"##ID##",id);
	$("#prophtml_"+id).append(apphtml);
	$(this).parent().parent().find('.custom_msg').focus();
});

$(document).on("click",".remove-field",function(){
	dataarr[$(this).attr('data-id')] = $(this).attr('data-id'); 
	$(this).parent().prev('div').remove();
	$(this).parent().remove();
});
$(document).on("change",".is_notification_applicable",function(){
	if($(this).is(":checked")) {
		$(this).parent().find('.tag').addClass('acc_title');
		$(this).parent().find('.tag').addClass('acc_title_active');
		$(this).parent().next().addClass('anim_in');
		$(this).parent().next().removeClass('acc_panel_col');
		//console.log($(this).parent().parent().parent().find('.custom_msg').parent().html())
		if($(this).parent().parent().parent().find('.custom_msg').length <= 0) {
			$(this).parent().parent().parent().find('.custom_msg').parent().remove();
			$(".custom-front-notify").trigger("click");
		}
	} else {
		$(this).parent().find('.tag').removeClass('acc_title');
		$(this).parent().find('.tag').removeClass('acc_title_active');
		$(this).parent().next().removeClass('anim_in');
		$(this).parent().next().addClass('acc_panel_col');
	}
});
$(document).on("blur","form .custom_msg",function(){
	var input_value = $.trim($(this).val());
	if(input_value == '' || input_value == null) {
		$(this).addClass('cls_error');
	} else {
		$(this).removeClass('cls_error');
	}
});
