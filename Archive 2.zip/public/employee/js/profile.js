$("#profile_logo").change(function() {
	var val = $(this).val();
	switch(val.substring(val.lastIndexOf('.') + 1).toLowerCase()){
		case 'png':
		case 'jpg':
		case 'jpeg':
		case 'gif':
			break;
		default:
			$(this).val('');
			error_msg('File format not supported.');
			break;
	}
});

 $(document).on("click", "#profile_submit", function() {
	var error = false;
	var myfile=$('#profile_logo').val();
	var ext = myfile.split('.').pop();
	if(myfile.trim() != "" && ext != 'png' && ext != 'jpg' && ext != 'jpeg' && ext != "gif"){
		error_msg('File format not supported.');
		error = true;
	} 
	if(error) {
		$('html, body').animate({ scrollTop : 0 }, 1000);
	} else {
		$(".cls_loader").removeClass('cls_hide');
		var Bcnurl = jQuery("#profile_form").attr('action');
		var vFD = new FormData(document.getElementById("profile_form")); 
		$.ajax({
			type : 'POST',
			url : Bcnurl,
			dataType : "json",
			data : vFD,
			cache: false,
			processData: false,
			contentType: false,
			success : function(data) {
				$('.cls_loader').addClass('cls_hide');
				if(data.error_log_out != undefined) {
				  location.reload();
				  return false;
				}
				if(data.status == 1) {
					if(data.profile_photo != '') {
						$("#profile_pic_view").attr('src',data.profile_photo);
					}
					success_msg(data.msg);
				} else {
					error_msg(data.msg);
				}
			},
			error : function(){
				$(".cls_loader").addClass('cls_hide');
				error_msg(GLOBAL_ERROR_MESSAGE);
				return false;
			}
		});
	}
 });
  
jQuery(document).ready(function(){
  jQuery(".isa_success").removeClass("hide_eroor").delay(2000).queue(function(){
	  jQuery(this).addClass("hide_eroor").dequeue();
		var that = this; setTimeout(function(){ jQuery(that).addClass("hide").dequeue(); }, 1100);
   });
   $('html, body').animate({scrollTop : 0},1000);  
   if((jQuery('#sample_image').attr('src')) === (jQuery('#add_image').val())){
      jQuery('#remove_image').addClass('hidden');
   } else { 
      jQuery('#remove_image').removeClass('hidden');
    }
    jQuery('#remove_image').click(function() {
      jQuery('#remove_image').addClass('hidden');
      jQuery('#sample_image').attr("src",jQuery('#add_image').val());
      jQuery('#is_remove_image').val('1');
      jQuery('#profile_logo').val(''); 
    });
    jQuery('.avatar-save').click(function() {
      jQuery('#remove_image').removeClass('hidden');
      jQuery('#is_remove_image').val('0');
    });
 });
function OnProgress(event, position, total, percentComplete){ }

function bytesToSize(bytes) {
   var sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
   if (bytes == 0) return '0 Bytes';
   var i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)));
   return Math.round(bytes / Math.pow(1024, i), 2) + ' ' + sizes[i];
}    
  
var iBytesUploaded = 0;
var iBytesTotal = 0;
var iPreviousBytesLoaded = 0;
var iMaxFilesize = 5242880; // 1MB
var oTimer = 0;
var sResultFileSize = ''; 
function secondsToTime(secs) { // we will use this function to convert seconds in normal time format
    var hr = Math.floor(secs / 3600);
    var min = Math.floor((secs - (hr * 3600))/60);
    var sec = Math.floor(secs - (hr * 3600) -  (min * 60));

    if (hr < 10) {hr = "0" + hr; }
    if (min < 10) {min = "0" + min;}
    if (sec < 10) {sec = "0" + sec;}
    if (hr) {hr = "00";}
    return hr + ':' + min + ':' + sec;
}

function bytesToSize(bytes) {
    var sizes = ['Bytes', 'KB', 'MB'];
    if (bytes == 0) return 'n/a';
    var i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)));
    return (bytes / Math.pow(1024, i)).toFixed(1) + ' ' + sizes[i];
}
function Uploadimg(){
      $('#profile_logo').trigger('click');
      return false;
 }

function fileSelected() {
    var oFile = document.getElementById('profile_logo').files[0];
	var rFilter = /^(image\/bmp|image\/gif|image\/jpeg|image\/png|image\/tiff)$/i;
    if (! rFilter.test(oFile.type)) {
		error_msg(IMG_UNSUPPORTED);
        return false;
}
if (oFile.size > iMaxFilesize) {
	error_msg(IMG_SIZE_BIG);
	return false;
}
var oImage2 = document.getElementById('sample_image');
var oProfileImg = document.getElementById('profile_img_display');
var oReader = new FileReader();
oReader.onload = function(e) {
	oImage2.src = e.target.result;
};
oReader.readAsDataURL(oFile);
jQuery('#remove_image').removeClass('hidden');
}
function startUploading() {
	var error_val = true; 
	if (!error_val) {
		$('html, body').animate({scrollTop : 0},700);
		return false;
	}else{
		var oFilesize  = document.getElementById('profile_logo').files[0].size;
		if (oFilesize < iMaxFilesize) {
			 iPreviousBytesLoaded = 0;
			var updateurl = jQuery('#update_profile').attr('action');
			var vFD = new FormData(document.getElementById('update_profile')); 
			var oXHR = new XMLHttpRequest();        
			oXHR.upload.addEventListener('progress', uploadProgress, false);
			oXHR.addEventListener('load', uploadFinish, false);
			oXHR.addEventListener('error', uploadError, false);
			oXHR.addEventListener('abort', uploadAbort, false);
			oXHR.open('POST', updateurl);
			oXHR.send(vFD);
		}
	}
}
function uploadProgress(e) {
	if (e.lengthComputable) {
		iBytesUploaded = e.loaded;
		iBytesTotal = e.total;
		var iPercentComplete = Math.round(e.loaded * 100 / e.total);
		var iBytesTransfered = bytesToSize(iBytesUploaded);
	}
}
//==========================START :: Password Update Part =============================// 

$(document).on("blur", "#org_pass,#org_confirmpass,#current_pass", function(){
	if (jQuery.trim($(this).val()) == null || jQuery.trim($(this).val()) == '') {
		$(this).addClass('cls_error');
	}else{
		$(this).removeClass('cls_error');
	}
});
jQuery('#update_password').click(function(){
	var current_pass =  $('#current_pass').val();
	var new_pwd =  $('#org_pass').val();
	var confirm_pwd = $('#org_confirmpass').val();
	var data_id = $('#data_id').val();
	var flag = true;
	if(jQuery.trim(current_pass) == null || jQuery.trim(current_pass) == ''){
		 jQuery('#current_pass').addClass('cls_error'); 
		 flag = false;
	} else if(CryptoJS.MD5(jQuery.trim(current_pass)) != data_id) {
		jQuery('#current_pass').addClass('cls_error'); 
		error_msg('Current password is wrong!');
		flag = false;
	}
	if(jQuery.trim(new_pwd) == null || jQuery.trim(new_pwd) == ''){
		 jQuery('#org_pass').addClass('cls_error'); 
		 flag = false;
	} else if(jQuery.trim(new_pwd) == jQuery.trim(current_pass)) {
		jQuery('#org_pass').addClass('cls_error'); 
		error_msg(CURRENT_PASSWORD_NEW_PASSWORD);
		 flag = false;
	}
	if(jQuery.trim(confirm_pwd) == null || jQuery.trim(confirm_pwd) == ''){
		 jQuery('#org_confirmpass').addClass('cls_error');
		 flag = false;
	} else if(new_pwd != confirm_pwd) {
		jQuery('#org_confirmpass').addClass('cls_error');
		error_msg(MISMATCH_PASSWORD);
		flag = false;
	}
	if(!flag){
		return false;
	}
	var data_value = window.btoa(new_pwd);
	var user_id = jQuery('#user_id').val();
	var organization_id = jQuery('#organization_id').val();
	var employee_id = jQuery('#org_employee_id').val();
	var organization_master_employee_id = jQuery('#organization_master_employee_id').val();
	var Bcnurl = jQuery("#pwd_form").attr('action');
	   $(".cls_loader").removeClass('cls_hide');
		jQuery.ajax({
		type: 'POST',
		url: Bcnurl,
		dataType: "json",
		data: {
		  data_value: data_value,
		  user_id: user_id,
		  organization_id: organization_id,
		  employee_id: employee_id,
		  current_pass: window.btoa(current_pass),
		  organization_master_employee_id: organization_master_employee_id,
		},
		success: function(data) {
			 $(".cls_loader").addClass('cls_hide');
			 if(data.error_log_out != undefined) {
				  location.reload();
				  return false;
			 }
			if(data.error != undefined){
				error_msg(data.error);
				jQuery('#org_pass').val('');
				jQuery('#org_confirmpass').val('');
				jQuery('#current_pass').val('');
			return false;
		  } else {
			 jQuery('#org_pass').val('');
			  jQuery('#org_confirmpass').val('');
			  jQuery('#current_pass').val('');
			  $('#org_confirmpass').removeClass('cls_error');
			  $('#org_pass').removeClass('cls_error');
			  $('#current_pass').removeClass('cls_error');
			  success_msg(PASSWORD_UPDATE);
		  }
		},
		error : function(){
			$(".cls_loader").addClass('cls_hide');
			error_msg(GLOBAL_ERROR_MESSAGE);
			return false;
		}
	});
	return false;
});
//==========================END :: Password Update Part =============================// 

