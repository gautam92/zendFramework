jQuery(document).ready(function(){
    jQuery('#email').focusout(function(){
    	var filter = /^[_a-zA-Z0-9-]+(\.[_a-zA-Z0-9-]+)*@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*(\.[a-zA-Z]{2,10})$/;
	    if ($(this).val() == null || $(this).val() == '') {
            $(this).addClass('cls_error');    
        }else if(!filter.test($(this).val())){
            $(this).addClass('cls_error');
        }else{
            $(this).removeClass('cls_error'); 
        }
    });  
    jQuery('#password').focusout(function(){
        if ($(this).val() == null || $(this).val() == '') {
            $(this).addClass('cls_error');    
        }else{
            $(this).removeClass('cls_error');  
        }
    });
	 $("#loginuser").unbind().submit(function(event) {	
		event.preventDefault();
        event.stopPropagation();
		var loginurl = jQuery("#loginuser").attr('action');
		var email = jQuery('#email').val();
		var password = jQuery('#password').val();
		var filter = /^[_a-zA-Z0-9-]+(\.[_a-zA-Z0-9-]+)*@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*(\.[a-zA-Z]{2,10})$/;
		var remember_chk = jQuery("input[name=check]").is(':checked');

		var error = true;
		if (email == null || email == '') {
			jQuery('#email').addClass('cls_error');
			error = false;
			//return false;
		}
		if (password == null || password == '') {
			jQuery('#password').addClass('cls_error');
			error = false;
			//return false;
		}
		if (!error) {
			$('html, body').animate({
				scrollTop : 0
			}, 1000);
			return false;
		} else if (!filter.test(email)) {
			error_msg(EMAIL_INVALID);
			return false;
		} else {
			var form_data = new FormData(document.getElementById('loginuser'));
			var msg_res = true;
            jQuery('#cls_loader').removeClass('cls_hide');
			jQuery.ajax({
				type : 'POST',
				url : loginurl,
				dataType : "json",
				data :  form_data,
				processData : false,
				contentType : false,
				success : function(data) {
                    jQuery('#cls_loader').addClass('cls_hide');
					if (data != undefined) {
    					var obj = data;
    					if (obj.error != undefined){
							error_msg(obj.error);
    						return false;
						} else {
                            if ($('#remember_chk').is(':checked')) {
    	                        if($('#email').val().length != "0" && $('#password').val().length != "0") {
                                    $.cookie("voonotes",$('#email').val()+","+ btoa($('#password').val())+","+$('#remember_chk').val()+"'",{ expires: 365 });
                                }
                            } else {
                                var email = $('#email').val();
                                $.cookie("voonotes","");
                            }
							location.reload();
						}
					}
				},
                error : function(){
					$(".cls_loader").addClass('cls_hide');
					error_msg(GLOBAL_ERROR_MESSAGE);
					return false;
				}
			});
            return false;
		}
		//return false;
	});

    jQuery('#changepassword_submit').click(function(){
    	var changepassword = jQuery("#changepwdemail").attr('action');
        var new_password = jQuery('#new_password').val();
    	var confirm_password = jQuery('#confirm_password').val();
        var forgot_token = jQuery('#forgot_token').val();
        var chg_error = true;
        if (new_password == null || new_password == '') {
                jQuery('#new_password').addClass('cls_error');
                chg_error = false;
                //return false;
        }
        if (confirm_password == null || confirm_password == '') {
                jQuery('#confirm_password').addClass('cls_error');
                chg_error = false;
                //return false;
        }
        if (!chg_error) {
                $('html, body').animate({scrollTop : 0},1000);
                jQuery('#curr_pass').val('');
                jQuery('#new_password').val('');
            	jQuery('#confirm_password').val('');
                return false;
        }else{
            if(new_password.length < 6) {
				error_msg(PASSWORD_LENGTH_6);
                jQuery('#curr_pass').val('');
                jQuery('#new_password').val('');
            	jQuery('#confirm_password').val('');
    	    	return false;
    	    }
	        if(new_password.length > 20) {
				error_msg(PASSWORD_LENGTH_20);
                jQuery('#curr_pass').val('');
                jQuery('#new_password').val('');
            	jQuery('#confirm_password').val('');
    	    	return false;
    	    }
	        jQuery('#new_password').css('border-color','#dedede');
            jQuery('#confirm_password').css('border-color','#dedede');
       		if (new_password != confirm_password) {
				error_msg(MISMATCH_PASSWORD);
                jQuery('#curr_pass').val('');
                jQuery('#new_pass').val('');
            	jQuery('#confirm_pass').val('');
                return false;
            }
	        var datachangepass = 'new_password='+ new_password+ '&confirm_password='+ confirm_password+'&forgot_token='+forgot_token;
            var chgpassurl = jQuery("#changepwdemail").attr('action');
            jQuery('#cls_loader').removeClass('cls_hide');
            jQuery.ajax({
                type: 'POST',
                url: chgpassurl,
                dataType: "json",
                // async:false,
                data: datachangepass,
                success: function(data) {
                    jQuery('#cls_loader').addClass('cls_hide');
                    if(data.errorpwd != undefined){
						error_msg(data.errorpwd);
				        return false;
			        } else if(data.succpwd != undefined) {
				        window.location = BASE_URL_MAIN;
				    }
                    return false;
                },
                error : function(){
					$(".cls_loader").addClass('cls_hide');
					error_msg(GLOBAL_ERROR_MESSAGE);
					return false;
				}
            });
        }
        return false;
    });
});
