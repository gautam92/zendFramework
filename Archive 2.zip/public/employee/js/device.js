function onlyDigit(val) {
	var re = /^\d+$/;
	return re.test(val);
}	
	
$(document).on("blur","#device_code",function(){
	var device_code = $.trim($(this).val());
	if(device_code == '' || device_code == null) {
		$(this).addClass("cls_error");
	} else {
		$(this).removeClass("cls_error");
	}
});	
	
$(document).on("click",".device_submit",function(){
	var error = false;
	var device_link_code = $.trim($("#device_code").val());
	if(device_link_code == '' || device_link_code == null) {
		$("#device_code").addClass("cls_error");
		error = true;
	} else {
		$("#device_code").removeClass("cls_error");
	}
	if(!error){
		$(".cls_loader").removeClass('cls_hide');
		$.ajax({
			type : 'POST',
			url : MODULE_ROUTE_ACCOUNTADMIN_URL+'/hardware/checkDeviceExistorNot',
			dataType : "json",
			data : {device_link_code:device_link_code},
			success : function(data) {
				$('.cls_loader').addClass('cls_hide');
				if(data.error_log_out != undefined) {
				  location.reload();
				  return false;
				}
				if(data.status == 1) {
					if(data.deviceData != undefined) {
						$("#device_name").val(data.deviceData.device_reference_name);
						//$("#ip_address").val(data.deviceData.ip_address);
						//$("#wifi_address").val(data.deviceData.wifi_network);
						var device_passcode = data.deviceData.device_passcode;
						if(data.deviceData.device_passcode == '' || data.deviceData.device_passcode == null) {
							 device_passcode = '-';
						}
						$("#device_password").val(device_passcode);
						if(data.deviceData.checkin_type == 1) {
							$("#checkin_type1").prop("checked",true);
						} else {
							$("#checkin_type0").prop("checked",true);
						}
					}
					 $("#device_model").val(data.dataarr['device_model']);
					 $("#device_unique_id").val(data.dataarr['device_unique_id']);
					 $("#device_link_code").val(data.dataarr['device_link_code']);
					 $("#device_type").val(data.dataarr['device_type']);
					 $("#device_os").val(data.dataarr['device_os']);
					 $("#os_version").val(data.dataarr['os_version']);
					 $("#app_version").val(data.dataarr['app_version']);
					 $("#device_socket_id").val(data.dataarr['device_socket_id']);
					 $("#wifi_address").val(data.dataarr['wifi_network']);
					 $("#ip_address").val(data.dataarr['ip_address']);
					 var html = "";
					 var devicemodel = '-';
					 var app_version = '-';
					 var ip_address = '-';
					 var wifi_network = '-';
					 if(data.dataarr['device_model'] != '' && data.dataarr['device_type'] != '') {
						devicemodel = data.dataarr['device_model']+', '+data.dataarr['device_type'];
					 } else if(data.dataarr['device_type'] == '') {
						devicemodel = data.dataarr['device_model'];
					 }
					 if(data.dataarr['app_version'] != '') {
						app_version = data.dataarr['app_version'];
					 }
					 if(data.dataarr['ip_address'] != '') {
						ip_address = data.dataarr['ip_address'];
					 }
					 if(data.dataarr['wifi_network'] != '') {
						wifi_network = data.dataarr['wifi_network'];
					 }
					 html += '<div class="row">';
						html += '<div class="col-xl-4 col-lg-12 col-sm-4 col-12 m-t-25 lg-m-t-15"><label>Model</label></div>';
						html += '<div class="col-xl-8 col-lg-12 col-sm-8 col-12 m-t-20 lg-m-t-5">'+devicemodel+'</div>';
					html += '</div>';
					html += '<div class="row">';
						html += '<div class="col-xl-4 col-lg-12 col-sm-4 col-12 m-t-25 lg-m-t-15"><label>App Version</label></div>';
						html += '<div class="col-xl-8 col-lg-12 col-sm-8 col-12 m-t-20 lg-m-t-5">'+app_version+'</div>';
					html += '</div>';
					html += '<div class="row">';
						html += '<div class="col-xl-4 col-lg-12 col-sm-4 col-12 m-t-25 lg-m-t-15"><label>Wifi Network</label></div>';
						html += '<div class="col-xl-8 col-lg-12 col-sm-8 col-12 m-t-20 lg-m-t-5">'+wifi_network+'</div>';
					html += '</div>';
					html += '<div class="row">';
						html += '<div class="col-xl-4 col-lg-12 col-sm-4 col-12 m-t-25 lg-m-t-15"><label>IP Address</label></div>';
						html += '<div class="col-xl-8 col-lg-12 col-sm-8 col-12 m-t-20 lg-m-t-5">'+ip_address+'</div>';
					html += '</div>';
					$(".device_info").html(html);
					$("#device_code_div").addClass("hidden");
					$("#device_add_div").removeClass("hidden");
				} else {
					error_msg(data.msg);
				}
			},
			error: function(){  // error handling
				error_msg(GLOBAL_ERROR_MESSAGE);
				$('.cls_loader').addClass('cls_hide');
			}
		});
	}
});

$(document).on("blur","#device_name",function(){
	var device_name = $.trim($(this).val());
	if(device_name == '' || device_name == null){
		$(this).addClass('cls_error');
	} else {
		$(this).removeClass('cls_error');
	}
});

$(document).on("blur","#device_password",function(){
	var device_password = $.trim($(this).val());
	//alert(!onlyDigit(device_password));
	if(device_password != '' && device_password != null) {
		if(device_password.length > 4 || device_password.length < 4 || !onlyDigit(device_password)){
			$(this).addClass('cls_error');
		} else {
			$(this).removeClass('cls_error');
		}
	}
});
function validationJquery() {
	var error = false;
	var device_name = $.trim($("#device_name").val());
	var device_password = $.trim($("#device_password").val());
	if(device_name == '' || device_name == null){
		$("#device_name").addClass('cls_error');
		error = true;
	} else {
		$("#device_name").removeClass('cls_error');
	}
	if(device_password != '' && device_password != null) {
		if(device_password.length > 4 || device_password.length < 4 || !onlyDigit(device_password)){
			$("#device_password").addClass('cls_error');
			error = true;
		} else {
			$("#device_password").removeClass('cls_error');
		}
	}
	return error;
}

$(document).on("click","#device_connect",function(){
	var error = validationJquery();
	if(!error){
		$(".cls_loader").removeClass('cls_hide');
		var Bcnurl = jQuery("#adddevice").attr('action');
		var vFD = new FormData(document.getElementById('adddevice')); 
		$.ajax({
			type : 'POST',
			url : Bcnurl,
			dataType : "json",
			data : vFD,
			cache: false,
			processData: false,
			contentType: false,
			success : function(data) {
				$('.cls_loader').addClass('cls_hide');
				if(data.error_log_out != undefined) {
				  location.reload();
				  return false;
				}
				if(data.status == 1) {
					window.location = MODULE_ROUTE_ACCOUNTADMIN_URL+'/hardware/managedevices';
				} else {
					error_msg(data.msg);
				}
			},
			error: function(){  // error handling
				error_msg(GLOBAL_ERROR_MESSAGE);
				$('.cls_loader').addClass('cls_hide');
				return false;
			}
		});
	}
});
