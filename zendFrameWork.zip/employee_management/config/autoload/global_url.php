<?php
/* @@ Developer : [Gautam Dharaiya] [Date : 11-Mar-2019]
  @@ Description :Define Url */
$_SERVER['HTTP_HOST'];
$actual_link = $_SERVER['HTTP_HOST'];

define('MODULE_ROUTE_URL','/employee_management/');
define('BASE_PATH_URL','http://'.$actual_link.'/employee_management/public/');  // Route Main url changes for htaccess url

define('BASE_PATH','http://'.$actual_link.'/employee_management/');
define('BASE_PATH_SCRIPT_URL_COMMAN','http://'.$actual_link.'/employee_management/public/common/');
define('BASE_PATH_SCRIPT_URL_EMPLOYEE','http://'.$actual_link.'/employee_management/public/employee/');

?>
