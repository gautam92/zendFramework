<?php
return array(
	'PHPExcel' => __DIR__.'/../../library/PHPExcel/PHPExcel.php',
	'PHPExcel_IOFactory' => __DIR__.'/../../library/PHPExcel/PHPExcel/IOFactory.php',
);