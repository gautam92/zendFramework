<?php
namespace Employeemgt\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Employeemgt\Model\Employeemgt;
use Employeemgt\Model\EmployeemgtTable;
use Employeemgt\Form\EmployeemgtForm;
use Zend\Authentication\Storage;
use Zend\Session\Config\SessionConfig;
use Zend\Session\Storage\ArrayStorage;
use Zend\Session\SessionManager;
use Zend\Session\Storage\StorageInterface;
use Zend\Validator\EmailAddress;
use Zend\Db\Sql\Select;
use Zend\Paginator\Paginator;
use Zend\Paginator\Adapter\Iterator as paginatorIterator;
use Zend\Stdlib\RequestInterface as Request;
use Zend\Stdlib\ResponseInterface as Response;
use Zend\Mvc\MvcEvent;

class EmployeemgtController extends AbstractActionController
{

	public function getEmployeemgtTable(){
		$sm = $this->getServiceLocator();
		$this->userTable = $sm->get('Employeemgt\Model\EmployeemgtTable');
		return $this->userTable;
	}

	public function indexAction()
	{
		$request = $this->getRequest();
		$vData = array();
		$vData['resultSet'] = $this->getEmployeemgtTable()->getContactList();
		return $vData;
		die;
	}

	public function createAction()
	{
		$request = $this->getRequest();
		$employee_id = $this->params('id');
		
		if ($request->isPost()) {
	        $post = $request->getPost()->toArray();
	        $file = $request->getFiles()->toArray();
	        
	       	if(isset($_FILES['profile_photo']) && $_FILES['profile_photo']["error"]== UPLOAD_ERR_OK )
			{
		        $data['image_path'] = 'employee_photo';
				$image_result = $this->getEmployeemgtTable()->uploadImage($file,$data);
				if($image_result['STATUS'] == 0){
					echo json_encode($image_result);
					die;
				}
			}
	        	
			if(isset($post['employee_id']) && $post['employee_id'] >'0'){
				$update['department_id'] = $post['e_department'];
				$update['name'] = $post['e_name'];
				$update['date_of_birth'] = date('Y-m-d H:i:s',strtotime($post['e_date_of_birth']));
				$update['phone_number'] = $post['e_number'];
				if(isset($image_result['RESULT'])){
				$update['photo'] = isset($image_result['RESULT']) ? $image_result['RESULT']:'';
				}
				$update['email'] = $post['e_email'];
				$update['salary'] = $post['e_salary'];
				$update['modified_date'] = date('Y-m-d H:i:s');

				$where_data['employee_id'] = $post['employee_id'];
				$department_list = $this->getEmployeemgtTable()->updateData('tbl_employee',$update,$where_data);
				$res['STATUS'] = 1;
				$res['MESSAGE'] = 'Your employee has been update successfully';
				echo json_encode($res);
				die();
			}else{
				$add['department_id'] = $post['e_department'];
				$add['name'] = $post['e_name'];
				$add['date_of_birth'] = date('Y-m-d H:i:s',strtotime($post['e_date_of_birth']));
				$add['phone_number'] = $post['e_number'];
				$add['photo'] = isset($image_result['RESULT']) ? $image_result['RESULT']:'';
				$add['email'] = $post['e_email'];
				$add['salary'] = $post['e_salary'];
				$add['created_date'] = date('Y-m-d H:i:s');
				$department_list = $this->getEmployeemgtTable()->addData('tbl_employee',$add);
				$res['STATUS'] = 1;
				$res['MESSAGE'] = 'Your employee has been added successfully';
				echo json_encode($res);
				die();
			}
		}   

		$vData = array();
		$department_list = $this->getEmployeemgtTable()->getData('tbl_department','','',1);
		$employee_detail = $this->getEmployeemgtTable()->getEmployeeDetails($employee_id);
		$vData['employee_detail'] = $employee_detail;
		$vData['department_list'] = $department_list['RESULT'];
		$vData['resultSet'] = $this->getEmployeemgtTable()->getContactList();
		return $vData;
		die;
	}

	public function deleteAction()
	{
		$request = $this->getRequest();
		$deletedIDs = json_decode($request->getpost()->deletedIDs);
		//echo "<pre>"; print_r($deletedIDs); exit;
		$data = array();
		if(empty($deletedIDs)) {
			$data['status'] = '0';
			$data['msg'] = 'No record found';
		} else {		
			$data['datatable_array'] = $this->getEmployeemgtTable()->delete($deletedIDs);
			$data['status'] = '1';
			$data['msg'] = 'Employee list has been deleted successfully';
		}
		echo json_encode($data); exit;
	}

}
