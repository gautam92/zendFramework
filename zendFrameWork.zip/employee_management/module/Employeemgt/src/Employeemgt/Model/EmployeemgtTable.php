<?php
namespace Employeemgt\Model;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Employeemgt\Model\Employeemgt;
use Employeemgt\Model\EmployeemgtTable;
use Zend\Db\Adapter\Driver\ResultInterface;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\Sql\Select;
use Zend\Db\Sql\Where;
use Zend\Db\Sql\Insert;
use Zend\Db\Adapter\AdapterInterface;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Db\Sql\Sql;
use Zend\Db\Sql\Update;
use Zend\Db\Sql\Delete;
use Zend\Validator;
use Zend\Validator\EmailAddress;
use Zend\Validator\File\Md5;
use Zend\Validator\Db\NoRecordExists;
use Zend\Mail;
use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Adapter\Driver\DriverInterface;
use Zend\Db\Sql\Expression; 
use Zend\Db\Sql\Predicate\NotIn;
// Use Pagination content.
use Zend\Paginator\Paginator;

class EmployeemgtTable extends AbstractTableGateway
{
    
    public function __construct(Adapter $adapter)
    {

		$this->adapter = $adapter;
		$this->resultSetPrototype = new ResultSet();
		//$this->resultSetPrototype->setArrayObjectPrototype(new Employeemgt());
		//$this->initialize();
    }
	

	public function getContactList(){
        $resultAry['AllData'] = array();

        $sql = "SELECT *,YEAR(CURDATE()) - YEAR(e.date_of_birth) AS age from tbl_employee e 
        LEFT JOIN tbl_department d ON d.department_id = e.department_id order by e.department_id,e.salary desc";
       
       /* $sql = "SELECT e.employee_id,e.name,e.photo,e.created_date,d.department_name,e.department_id,SUM(e.salary) AS salary FROM tbl_employee e left join tbl_department d on d.department_id = e.department_id  GROUP BY e.name,e.department_id ORDER BY salary DESC";*/
        

        $statement = $this->adapter->query($sql);
        $result = $statement->execute();

        $department_list = array();
        $without_department = array();
	    foreach ($result as $key => $value) {
	    	$tmpAry = array();
	    	$tmpAry[] = $value['employee_id'];
            $tmpAry[] = $value['photo'] != '' ? "<img src='".BASE_PATH_URL."uploads/employee_photo/".$value['photo']."' width='50%'>":'No Image';
            //$tmpAry[] = $value['photo'];
            $tmpAry[] = $value['name'];
            $tmpAry[] = (!empty($value['department_name'])?$value['department_name']:'-');
            $tmpAry[] = (!empty($value['age'])?$value['age']:'-');
            $tmpAry[] = (!empty($value['salary'])?$value['salary']:'-');
           	$tmpAry[] = date("d/m/Y h:i A",strtotime($value['created_date']));
            $tmpAry[] = '<a href="'.BASE_PATH.'employeemgt/create/'.$value['employee_id'].'" class="cls_send_sms" id="edit_employee">edit</a> ';

            if((!empty($value['department_name']))){
            	$department_list[$value['department_name']][] = $tmpAry;
            }else{
            	$without_department['without_department'][] = $tmpAry;
            }
	    	//$resultAry['AllData'][] = $department_list;
	    }

	    $resultAry['AllData'] = array_merge($department_list,$without_department);
		return $resultAry;
    }

    public function getData($table_name,$where_data='',$order_by_key='',$is_return_array = 0,$where_or =''){
		try{

			$sql_branch = new Sql($this->adapter);
	    	$select = new Select($table_name);
			if($where_data !='' && !empty($where_data)){
				$select->where($where_data);
				//$select->orWhere($where_or);
			}
			if($order_by_key !=''){
				$select->order($order_by_key);
			}

			//print_r($select); die;
			$statement = $sql_branch->prepareStatementForSqlObject($select);
		    $result_data = $statement->execute();

		    //echo $select->getSqlString();
		    if(count($result_data)> 0){
		    	if($is_return_array == '1'){
		    		$row = $result_data;
		    	}else{
		    		$row = $result_data->current();
				}
				$res['STATUS'] = 1;
				$res['MESSAGE'] = 'Success';
				$res['RESULT'] = $row;
		    }else{
		    	$res['STATUS'] = 0;
				$res['MESSAGE'] = 'No data available';
				
		    }
		  	return $res;
    	}catch(Exception $e){
    		$res['STATUS'] = 0;
    		$res['MESSAGE'] = 'Something went wrong with server';
    		return $res;
    	}
    }    

    public function addData($table_name,$add_data){
    	//try{
	    	$insert = new Insert($table_name);
	        $insert->values($add_data);
	        $statment = $this->adapter->createStatement();
	        $insert->prepareStatement($this->adapter, $statment);
	        $result = $statment->execute();     
	        $last_add_data_id = $this->adapter->getDriver()->getLastGeneratedValue();
        	return $last_add_data_id;
    	/*}catch(Exception $e){
    		return 0;
    	}*/
    }

    public function updateData($table_name,$update_data,$where_data){
    	try{
	    	$update = new Update($table_name);
	        $update->set($update_data);
	        $update->where($where_data);
	        $statment = $this->adapter->createStatement();
	        $update->prepareStatement($this->adapter, $statment);
	        $result = $statment->execute(); 
        }catch(Exception $e){
    		return 0;
    	}
    }

    public function delete($deleteIDs)
    {
        foreach($deleteIDs as $k=>$v) {
            if(!empty($k) && $v == '1') {
                // Contact Role Deleled //
                $del_sql ="DELETE FROM `tbl_employee` WHERE `employee_id` = '".$k."' ";
                $del_statement = $this->adapter->query($del_sql);
                $del_result = $del_statement->execute();
            }
        }
        return $this->getContactList();
    }

    public function uploadImage($file,$data){
		
		$_FILES = $file;
		if(isset($_FILES['profile_photo']) && $_FILES['profile_photo']["error"]== UPLOAD_ERR_OK )
		{
				############ Edit settings ##############
				$UploadDirectory	=  getcwd().'/public/uploads/employee_photo/';  //specify upload directory ends with / (slash)
				##########################################
				
				//Is file size is less than allowed size.
				if ($_FILES['profile_photo']["size"] > 5242880) {
					$res['STATUS'] = 0;
					$res['MESSAGE'] = 'File size is too big!';
					return $res;
					die;
				}
				
				//allowed file type Server side check
				switch(strtolower($_FILES['profile_photo']['type']))
					{
						//allowed file types
						case 'image/png': 
						case 'image/gif': 
						case 'image/jpeg':
						case 'image/jpg':
						break;
						default:
						$res['STATUS'] = 0;
						$res['MESSAGE'] = 'Invalid image type';
						return $res;
						die;
					}
				
				$File_Name          = strtolower($_FILES['profile_photo']['name']);
				$File_Ext           = substr($File_Name, strrpos($File_Name, '.')); //get file extention
				// $Random_Number      = rand(0, 9999999999); //Random number to be added to name.
				$Random_Number      = date('YmdHis'); //Unique number to be added to name.
				$NewFileName 		= $Random_Number.$File_Ext; //new file name
				$fileaws_path = 'employee_photo/';
				$image_type = $_FILES["profile_photo"]["type"];
				$filename = tempnam(sys_get_temp_dir(), $Random_Number);
			    $image_path['actual_image'] = $fileaws_path.$NewFileName;  
				$image_path['publicDir'] = $_FILES['profile_photo']['tmp_name']; //$filename;

				if (move_uploaded_file($image_path['publicDir'],$UploadDirectory.$NewFileName)) {
				//getcwd() . '/public/images/branch_img.png';
					$res['STATUS'] = 1;
					$res['MESSAGE'] = 'Success';
					$res['RESULT'] = $NewFileName;
					return $res;
				}else{
					$res['STATUS'] = 0;
					$res['MESSAGE'] = 'Image uploading fail';
					return $res;
				}
				
		}else{
			$res['STATUS'] = 0;
			$res['MESSAGE'] = 'Something went wrong with Server';
			return $res;
		}
    }

    public function getEmployeeDetails($employee_id){
        

        $sql = new Sql($this->adapter);
	    $select = $sql->select();
	    $select->from(array('te' => 'tbl_employee'))
	           ->join(array('td' => 'tbl_department'), 'te.department_id = td.department_id');
	    $where = new  Where();
	    $where->equalTo('te.employee_id', $employee_id);
	    $select->where($where);
	 	//you can check your query by echo-ing :
	    //echo $select->getSqlString();
	    $statement = $sql->prepareStatementForSqlObject($select);
	    $result = $statement->execute();
	    $row = $result->current();
		return $row;
    }
}
