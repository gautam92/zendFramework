<?php
namespace Employeemgt\Form;

use Zend\Form\Form;

class EmployeemgtForm extends Form
{
    public function __construct($name = null)
    {
        // we want to ignore the name passed
        parent::__construct('Employeemgt');

        $this->setAttribute('method', 'post');
        $this->add(array(
            'name' => 'id',
            'attributes' => array(
                'type'  => 'hidden',
            ),
        ));

        $this->add(array(
            'name' => 'submit',
            'attributes' => array(
                'type'  => 'submit',
                'value' => 'Go',
                'id' => 'submitbutton',
            ),
        ));
    
    $this->add(array(
            'name' => 'first_name',
            'attributes' => array(
                'type'  => 'text',
                'id' => 'first_name',
                'placeholder'  => 'Type name',
                'class' => 'form-control',
				//'maxlength' => '30',
				'onkeyup'=> "cFnameLname(this);",
            ),
    ));
		
	
 
    }
}
