<?php

namespace Employeemgt;

use Employeemgt\Model\EmployeemgtTable;

use Zend\Mvc\MvcEvent;
class Module
{
	
    public function getAutoloaderConfig()
    {
        return array(
            'Zend\Loader\ClassMapAutoloader' => array(
                __DIR__ . '/autoload_classmap.php',
            ),
            'Zend\Loader\StandardAutoloader' => array(
                'namespaces' => array(
                    __NAMESPACE__ => __DIR__ . '/src/' . __NAMESPACE__,
                ),
	    	),
        );
    }
    
   public function getServiceConfig()
    {
    	return array(
            'factories' => array(
                'Employeemgt\Model\EmployeemgtTable' =>  function($sm) {
                    $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                    $table = new EmployeemgtTable($dbAdapter);
                    return $table;
                 },
            ),
        );
    }

    public function getConfig() {
    	return include __DIR__ . '/config/module.config.php';
    }
}

