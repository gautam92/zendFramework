
var hostname = window.location.hostname;
var pageUrl = window.location.protocol;
var host_name = window.location.host;
var domain_url = 'employee_management';
var ROOT_URL = '';
ROOT_URL = pageUrl+"//"+host_name+'/'+domain_url+'/';
// //~
var BASE_URL_MAIN = ROOT_URL+'employeemgt';
var BASE_URL= ROOT_URL+'employeemgt';
var MODULE_ROUTE_URL = 'employeemgt';
				  
function success_msg(msg){
	 jQuery('html, body').animate({scrollTop : 0}, 1000);
	  jQuery('#id_org_msg').html('<div class="isa_success" style="z-index:999;"><span>'+msg+'</span></div>');
		jQuery(".isa_success").removeClass("hide_eroor").delay(2000).queue(function(){
			jQuery(this).addClass("hide_eroor").dequeue();
			var that = this; setTimeout(function(){ jQuery(that).addClass("hide").dequeue(); }, 1100);
		});
}
function error_msg(msg){
	 jQuery('html, body').animate({scrollTop : 0}, 1000);
	  jQuery('#id_org_msg').html('<div class="isa_error" style="z-index:999;"><span>'+msg+'</span></div>');
		jQuery(".isa_error").removeClass("hide_eroor").delay(2000).queue(function(){
			jQuery(this).addClass("hide_eroor").dequeue();
			var that = this; setTimeout(function(){ jQuery(that).addClass("hide").dequeue(); }, 1100);
		});
}