<?php

/**
 * This makes our life easier when dealing with paths. Everything is relative
 * to the application root now.
 */

chdir(dirname(__DIR__));
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Headers: x-requested-with");

//$environment = 'development';
if ($environment == 'development') {
	error_reporting(E_ALL);
	ini_set("display_errors", 1);
}

ini_set("max_execution_time", "-1");
ini_set("memory_limit", "-1");
ignore_user_abort(true);
set_time_limit(0);

// Setup autoloading
include 'init_autoloader.php';
require 'config/autoload/global_url.php';


// Run the application!
Zend\Mvc\Application::init(include 'config/application.config.php')->run()->send();




